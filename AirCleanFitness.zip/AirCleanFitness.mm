<map version="freeplane 1.6.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="Air Cleaning Fitness&#xa;ACFit" FOLDED="false" ID="ID_362164510" CREATED="1517025450167" MODIFIED="1545536924983">
<font SIZE="18"/>
<hook NAME="MapStyle" background="#000000" zoom="2.0">
    <properties fit_to_viewport="false" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#cccccc" BACKGROUND_COLOR="#333333" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<icon BUILTIN="yes"/>
</stylenode>
<stylenode TEXT="mine" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#cccccc" BACKGROUND_COLOR="#333333" SHAPE_HORIZONTAL_MARGIN="10.0 pt" SHAPE_VERTICAL_MARGIN="10.0 pt">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="30" RULE="ON_BRANCH_CREATION"/>
<node TEXT="&#x6982;&#x8981;" POSITION="right" ID="ID_1877809856" CREATED="1545536936602" MODIFIED="1545536940711">
<edge COLOR="#7c0000"/>
<node TEXT="&#x6027;&#x8cea;&#x985e;&#x4f3c;&quot;&#x5927;&#x898f;&#x6a21;&#x8def;&#x8dd1;&quot;&#xff0c;&#x4f46;&#x662f;&#x6539;&#x6210;&#x5728;&#x5ba4;&#x5167;&#xff0c;&#x4e0d;&#x8b93;&#x53c3;&#x52a0;&#x8005;&#x5438;&#x9ad2;&#x7a7a;&#x6c23;&#xff0c;&#x800c;&#x4e14;&#x904b;&#x52d5;&#x65b9;&#x5f0f;&#x591a;&#x7a2e;&#xff0c;&#x4e0d;&#x9650;&#x65bc;&#x6162;&#x8dd1;&#xff0c;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x5f9e;&#x4e00;&#x5929;&#x6539;&#x6210;&#x4e00;&#x500b;&#x6708;&#x3002;" ID="ID_1139102830" CREATED="1545536941774" MODIFIED="1545537117944"/>
<node TEXT="&#x53c3;&#x52a0;&#x8005;&#x5230;&#x6307;&#x5b9a;&#x7684;&#x4f4d;&#x65bc;&#x5ba4;&#x5167;&#x3001;&#x4f7f;&#x7528;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;&#x7cfb;&#x7d71;&#x7684;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x9032;&#x884c;&#x904b;&#x52d5;&#xff0c;&#x5c07;&#x904b;&#x52d5;&#x5668;&#x6750;&#x5982;&#x98db;&#x8f2a;&#x6216;&#x5212;&#x8239;&#x6a5f;&#x7b49;&#x6539;&#x9020;&#x6210;&#x53ef;&#x4ee5;&#x62bd;&#x6c34;&#x84c4;&#x80fd;&#x4ee5;&#x9032;&#x884c;&#x767c;&#x96fb;&#x7684;&#x7248;&#x672c;&#xff0c;&#xa;&#x53c3;&#x52a0;&#x8005;&#x7528;&#x9019;&#x4e9b;&#x5668;&#x6750;&#x7d2f;&#x7a4d;&#xff62;&#x91cc;&#x7a0b;&#x6578;&#xff63;&#x4e26;&#x4e14;&#x4ee5;&#x6b64;&#x70ba;&#x6a19;&#x6e96;&#x9032;&#x884c;&#x7af6;&#x8cfd;&#xff0c;&#xa;&#x5b98;&#x65b9;&#x7db2;&#x7ad9;&#x4e0a;&#x6703;&#x5373;&#x6642;&#x66f4;&#x65b0;&#x6bcf;&#x4e00;&#x4f4d;&#x53c3;&#x8cfd;&#x8005;&#x7684;&#x9032;&#x5ea6;&#xff0c;&#x7e3d;&#x76ee;&#x6a19;&#x91cc;&#x7a0b;&#x6578;&#x8a02;&#x5728;&#x4e00;&#x500b;&#x4eba;&#x53ef;&#x4ee5;&#x5728;&#x4e00;&#x500b;&#x6708;&#x5167;&#x9032;&#x884c;&#x7684;&#x5408;&#x7406;&#x7bc4;&#x570d;&#x5167;&#xff0c;&#xa;&#x6700;&#x65e9;&#x9054;&#x6a19;&#x8005;&#x5373;&#x70ba;&#x51a0;&#x8ecd;&#xff0c;&#x4ee5;&#x6b64;&#x985e;&#x63a8;&#x3002;" ID="ID_287169656" CREATED="1545537118522" MODIFIED="1547943953802"/>
</node>
<node TEXT="&#x7279;&#x6027;" POSITION="right" ID="ID_1365111978" CREATED="1545537597787" MODIFIED="1545537604490">
<edge COLOR="#00007c"/>
<node TEXT="1.&#x4e0d;&#x8b93;&#x4f60;&#x5438;&#x9ad2;&#x7a7a;&#x6c23;" ID="ID_1968833217" CREATED="1545537605599" MODIFIED="1545537625255">
<node TEXT="&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x5747;&#x4f4d;&#x65bc;&#x5ba4;&#x5167;&#xff0c;&#x4e14;&#x5099;&#x6709;&#x7a7a;&#x6c23;&#x6de8;&#x5316;&#x7cfb;&#x7d71;&#xff0c;&#x8b93;&#x53c3;&#x8cfd;&#x8005;&#x80fd;&#x5920;&#x9032;&#x884c;&#x771f;&#x6b63;&#x5065;&#x5eb7;&#x7684;&#x904b;&#x52d5;&#x3002;" ID="ID_1531940393" CREATED="1545537626634" MODIFIED="1545537691530"/>
</node>
<node TEXT="2.&#x4f60;&#x904b;&#x52d5;&#x6211;&#x6de8;&#x7a7a;" ID="ID_267362005" CREATED="1545537694425" MODIFIED="1545537719190">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x5728;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x767c;&#x51fa;&#x7684;&#x96fb;&#x529b;&#x5c07;&#x6703;&#x88ab;&#x7528;&#x4f86;&#x9a45;&#x52d5;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;&#x7cfb;&#x7d71;&#x3001;&#x51b7;&#x6c23;&#x7cfb;&#x7d71;&#x4ee5;&#x53ca;&#x7167;&#x660e;&#xff0c;&#xa;&#x4e0d;&#x53ea;&#x5728;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x7684;&#x5ba4;&#x5167;&#xff0c;&#x540c;&#x6642;&#x5728;&#x5ba4;&#x5916;&#x4e5f;&#x6703;&#x653e;&#x7f6e;&#x5c0d;&#x5916;&#x7684;&#x7a7a;&#x6c23;&#x6de8;&#x5316;&#x7cfb;&#x7d71;&#xff0c;&#x5229;&#x5df1;&#x4e5f;&#x5229;&#x4ed6;&#xff0c;&#x6709;&#x516c;&#x76ca;&#x6027;&#x8cea;&#x3002;" ID="ID_1171837050" CREATED="1545537719956" MODIFIED="1549674435111"/>
<node TEXT="&#x7ad9;&#x9ede;&#x7684;&#x4f9b;&#x96fb;&#x81ea;&#x7d66;&#x81ea;&#x8db3;&#xff0c;&#x6e1b;&#x5c11;&#x4f86;&#x81ea;&#x706b;&#x529b;&#x767c;&#x96fb;&#x5ee0;&#x7684;&#x7a7a;&#x6c23;&#x6c59;&#x67d3;&#xff0c;&#x591a;&#x9918;&#x7684;&#x96fb;&#x529b;&#x53c8;&#x53ef;&#x4ee5;&#x5c0d;&#x7ad9;&#x9ede;&#x9644;&#x8fd1;&#x7684;&#x7a7a;&#x6c23;&#x9032;&#x884c;&#x6de8;&#x5316;&#xff0c;&#x7b49;&#x65bc;&#x662f;&#x96d9;&#x91cd;&#x7684;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;" ID="ID_186859850" CREATED="1549674448251" MODIFIED="1549674654716"/>
</node>
<node TEXT="3.&#x53c3;&#x8cfd;&#x6642;&#x9593;&#x5730;&#x9ede;&#x4efb;&#x4f60;&#x6311;" ID="ID_1098588662" CREATED="1545537860479" MODIFIED="1545537958389">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x5728;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x53ea;&#x8981;&#x662f;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x958b;&#x653e;&#x7684;&#x6642;&#x6bb5;&#x90fd;&#x53ef;&#x53c3;&#x8cfd;&#xff0c;&#xa;&#x800c;&#x4e14;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x4e0d;&#x53ea;&#x4e00;&#x500b;" ID="ID_350362140" CREATED="1545537897560" MODIFIED="1545537995389"/>
</node>
<node TEXT="4.&#x904b;&#x52d5;&#x9805;&#x76ee;&#x4efb;&#x4f60;&#x6311;" ID="ID_524135087" CREATED="1545537996831" MODIFIED="1545538060309">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x53ef;&#x4ee5;&#x6311;&#x9078;&#x81ea;&#x5df1;&#x60f3;&#x9032;&#x884c;&#x7684;&#x904b;&#x52d5;&#x9805;&#x76ee;&#xff0c;&#x4e0d;&#x9700;&#x8981;&#x4fb7;&#x9650;&#x5728;&#x9577;&#x8dd1;&#xff0c;&#xa;&#x53ea;&#x8981;&#x662f;&#x80fd;&#x5920;&#x914d;&#x5408;&#x904b;&#x52d5;&#x5668;&#x6750;&#x9032;&#x884c;&#x62bd;&#x6c34;&#x767c;&#x96fb;&#x7684;&#x9805;&#x76ee;&#x90fd;&#x53ef;&#x4ee5;&#xff0c;&#xa;&#x98db;&#x8f2a;&#x3001;&#x5212;&#x8239;&#x6a5f;&#x3001;&#x555e;&#x9234;&#x3001;&#x62c9;&#x529b;&#x7e69;&#x90fd;&#x884c;&#xff0c;&#x56e0;&#x6b64;&#x4ee5;&#x7121;&#x6c27;&#x58d3;&#x529b;&#x8a13;&#x7df4;&#x70ba;&#x76ee;&#x6a19;&#x7684;&#x5065;&#x7f8e;&#x9078;&#x624b;&#x53ef;&#x4ee5;&#x548c;&#x6709;&#x6c27;&#x904b;&#x52d5;&#x7684;&#x611b;&#x597d;&#x8005;&#x540c;&#x53f0;&#x7af6;&#x6280;&#x3001;&#x62f3;&#x64ca;&#x9078;&#x624b;&#x80fd;&#x8207;&#x99ac;&#x62c9;&#x677e;&#x8dd1;&#x8005;&#x4e00;&#x8f03;&#x9ad8;&#x4e0b;&#x3002;" ID="ID_194628336" CREATED="1545538061872" MODIFIED="1550117693765"/>
</node>
<node TEXT="5.&#x734e;&#x52f5;&#x9054;&#x6a19;&#x8005;" ID="ID_1837423007" CREATED="1545538382652" MODIFIED="1545538400524">
<node TEXT="&#x7531;&#x65bc;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x9577;&#x9054;&#x4e00;&#x500b;&#x6708;&#xff0c;&#x6709;&#x53ef;&#x80fd;&#x6703;&#x6709;&#x4eba;&#x4e2d;&#x9014;&#x68c4;&#x8cfd;&#xff0c;&#xa;&#x56e0;&#x6b64;&#x8a2d;&#x5b9a;&#x6bcf;&#x7576;&#x53c3;&#x8cfd;&#x8005;&#x7d2f;&#x7a4d;&#x4e00;&#x5b9a;&#x7684;&#x904b;&#x52d5;&#x91cc;&#x7a0b;&#x6578;&#x5c31;&#x53ef;&#x4ee5;&#x53d6;&#x56de;&#x4e00;&#x5b9a;&#x6bd4;&#x4f8b;&#x7684;&#x53c3;&#x52a0;&#x8cbb;&#xff0c;&#x5728;&#x6d3b;&#x52d5;&#x7d50;&#x675f;&#x6642;&#x9000;&#x56de;&#x7d66;&#x53c3;&#x52a0;&#x8005;&#xff0c;&#x7528;&#x734e;&#x52f5;&#x6a5f;&#x5236;&#x4f86;&#x4fc3;&#x9032;&#x53c3;&#x8cfd;&#x8005;&#x5b8c;&#x6210;&#x76ee;&#x6a19;&#x3002;" ID="ID_164648339" CREATED="1545538403118" MODIFIED="1545538654109"/>
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x9032;&#x884c;&#x904b;&#x52d5;&#x9700;&#x8981;&#x5360;&#x7528;&#x5668;&#x6750;&#xff0c;&#x56e0;&#x6b64;&#x9700;&#x8981;&#x8b93;&#x4f7f;&#x7528;&#x8005;&#x5148;&#x9810;&#x7d04;&#x6642;&#x6bb5;&#xff0c;&#x7576;&#x4f7f;&#x7528;&#x8005;&#x5728;&#x9810;&#x7d04;&#x7684;&#x6642;&#x6bb5;&#x6e96;&#x6642;&#x4f86;&#x9032;&#x884c;&#x4e26;&#x4e14;&#x9054;&#x6a19;&#x6642;&#xff0c;&#x9000;&#x8cbb;&#x734e;&#x52f5;&#x7684;&#x6bd4;&#x7387;&#x66f4;&#x5927;" ID="ID_985234327" CREATED="1547962100706" MODIFIED="1547962221270"/>
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x53ef;&#x4ee5;&#x9080;&#x8acb;&#x670b;&#x53cb;&#x4e00;&#x540c;&#x53c3;&#x52a0;&#xff0c;&#x5728;&#x540c;&#x6642;&#x6bb5;&#x4f46;&#x4e0d;&#x540c;&#x6d3b;&#x52d5;&#x7ad9;&#x9ede;&#x9032;&#x884c;&#x6d3b;&#x52d5;&#xff0c;&#x9054;&#x6a19;&#x5f8c;&#x540c;&#x6a23;&#x7d66;&#x4e88;&#x734e;&#x52f5;&#xff0c;&#x4fc3;&#x4f7f;&#x4ed6;&#x5011;&#x7d50;&#x4f34;&#x53c3;&#x8cfd;" ID="ID_1953353770" CREATED="1547962222817" MODIFIED="1548291053174"/>
<node TEXT="&#x4f8b;:&#x53c3;&#x52a0;&#x8cbb;2000&#xff0c;&#x6bcf;&#x4e00;&#x6b21;&#x90fd;&quot;&#x9080;&#x8acb;&#x4e00;&#x4eba;&#x4ee5;&#x4e0a;&#x53c3;&#x52a0;&quot; &#xff0c;&quot;&#x6e96;&#x6642;&#x5230;&#x9810;&#x7d04;&#x7ad9;&#x9ede;&quot;&#xff0c;&quot;&#x6bcf;&#x6b21;&#x904b;&#x52d5;&#x90fd;&#x9054;&#x5230;&#x76ee;&#x6a19;&#x904b;&#x52d5;&#x91cf;&quot;&#x5728;&#x8a72;&#x671f;&#x7d50;&#x675f;&#x6642;&#x5c07;&#x53ef;&#x7372;&#x5f97;1000&#x7684;&#x9000;&#x8cbb;" ID="ID_1584274739" CREATED="1547962041988" MODIFIED="1548290806620">
<font BOLD="false"/>
</node>
</node>
</node>
<node TEXT="&#x6bd4;&#x8cfd;&#x898f;&#x5247;" POSITION="right" ID="ID_637782838" CREATED="1550119594449" MODIFIED="1550119600939">
<edge COLOR="#7c0000"/>
<node TEXT="&#x904b;&#x52d5;&#x8cfd;&#x7a0b;&#x898f;&#x5283;" ID="ID_662751309" CREATED="1550119601671" MODIFIED="1550119623005"/>
<node TEXT="&#x96fb;&#x529b;&#x9435;&#x4eba;&#x99ac;&#x62c9;&#x677e;" ID="ID_286763558" CREATED="1550119623443" MODIFIED="1550377890228">
<node TEXT="&#x4ee5;&#x6708;&#x70ba;&#x55ae;&#x4f4d;&#xff0c;&#x6bcf;&#x500b;&#x6708;&#x53d6;&#x7576;&#x6708;&#x4efd;&#x96fb;&#x529b;&#x91cc;&#x7a0b;&#x6578;&#x6700;&#x9ad8;&#x8005;&#x70ba;&#x512a;&#x52dd;&#x8005;&#xff0c;" ID="ID_360642099" CREATED="1550119762562" MODIFIED="1550119817036"/>
<node TEXT="&#x734e;&#x91d1;&#x7684;&#x91d1;&#x984d;&#x56fa;&#x5b9a;" ID="ID_749700386" CREATED="1550119817254" MODIFIED="1550119838856"/>
</node>
<node TEXT="&#x8010;&#x529b;&#x8d85;&#x4eba;&#x5927;&#x6a02;&#x900f;" ID="ID_1401482145" CREATED="1550119732008" MODIFIED="1550377896526">
<node TEXT="&#x9023;&#x7e8c;&#x53c3;&#x8cfd;&#x4e09;&#x500b;&#x6708;&#x4ee5;&#x4e0a;&#x4e26;&#x4e14;&#x904b;&#x52d5;&#x91cf;&#x548c;&#x6e96;&#x6642;&#x5ea6;&#x9054;&#x5230;&#x6a19;&#x6e96;&#x7684;&#x5ba2;&#x6236;&#x53ef;&#x4ee5;&#x53c3;&#x52a0;&#x62bd;&#x734e;" ID="ID_1586767210" CREATED="1550119841327" MODIFIED="1550119958087"/>
<node TEXT="&#x4ee5;&#x9078;&#x865f;&#x65b9;&#x5f0f;&#x62bd;&#x734e;&#xff0c;&#x5171;&#x6709;&#x516b;&#x7d44;&#x6578;&#x5b57;&#xff0c;&#x53c3;&#x8cfd;&#x8005;&#x53ef;&#x81ea;&#x884c;&#x9078;&#x865f;&#x6216;&#x662f;&#x7531;&#x7cfb;&#x7d71;&#x81ea;&#x884c;&#x7522;&#x751f;" ID="ID_887350164" CREATED="1550378802938" MODIFIED="1550378886299"/>
<node TEXT="&#x5728;&#x4e2d;&#x734e;&#x4e4b;&#x524d;&#xff0c;&#x6bcf;&#x4e09;&#x500b;&#x9054;&#x6a19;&#x6708;&#x4efd;&#x589e;&#x52a0;&#x4e00;&#x7d44;&#x62bd;&#x734e;&#x865f;&#x78bc;&#xff0c;&#x7b49;&#x65bc;&#x53c3;&#x8cfd;&#x8d8a;&#x4e45;&#x4e2d;&#x734e;&#x6a5f;&#x7387;&#x8d8a;&#x5927;" ID="ID_1472288724" CREATED="1550378673015" MODIFIED="1550378796594"/>
<node TEXT="&#x53c3;&#x52a0;&#x8005;&quot;&#x6e96;&#x6642;&#x5230;&#x6307;&#x5b9a;&#x5730;&#x9ede;&#x53c3;&#x8cfd;&quot;&#x3001;&quot;&#x9080;&#x8acb;&#x4e00;&#x4eba;&#x4ee5;&#x4e0a;&#x53c3;&#x52a0;&quot;&#x3001;&quot;&#x904b;&#x52d5;&#x9054;&#x5230;&#x516c;&#x5b9a;&#x6700;&#x4f4e;&#x904b;&#x52d5;&#x91cf;&quot;&#x6642;&#x90fd;&#x6703;&#x7372;&#x5f97;&#x52a0;&#x6210;&#x9ede;&#x6578;" ID="ID_135199470" CREATED="1550120087330" MODIFIED="1550120215185"/>
<node TEXT="&#x734e;&#x91d1;&#x7684;&#x8a08;&#x7b97;&#x70ba;&#x57fa;&#x790e;&#x734e;&#x91d1;*&#x52a0;&#x6210;&#x9ede;&#x6578;" ID="ID_1291208950" CREATED="1550119959728" MODIFIED="1550120003483"/>
<node TEXT="&#x62bd;&#x4e2d;&#x7684;&#x5ba2;&#x6236;&#x4e4b;&#x52a0;&#x6210;&#x9ede;&#x6578;&#x5c07;&#x6703;&#x6b78;&#x96f6;" ID="ID_1099276162" CREATED="1550120223921" MODIFIED="1550120266754"/>
<node TEXT="&#x5982;&#x679c;&#x4e2d;&#x540c;&#x4e00;&#x734e;&#x9805;&#x8005;&#x8d85;&#x904e;&#x984d;&#x5b9a;&#x4eba;&#x6578;&#xff0c;&#x4ee5;&#x982d;&#x734e;&#x53ea;&#x6709;&#x4e00;&#x4eba;&#x70ba;&#x4f8b;&#xff0c;&#x4e09;&#x4eba;&#x4e2d;&#x734e;&#x6642;&#x53ea;&#x53d6;&#x52a0;&#x4e58;&#x9ede;&#x6578;(&#x904b;&#x52d5;&#x8868;&#x73fe;&#x6210;&#x7e3e;)&#x6700;&#x9ad8;&#x7684;&#x90a3;&#x4e00;&#x4f4d;&#xff0c;&#x8b93;&#x904b;&#x52d5;&#x7af6;&#x8cfd;&#x7684;&#x6027;&#x8cea;&#x5927;&#x904e;&#x6478;&#x5f69;&#x7684;&#x6027;&#x8cea;" ID="ID_1395517664" CREATED="1550378920067" MODIFIED="1550379111171"/>
<node TEXT="&#x672a;&#x4e2d;&#x734e;&#x7684;&#x5ba2;&#x6236;&#x4e4b;&#x52a0;&#x6210;&#x9ede;&#x6578;&#x6703;&#x7e7c;&#x7e8c;&#x7d2f;&#x7a4d;&#xff0c;&#x8b93;&#x5ba2;&#x6236;&#x6709;&#x66f4;&#x5927;&#x7684;&#x52d5;&#x529b;&#x7e7c;&#x7e8c;&#x8a02;&#x8cfc;&#x670d;&#x52d9;" ID="ID_1773572009" CREATED="1550120267332" MODIFIED="1550120338181"/>
</node>
</node>
<node TEXT="&#x786c;&#x9ad4;&#x9700;&#x6c42;" POSITION="right" ID="ID_1861946570" CREATED="1545553424568" MODIFIED="1545553437358">
<edge COLOR="#007c00"/>
<node TEXT="&#x6d3b;&#x52d5;&#x5834;&#x5730;" ID="ID_705892240" CREATED="1545553444363" MODIFIED="1545553465241">
<node TEXT="&#x79df;&#x501f;&#x5065;&#x8eab;&#x623f;or&#x7a7a;&#x6a13;&#x5c64;" ID="ID_656733314" CREATED="1545553466665" MODIFIED="1545553501997"/>
<node TEXT="&#x4f7f;&#x7528;&#x8ca8;&#x6ac3;&#x5c4b;&#x6539;&#x88dd;" ID="ID_1203372654" CREATED="1545553503715" MODIFIED="1545553526652"/>
</node>
<node TEXT="&#x6d3b;&#x52d5;&#x8a2d;&#x5099;&#xa;(&#x5168;&#x90e8;&#x6539;&#x88dd;&#x6210;&#x62bd;&#x6c34;&#x5e6b;&#x6d66;)" ID="ID_835965796" CREATED="1545553530817" MODIFIED="1547773051121">
<node TEXT="&#x98db;&#x8f2a;&#x6a5f;" ID="ID_1873859739" CREATED="1545553545409" MODIFIED="1545553555725">
<node TEXT="&#x8f49;&#x8ef8;&#x7684;&#x8ca0;&#x8f09;&#x6539;&#x70ba;&quot;&#x62bd;&#x6cb9;&#x6a5f;&quot;&#x7684;&#x7d50;&#x69cb;" ID="ID_1902886106" CREATED="1547773074478" MODIFIED="1547773170381"/>
</node>
<node TEXT="&#x5212;&#x8239;&#x6a5f;" ID="ID_430342956" CREATED="1545553556197" MODIFIED="1545553560701">
<node TEXT="&#x6539;&#x88dd;&#x65b9;&#x6cd5;&#x540c;&#x98db;&#x8f2a;&#x6a5f;" ID="ID_241642167" CREATED="1547773173695" MODIFIED="1547773208770"/>
</node>
<node TEXT="&#x62c9;&#x529b;&#x7e69;" ID="ID_1568108823" CREATED="1545553561155" MODIFIED="1545553567210">
<node TEXT="&#x62c9;&#x529b;&#x7684;&#x8ca0;&#x8f09;&#x6539;&#x70ba;&#x8ca0;&#x58d3;&#x5e6b;&#x6d66;" ID="ID_1329638774" CREATED="1547773210910" MODIFIED="1547773286722"/>
</node>
<node TEXT="&#x8e0f;&#x6b65;&#x6a5f;" ID="ID_1181388680" CREATED="1545553577697" MODIFIED="1547773304990">
<node TEXT="&#x8e0f;&#x677f;&#x6539;&#x88dd;&#x6210;&#x8173;&#x8e0f;&#x5f0f;&#x62bd;&#x6c34;&#x6a5f;" ID="ID_128817219" CREATED="1547773306759" MODIFIED="1547773392752"/>
</node>
<node TEXT="&#x62f3;&#x64ca;&#x9776;" ID="ID_1451500750" CREATED="1547773403823" MODIFIED="1547773428561">
<node TEXT="&#x53ef;&#x52d5;&#x7684;&#x62f3;&#x64ca;&#x9776;&#x548c;&#x6b63;&#x58d3;&#x5e6b;&#x6d66;&#x9023;&#x901a;&#xff0c;&#x5c07;&#x62f3;&#x64ca;&#x529b;&#x9053;&#x8f49;&#x5316;&#x6210;&#x63a8;&#x52d5;&#x6c34;&#x7684;&#x52d5;&#x529b;" ID="ID_617457819" CREATED="1547773429487" MODIFIED="1547773534881"/>
</node>
<node TEXT="&#x58fa;&#x9234;/&#x555e;&#x9234;" ID="ID_1969290987" CREATED="1547773591499" MODIFIED="1550283492999">
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x8209;&#x9ad8;&#x5f8c;&#x653e;&#x7f6e;&#x5728;&#x5e6b;&#x6d66;&#x7684;&#x58d3;&#x687f;&#xff0c;&#x58d3;&#x687f;&#x88ab;&#x63a8;&#x5230;&#x5e95;&#x4ee5;&#x5f8c;&#x6ed1;&#x843d;&#x56de;&#x5230;&#x539f;&#x4f4d;" ID="ID_96648151" CREATED="1547773610588" MODIFIED="1550283633591"/>
</node>
</node>
<node TEXT="&#x9644;&#x5c6c;&#x5132;&#x80fd;&#x8a2d;&#x5099;" ID="ID_721589129" CREATED="1547944803947" MODIFIED="1547944844650">
<node TEXT="&#x5927;&#x9762;&#x7a4d;&#x5c4b;&#x9802;" ID="ID_791365122" CREATED="1547944845827" MODIFIED="1547944861582">
<node TEXT="&#x8a2d;&#x7f6e;&#x4fbf;&#x5b9c;&#x7684;&#x92c1;&#x7b94;&#x7d19;&#x53cd;&#x5c04;&#x93e1;&#xff0c;&#x5c07;&#x5149;&#x7dda;&#x96c6;&#x4e2d;&#x5230;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x96c6;&#x71b1;&#x69fd;&#xff0c;&#x9a45;&#x52d5;&#x5e6b;&#x6d66;&#x4f86;&#x62bd;&#x6c34;" ID="ID_1919687377" CREATED="1547944863960" MODIFIED="1547944958286"/>
</node>
<node TEXT="&#x9ad8;&#x98a8;&#x529b;&#x5730;&#x5340;" ID="ID_1903679533" CREATED="1547944960067" MODIFIED="1547944969586">
<node TEXT="&#x8a2d;&#x7f6e;&#x5782;&#x76f4;&#x5f0f;&#x98a8;&#x8eca;&#xff0c;&#x540c;&#x6a23;&#x4ee5;&#x6c34;&#x4f4d;&#x80fd;&#x65b9;&#x5f0f;&#x5132;&#x80fd;" ID="ID_1661782797" CREATED="1547944970852" MODIFIED="1547945037920"/>
</node>
<node TEXT="&#x71b1;&#x6c34;&#x69fd;" ID="ID_987346628" CREATED="1549674862918" MODIFIED="1549674874330">
<node TEXT="&#x70ba;&#x7a7a;&#x8abf;&#x7cfb;&#x7d71;&#x8207;&#x592a;&#x967d;&#x80fd;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x51b7;&#x537b;&#x6c34;&#x7684;&#x96c6;&#x4e2d;&#x69fd;&#xff0c;&#x5927;&#x91cf;&#x7684;&#x5ee2;&#x71b1;&#x53ef;&#x4ee5;&#x5145;&#x7576;&#x76e5;&#x6d17;&#x7528;&#x7684;&#x71b1;&#x6c34;" ID="ID_615663276" CREATED="1549674875159" MODIFIED="1549674944925"/>
</node>
<node TEXT="&quot;&#x4e0d;&quot;&#x4f7f;&#x7528;&#x592a;&#x967d;&#x80fd;&#x677f;&#xff0c;&#x56e0;&#x70ba;&#x5176;&#x4fdd;&#x990a;&#x4e0d;&#x6613;&#x4e14;&#x990a;&#x8b77;&#x6280;&#x8853;&#x548c;&#x5efa;&#x69cb;&#x6210;&#x672c;&#x6975;&#x9ad8;&#xff0c;&#x800c;&#x4e14;&#x6703;&#x5206;&#x6563;&#x96fb;&#x529b;&#x7522;&#x751f;&#x8207;&#x8f38;&#x9001;&#x7684;&#x9014;&#x5f91;" ID="ID_1331785428" CREATED="1547945080245" MODIFIED="1547945242727"/>
</node>
<node TEXT="&#x7db2;&#x8def;&#x8a2d;&#x5099;/&#x96fb;&#x8a71;&#x7e3d;&#x6a5f;&#x8a2d;&#x5099;" ID="ID_772230489" CREATED="1545553587525" MODIFIED="1545553617684"/>
</node>
<node TEXT="&#x4eba;&#x529b;&#x9700;&#x6c42;" POSITION="right" ID="ID_125243513" CREATED="1545553621135" MODIFIED="1545553627526">
<edge COLOR="#7c007c"/>
<node TEXT="&#x8a2d;&#x5099;&#x7ba1;&#x7406;&#x54e1;" ID="ID_1653423642" CREATED="1545553628963" MODIFIED="1545553668270"/>
<node TEXT="&#x5834;&#x5730;&#x7ba1;&#x7406;&#x54e1;" ID="ID_20158108" CREATED="1545553668520" MODIFIED="1545553679900"/>
<node TEXT="&#x5ba3;&#x50b3;&#x90e8;&#x9580;" ID="ID_1262493586" CREATED="1545553683635" MODIFIED="1545553691524"/>
<node TEXT="&#x7db2;&#x7ad9;&#x7ba1;&#x7406;&#x90e8;&#x9580;" ID="ID_1898585757" CREATED="1545553699810" MODIFIED="1545553710840"/>
</node>
<node TEXT="&#x6280;&#x8853;&#x9700;&#x6c42;" POSITION="right" ID="ID_1036264379" CREATED="1545553721971" MODIFIED="1545553727455">
<edge COLOR="#7c7c00"/>
<node TEXT="&#x4e00;&#x500b;&#x80fd;&#xff62;&#x986f;&#x793a;&#x53bb;&#x6c59;&#x6210;&#x6548;&#xff63;&#x7684;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;&#x6a5f;" ID="ID_1701706950" CREATED="1545553728506" MODIFIED="1545553805299"/>
<node TEXT="&#x6539;&#x88dd;&#x6210;&#x62bd;&#x6c34;&#x6a5f;&#x7684;&#x904b;&#x52d5;&#x8a2d;&#x5099;" ID="ID_1151253426" CREATED="1545553805737" MODIFIED="1547944088792"/>
<node TEXT="&#x96fb;&#x529b;&#x5132;&#x85cf;&#x7cfb;&#x7d71;" ID="ID_1701111466" CREATED="1545553839921" MODIFIED="1545553895695">
<node TEXT="&#x4f7f;&#x7528;&#x653e;&#x5728;&#x9ad8;&#x8655;&#x7684;&#x6c34;&#x69fd;&#x5132;&#x5b58;&#x4e26;&#x4e14;&#x96c6;&#x4e2d;&#x80fd;&#x91cf;&#xff0c;&#x6574;&#x500b;&#x6d3b;&#x52d5;&#x6703;&#x5834;&#x53ea;&#x8a2d;&#x7f6e;&#x4e00;&#x500b;&#x4e3b;&#x8981;&#x7684;&#x767c;&#x96fb;&#x6a5f;(&#x8996;&#x6c34;&#x982d;&#x9ad8;&#x5ea6;&#x4f86;&#x9078;&#x64c7;&#x767c;&#x96fb;&#x6a5f;&#x7a2e;&#x985e;)" ID="ID_1031679946" CREATED="1547943998535" MODIFIED="1550284654481"/>
<node TEXT="&#x6c34;&#x4f4d;&#x80fd;&#x5bb9;&#x6613;&#x5132;&#x5b58;&#x4e14;&#x5132;&#x6c34;&#x8a2d;&#x5099;&#x9060;&#x8f03;&#x5132;&#x96fb;&#x8a2d;&#x5099;&#x7c21;&#x55ae;&#x800c;&#x4fbf;&#x5b9c;&#xff0c;&#x552f;&#x4e00;&#x7684;&#x554f;&#x984c;&#x662f;&#x9ad4;&#x7a4d;&#x548c;&#x91cd;&#x91cf;&#xff0c;&#x53ef;&#x4ee5;&#x7528;&#x62c9;&#x9ad8;&#x6c34;&#x982d;&#x9ad8;&#x5ea6;&#x4f86;&#x514b;&#x670d;" ID="ID_849828468" CREATED="1547944291239" MODIFIED="1550117817629"/>
<node TEXT="&#x4e3b;&#x767c;&#x96fb;&#x6a5f;&#x8996;&#x6703;&#x5834;&#x7684;&#x96fb;&#x529b;&#x9700;&#x6c42;&#x72c0;&#x6cc1;&#x4f86;&#x555f;&#x52d5;&#xff0c;&#x4f4d;&#x65bc;&#x9ad8;&#x8655;&#x7684;&#x6c34;&#x982d;&#x6c34;&#x69fd;&#x51fa;&#x6c34;&#x95a5;&#x9580;&#x53ef;&#x4ee5;&#x6309;&#x7167;&#x767c;&#x96fb;&#x7684;&#x9700;&#x6c42;&#x91cf;&#x4f86;&#x6539;&#x8b8a;&#x6d41;&#x91cf;&#xff0c;&#x4f7f;&#x767c;&#x96fb;&#x7684;&#x6548;&#x7387;&#x6700;&#x5927;&#x5316;" ID="ID_1013711000" CREATED="1547944394282" MODIFIED="1547944595523"/>
<node TEXT="&#x4e0d;&#x9700;&#x8981;&#x70ba;&#x5404;&#x7a2e;&#x4e0d;&#x540c;&#x7684;&#x904b;&#x52d5;&#x8a2d;&#x8a08;&#x7d50;&#x69cb;&#x8907;&#x96dc;&#x7684;&#x767c;&#x96fb;&#x8a2d;&#x5099;&#xff0c;&#xa;&#x66f4;&#x4e0d;&#x9700;&#x8981;&#x5728;&#x6bcf;&#x4e00;&#x500b;&#x5668;&#x6750;&#x8a2d;&#x7f6e;&#x767c;&#x96fb;&#x6a5f;&#xff0c;&#x964d;&#x4f4e;&#x8a2d;&#x5099;&#x6210;&#x672c;" ID="ID_437352748" CREATED="1547944615025" MODIFIED="1547944727872"/>
</node>
</node>
<node TEXT="&#x8cbb;&#x7528;&#x8a08;&#x7b97;" POSITION="right" ID="ID_229216314" CREATED="1547945337399" MODIFIED="1547945347481">
<edge COLOR="#00ffff"/>
<node TEXT="&#x6210;&#x672c;" ID="ID_1745661957" CREATED="1547945348372" MODIFIED="1547945390040">
<node TEXT="&#x5ba3;&#x50b3;&#x8cbb;&#x7528;" ID="ID_1088037770" CREATED="1547945390878" MODIFIED="1547945398095"/>
<node TEXT="&#x4eba;&#x4e8b;&#x8cbb;&#x7528;" ID="ID_118840434" CREATED="1547945398411" MODIFIED="1547945409317"/>
<node TEXT="&#x5834;&#x5730;&#x79df;&#x91d1;" ID="ID_342976986" CREATED="1547945409712" MODIFIED="1547945415382"/>
<node TEXT="&#x8a2d;&#x5099;&#x8cbb;&#x7528;" ID="ID_1287479429" CREATED="1547945415554" MODIFIED="1547945419490"/>
<node TEXT="&#x7d66;&#x4e88;&#x512a;&#x52dd;&#x8005;&#x7684;&#x734e;&#x91d1;" ID="ID_674115224" CREATED="1550117919721" MODIFIED="1550117953534"/>
</node>
<node TEXT="&#x6536;&#x5165;" ID="ID_305596983" CREATED="1547945494765" MODIFIED="1547945499574">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x7684;&#x53c3;&#x52a0;&#x8cbb; - &#x8cfd;&#x5f8c;&#x9054;&#x6a19;&#x7684;&#x9000;&#x8cbb;" ID="ID_411532505" CREATED="1547945500352" MODIFIED="1550117918367"/>
<node TEXT="&#x5ee3;&#x544a;&#x5ee0;&#x5546;&#x8d0a;&#x52a9;&#x8cbb;" ID="ID_921159486" CREATED="1547945522913" MODIFIED="1547945544989"/>
<node TEXT="&#x9644;&#x8a2d;&#x7926;&#x6cc9;&#x6c34;/&#x904b;&#x52d5;&#x98f2;&#x6599;&#x7ad9;&#x92b7;&#x552e;&#x6536;&#x5165;" ID="ID_619479606" CREATED="1548291235936" MODIFIED="1548291268813"/>
</node>
</node>
<node TEXT="&#x9650;&#x5236;" POSITION="right" ID="ID_618582848" CREATED="1545553903052" MODIFIED="1545553913209">
<edge COLOR="#ff0000"/>
<node TEXT="&#x7d14;&#x4eba;&#x529b;&#x767c;&#x96fb;&#x4e0d;&#x53ef;&#x80fd;&#x6703;&#x6709;&#x5546;&#x696d;&#x767c;&#x96fb;&#x7684;&#x898f;&#x6a21;&#x548c;&#x6548;&#x76ca;&#xff0c;&#x6700;&#x591a;&#x53ea;&#x80fd;&#x81ea;&#x6211;&#x4f9b;&#x96fb;&#xff0c;&#x5728;&#x5ba3;&#x50b3;&#x6642;&#x4e0d;&#x80fd;&#x904e;&#x5ea6;&#x8a87;&#x5927;&#xff0c;" ID="ID_537486540" CREATED="1545553914313" MODIFIED="1550117971233"/>
<node TEXT="&#x9700;&#x8981;&#x5c0d;&#x7528;&#x96fb;&#x6236;&#x81ea;&#x884c;&#x67b6;&#x8a2d;&#x96fb;&#x529b;&#x7db2;&#x8def;&#x548c;&#x96fb;&#x8868;&#xff0c;&#x6210;&#x672c;&#x9ad8;" ID="ID_471302559" CREATED="1559105028496" MODIFIED="1559105092501"/>
</node>
<node TEXT="&#x7af6;&#x722d;&#x7b56;&#x7565;" POSITION="right" ID="ID_1915167636" CREATED="1550377950671" MODIFIED="1550377955926">
<edge COLOR="#00007c"/>
<node TEXT="&#x5438;&#x5f15;&#x5ba2;&#x6e90;" ID="ID_684994172" CREATED="1550377956786" MODIFIED="1550377962667">
<node TEXT="&#x62db;&#x52df;&#x5176;&#x4ed6;&#x4f7f;&#x7528;&#x8005;&#x540c;&#x6642;&#x9032;&#x884c;&#x904b;&#x52d5;&#x53ef;&#x4ee5;&#x7372;&#x5f97;&#x734e;&#x91d1;&#x52a0;&#x4e58;&#x548c;&#x9000;&#x8cbb;&#x9ede;&#x6578;&#xff0c;&#x8b93;&#x53c3;&#x8cfd;&#x8005;&#x7a4d;&#x6975;&#x9080;&#x8acb;&#x81ea;&#x5df1;&#x7684;&#x670b;&#x53cb;&#x548c;&#x89aa;&#x4eba;&#x53c3;&#x8cfd;" ID="ID_1646599537" CREATED="1550379147401" MODIFIED="1550379266818"/>
<node TEXT="&#x5b63;&#x7bc0;&#x6027;&#x6d3b;&#x52d5;" ID="ID_759382275" CREATED="1550760683042" MODIFIED="1550760691917">
<node TEXT="&#x5728;&#x7aef;&#x5348;&#x7bc0;&#x8209;&#x8fa6;&#x5212;&#x8239;&#x6a5f;&#x7684;&#x5212;&#x9f8d;&#x821f;&#x6bd4;&#x8cfd;" ID="ID_1883449854" CREATED="1550760692651" MODIFIED="1550760729078"/>
<node TEXT="" ID="ID_589071451" CREATED="1550760729234" MODIFIED="1550760729234"/>
</node>
</node>
<node TEXT="&#x7559;&#x4f4f;&#x9867;&#x5ba2;" ID="ID_387239581" CREATED="1550377963386" MODIFIED="1550377971335">
<node TEXT="&quot;&#x8010;&#x529b;&#x8d85;&#x4eba;&#x6a02;&#x900f;&#x734e;&quot;&#x6703;&#x8b93;&#x53c3;&#x8cfd;&#x8005;&#x6709;&#x4e0d;&#x65b7;&#x53c3;&#x52a0;&#x7684;&#x52d5;&#x529b;&#xff0c;&#x7576;&#x5176;&#x9054;&#x6a19;&#x7684;&#x671f;&#x6578;&#x8d8a;&#x591a;&#xff0c;&#x7d2f;&#x7a4d;&#x7684;&#x734e;&#x91d1;&#x52a0;&#x6210;&#x500d;&#x6578;&#x6703;&#x66f4;&#x9ad8;&#xff0c;&#x66f4;&#x96e3;&#x653e;&#x68c4;&#x7e7c;&#x7e8c;&#x53c3;&#x8cfd;" ID="ID_1363491077" CREATED="1550378382606" MODIFIED="1550760609466"/>
<node TEXT="&#x5728;&#x5404;&#x500b;&#x57ce;&#x5e02;&#x8a2d;&#x7f6e;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#xff0c;&#x8b93;&#x7d93;&#x5e38;&#x79fb;&#x52d5;&#x7684;&#x5ba2;&#x6236;&#x80fd;&#x5920;&#x8f15;&#x9b06;&#x914d;&#x5408;&#x8cfd;&#x7a0b;" ID="ID_1747779492" CREATED="1550378487628" MODIFIED="1550378542630"/>
</node>
<node TEXT="&#x589e;&#x52a0;&#x6536;&#x5165;" ID="ID_262713071" CREATED="1550377980583" MODIFIED="1550377999571">
<node TEXT="&#x4ee5;&#x74b0;&#x4fdd;&#x3001;&#x5065;&#x5eb7;&#x7684;&#x516c;&#x76ca;&#x5f62;&#x8c61;&#x5438;&#x5f15;&#x8d0a;&#x52a9;&#x5546;&#xff0c;&#x4f7f;&#x5176;&#x80fd;&#x5920;&#x9577;&#x671f;&#x7684;&#x7d66;&#x4e88;&#x8d0a;&#x52a9;&#x8cbb;&#x7528;" ID="ID_547538367" CREATED="1550378000715" MODIFIED="1550378075252"/>
<node TEXT="&#x7528;&#x8ca8;&#x6ac3;&#x5c4b;&#x642d;&#x5efa;&#x7684;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x548c;&#x6c34;&#x69fd;&#x5916;&#x89c0;&#x90fd;&#x662f;&#x53ef;&#x4ee5;&#x520a;&#x767b;&#x8d0a;&#x52a9;&#x5546;&#x5ee3;&#x544a;&#x7684;&#x7248;&#x9762;" ID="ID_1811638679" CREATED="1550378078037" MODIFIED="1550378129218"/>
<node TEXT="&#x4f4d;&#x5728;&#x5f37;&#x964d;&#x96e8;&#x6642;&#x6703;&#x6df9;&#x6c34;&#x7684;&#x5340;&#x57df;&#x53ef;&#x4ee5;&#x5c0d;&#x9644;&#x8fd1;&#x5e97;&#x5bb6;&#x548c;&#x4f4f;&#x6236;&#x5ba3;&#x50b3;&quot;&#x9632;&#x6d2a;&#x6c34;&#x69fd;&quot;&#xff0c;&#x5982;&#x679c;&#x8d0a;&#x52a9;&#x6d3b;&#x52d5;&#x7d93;&#x8cbb;&#x5c31;&#x6703;&#x8a2d;&#x7f6e;&#x5927;&#x5bb9;&#x91cf;&#x7684;&#x984d;&#x5916;&#x6c34;&#x69fd;&#xff0c;&#x5728;&#x5f37;&#x964d;&#x96e8;&#x767c;&#x751f;&#x6642;&#x7528;&#x96fb;&#x529b;&#x9a45;&#x52d5;&#x99ac;&#x9054;&#x4f86;&#x62bd;&#x8d70;&#x7a4d;&#x6c34;&#xff0c;&#x8b93;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x8b8a;&#x6210;&#x7dca;&#x6025;&#x7de9;&#x885d;&#x6d2a;&#x6c34;&#x7684;&#x8a2d;&#x65bd;&#xff0c;&#x9632;&#x7bc4;&#x6d2a;&#x6c34;&#x9020;&#x6210;&#x7684;&#x4fb5;&#x5bb3;&#x3002;" ID="ID_1799943337" CREATED="1550378129687" MODIFIED="1550378350699"/>
<node TEXT="&#x592a;&#x967d;&#x6eab;&#x6cc9;/&#x6e05;&#x6dbc;&#x57ce;&#x5e02;" ID="ID_332960895" CREATED="1550760942555" MODIFIED="1550761256310">
<node TEXT="&#x5982;&#x679c;&#x53cd;&#x5149;&#x677f;&#x7684;&#x92ea;&#x8a2d;&#x9762;&#x7a4d;&#x5920;&#x5927;&#xff0c;&#x6574;&#x500b;&#x793e;&#x5340;&#x5728;&#x590f;&#x5929;&#x6703;&#x56e0;&#x70ba;&#x767d;&#x5929;&#x7684;&#x8f3b;&#x5c04;&#x71b1;&#x8f38;&#x5165;&#x964d;&#x4f4e;&#x800c;&#x4f7f;&#x6574;&#x9ad4;&#x6eab;&#x5ea6;&#x4e0b;&#x964d;&#xff0c;&#x4e14;&#x51b7;&#x6c23;&#x6a5f;&#x7684;&#x904b;&#x8f49;&#x96fb;&#x529b;&#x9700;&#x6c42;&#x4e5f;&#x4e0b;&#x964d;&#xff0c;" ID="ID_948255934" CREATED="1550760963334" MODIFIED="1550761186343"/>
<node TEXT="&#x904b;&#x7528;&#x4e00;&#x90e8;&#x5206;&#x96fb;&#x529b;&#x9032;&#x4e00;&#x6b65;&#x628a;&#x71b1;&#x80fd;&#x6fc3;&#x7e2e;&#xff0c;&#x4f5c;&#x70ba;&#x6fa1;&#x5802;&#x7684;&#x6d17;&#x6fa1;&#x6c34;&#x71b1;&#x6e90;&#xff0c;&#x540d;&#x70ba;&#x592a;&#x967d;&#x6eab;&#x6cc9;&#xff0c;&#x4f5c;&#x70ba;&#x6536;&#x8cbb;&#x7684;&#x516c;&#x5171;&#x6fa1;&#x5802;" ID="ID_823051502" CREATED="1550761186765" MODIFIED="1559105357006"/>
<node TEXT="&#x6a19;&#x699c;&#x6d17;&#x6fa1;&#x6c34;&#x8d8a;&#x71b1;&#xff0c;&#x793e;&#x5340;&#x5c31;&#x8d8a;&#x51c9;" ID="ID_34022855" CREATED="1550761296482" MODIFIED="1552900090546"/>
</node>
<node TEXT="&#x9632;&#x868a;&#x597d;&#x9130;&#x5c45;" ID="ID_782986948" CREATED="1559105143096" MODIFIED="1559105218224">
<node TEXT="&#x5728;&#x6d3b;&#x52d5;&#x5834;&#x5730;&#x5468;&#x908a;&#x8a2d;&#x7f6e;&#x96fb;&#x5b50;&#x6355;&#x868a;&#x5668;&#xff0c;&#x904b;&#x7528;&#x4f7f;&#x7528;&#x8005;&#x904b;&#x52d5;&#x6642;&#x7522;&#x751f;&#x7684;&#x5927;&#x91cf;&#x4e8c;&#x6c27;&#x5316;&#x78b3;&#x5f15;&#x8a98;&#x868a;&#x5b50;&#xff0c;" ID="ID_1894034603" CREATED="1559105219099" MODIFIED="1559105428285"/>
<node TEXT="&#x4e3b;&#x8fa6;&#x55ae;&#x4f4d;&#x63d0;&#x4f9b;&#x57fa;&#x790e;&#x7684;&#x6355;&#x868a;&#x5668;&#x6a5f;&#x53f0;&#xff0c;&#x4ee5;&#x6bcf;&#x5468;&#x7684;&#x6ec5;&#x868a;&#x6210;&#x6548;&#x70ba;&#x5ba3;&#x50b3;&#xff0c;&#x5438;&#x5f15;&#x9644;&#x8fd1;&#x4f4f;&#x6236;&#x548c;&#x5718;&#x9ad4;&#x8d0a;&#x52a9;&#x8a2d;&#x7f6e;&#x984d;&#x5916;&#x6a5f;&#x53f0;&#xff0c;" ID="ID_1152078981" CREATED="1559105428613" MODIFIED="1559105517185"/>
<node TEXT="&#x4e3b;&#x8fa6;&#x55ae;&#x4f4d;&#x6703;&#x5728;&#x5b98;&#x65b9;&#x7db2;&#x7ad9;&#x548c;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x516c;&#x4f48;&#x6bcf;&#x4e00;&#x671f;&#x7684;&#x8d0a;&#x52a9;&#x4eba;&#x58eb;/&#x5718;&#x9ad4;&#x540d;&#x55ae;" ID="ID_1029513304" CREATED="1559105517576" MODIFIED="1559105597083"/>
</node>
</node>
</node>
<node TEXT="&#x6f5b;&#x5728;&#x5408;&#x4f5c;&#x5c0d;&#x8c61;" POSITION="right" ID="ID_1029227209" CREATED="1545553986945" MODIFIED="1545554003612">
<edge COLOR="#0000ff"/>
<node TEXT="Gogoro&#x96fb;&#x529b;&#x7ad9;" ID="ID_931033234" CREATED="1545554004523" MODIFIED="1545554023454"/>
<node TEXT="&#x9700;&#x8981;&#x74b0;&#x4fdd;&#x516c;&#x76ca;&#x5f62;&#x8c61;&#x7684;&#x5ee0;&#x5546;&#x548c;&#x5718;&#x9ad4;" ID="ID_582727556" CREATED="1545554109915" MODIFIED="1547945069305"/>
<node TEXT="&#x904b;&#x52d5;&#x7528;&#x54c1;&#x5ee0;&#x5546;" ID="ID_1652162820" CREATED="1547773711745" MODIFIED="1547773727637"/>
<node TEXT="&#x75be;&#x75c5;&#x610f;&#x5916;&#x96aa;&#x696d;&#x8005;" ID="ID_444330878" CREATED="1550284231048" MODIFIED="1552900151457">
<node TEXT="&#x58fd;&#x96aa;&#x696d;&#x8005;&#x6703;&#x5e0c;&#x671b;&#x88ab;&#x4fdd;&#x96aa;&#x4eba;&#x4e00;&#x76f4;&#x6d3b;&#x4e0b;&#x53bb;&#x3001;&#x4e0d;&#x505c;&#x7684;&#x7e73;&#x4fdd;&#x8cbb;&#xff0c;&#x800c;&#x4e14;&#x6700;&#x597d;&#x4e0d;&#x8981;&#x751f;&#x5927;&#x75c5;" ID="ID_1502196359" CREATED="1550284334603" MODIFIED="1550284439187"/>
<node TEXT="&#x5b9a;&#x671f;&#x904b;&#x52d5; + &#x547c;&#x5438;&#x65b0;&#x9bae;&#x7a7a;&#x6c23; + &#x6709;&#x5065;&#x5eb7;&#x7fd2;&#x6163;&#x7684;&#x670b;&#x53cb;&#x5708; + &#x6309;&#x6469;&#x653e;&#x9b06; = &#x5065;&#x5eb7;&#x9577;&#x58fd;" ID="ID_1252809238" CREATED="1550284237213" MODIFIED="1550284322034"/>
<node TEXT="&#x8b93;&#x58fd;&#x96aa;&#x696d;&#x8005;&#x8d0a;&#x52a9;&#x7d93;&#x8cbb;&#xff0c;&#x5c0d;&#x53d7;&#x4fdd;&#x4eba;&#x63d0;&#x4f9b;&#x53c3;&#x52a0;ACFit&#x7684;&#x512a;&#x60e0;&#xff0c;&#x589e;&#x52a0;&#x53c3;&#x8cfd;&#x8005;&#x4eba;&#x6578;&#x548c;&#x6d3b;&#x52d5;&#x898f;&#x6a21;" ID="ID_309072749" CREATED="1550284440547" MODIFIED="1550284529859"/>
</node>
<node TEXT="&#x9ad4;&#x80b2;&#x5b78;&#x9662;" ID="ID_613531023" CREATED="1550117981731" MODIFIED="1550117997685">
<node TEXT="&#x5229;&#x7528;&#x73fe;&#x6709;&#x7684;&#x5efa;&#x7bc9;&#x7269;&#x9ad8;&#x5ea6;&#xff0c;&#x53ef;&#x4ee5;&#x5c07;&#x4e0a;&#x65b9;&#x6c34;&#x69fd;&#x7684;&#x9ad8;&#x5ea6;&#x5927;&#x5e45;&#x63d0;&#x5347;" ID="ID_1565763431" CREATED="1550118096300" MODIFIED="1550118169834"/>
<node TEXT="&#x5b78;&#x6821;&#x5177;&#x6709;&#x5bec;&#x655e;&#x7684;&#x64cd;&#x5834;&#x548c;&#x5927;&#x9762;&#x7a4d;&#x7684;&#x5c4b;&#x9802;&#xff0c;&#x53ef;&#x4ee5;&#x92ea;&#x8a2d;&#x5927;&#x91cf;&#x53cd;&#x5149;&#x96c6;&#x71b1;&#x677f;&#x4f86;&#x9a45;&#x52d5;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x5c07;&#x6c34;&#x62bd;&#x81f3;&#x4e0a;&#x65b9;&#x6c34;&#x69fd;&#x4ee5;&#x5132;&#x5b58;&#x80fd;&#x91cf;&#xff0c;" ID="ID_201520271" CREATED="1550118002190" MODIFIED="1550118191397"/>
<node TEXT="&#x767c;&#x51fa;&#x7684;&#x96fb;&#x529b;&#x53ef;&#x4ee5;&#x76f4;&#x63a5;&#x4f9b;&#x61c9;&#x6821;&#x820d;" ID="ID_334621138" CREATED="1550118191664" MODIFIED="1550118216407"/>
<node TEXT="&#x9ad4;&#x80b2;&#x5b78;&#x9662;&#x7684;&#x5b78;&#x751f;&#x6709;&#x5404;&#x7a2e;&#x7684;&#x9ad4;&#x529b;&#x8a13;&#x7df4;&#x9700;&#x6c42;&#xff0c;&#x53ef;&#x4ee5;&#x6309;&#x7167;&#x4ed6;&#x5011;&#x7684;&#x9700;&#x6c42;&#x4f86;&#x8a02;&#x88fd;&#x8a13;&#x7df4;&#x8a2d;&#x65bd;&#xff0c;&#x4e00;&#x4f4d;&#x5b78;&#x751f;&#x7684;&#x8a13;&#x7df4;&#x662f;&#x4ee5;&#x5b78;&#x5e74;&#x70ba;&#x55ae;&#x4f4d;&#xff0c;&#x53ef;&#x4ee5;&#x6210;&#x70ba;&#x66f4;&#x9577;&#x671f;&#x800c;&#x7a69;&#x5b9a;&#x7684;&#x53c3;&#x8cfd;&#x8005;" ID="ID_48589044" CREATED="1550118216767" MODIFIED="1550118427615"/>
<node TEXT="&#x9ad4;&#x5c08;&#x5b78;&#x751f;&#x672c;&#x8eab;&#x5c31;&#x6709;&#x904b;&#x52d5;&#x7684;&#x9700;&#x8981;&#xff0c;&#x53c3;&#x52a0;ACFit&#x9084;&#x53ef;&#x4ee5;&#x70ba;&#x4ed6;&#x5011;&#x5e36;&#x4f86;&#x8d0f;&#x5f97;&#x734e;&#x91d1;&#x7684;&#x6a5f;&#x6703;&#xff0c;&#x7bc0;&#x80fd;&#x53c8;&#x6de8;&#x7a7a;&#x7684;&#x516c;&#x76ca;&#x6d3b;&#x52d5;&#x6027;&#x8cea;&#x66f4;&#x53ef;&#x4ee5;&#x4fc3;&#x9032;&#x5b78;&#x751f;&#x9032;&#x884c;&#x9ad4;&#x529b;&#x8a13;&#x7df4;&#x7684;&#x52d5;&#x6a5f;&#x548c;&#x6bc5;&#x529b;&#xff0c;" ID="ID_635036831" CREATED="1550118431131" MODIFIED="1550118740553"/>
</node>
<node TEXT="&#x6709;&#x5927;&#x9762;&#x7a4d;&#x5e73;&#x5766;&#x5c4b;&#x9802;&#x7684;&#x91cf;&#x8ca9;&#x5e97;(&#x5168;&#x806f;&#x3001;&#x5927;&#x6f64;&#x767c;)&#x6216;&#x662f;&#x4f4e;&#x6eab;&#x5009;&#x5eab;(&#x88d5;&#x5229;)" ID="ID_325693574" CREATED="1549675072770" MODIFIED="1549676600301">
<node TEXT="&#x5728;&#x5c4b;&#x9802;&#x92ea;&#x8a2d;&#x92c1;&#x7b94;&#x53cd;&#x5c04;&#x93e1;&#xff0c;&#x96c6;&#x4e2d;&#x592a;&#x967d;&#x5149;&#x7dda;&#x5230;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x4ee5;&#x767c;&#x96fb;&#xff0c;" ID="ID_227648761" CREATED="1549676620339" MODIFIED="1549676711948"/>
<node TEXT="&#x767d;&#x5929;&#x9032;&#x5165;&#x5efa;&#x7bc9;&#x7269;&#x5167;&#x7684;&#x592a;&#x967d;&#x8f3b;&#x5c04;&#x71b1;&#x80fd;&#x6703;&#x88ab;&#x5927;&#x5e45;&#x5ea6;&#x6e1b;&#x5c11;&#xff0c;&#x4f7f;&#x7a7a;&#x8abf;&#x7cfb;&#x7d71;&#x7684;&#x96fb;&#x529b;&#x9700;&#x6c42;&#x964d;&#x4f4e;&#xff0c;&#x540c;&#x6642;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x5132;&#x5b58;&#x7684;&#x80fd;&#x91cf;&#x53ef;&#x4ee5;&#x4f9b;&#x61c9;&#x7a7a;&#x8abf;&#x8207;&#x7167;&#x660e;&#x7cfb;&#x7d71;&#x7684;&#x7528;&#x96fb;&#xff0c;&#x5927;&#x5e45;&#x5ea6;&#x964d;&#x4f4e;&#x5e97;&#x9762;&#x7684;&#x71df;&#x904b;&#x6210;&#x672c;" ID="ID_1897239689" CREATED="1549676712308" MODIFIED="1550760563054"/>
</node>
</node>
<node TEXT="&#x64f4;&#x5f35;&#x767c;&#x5c55;&#x65b9;&#x5411;" POSITION="right" ID="ID_1304049696" CREATED="1547773851996" MODIFIED="1547773866588">
<edge COLOR="#00ff00"/>
<node TEXT="FreeLunch&#xa;&#x540c;&#x5fc3;&#x5354;&#x529b;&#x8cfa;&#x4e09;&#x9910;" ID="ID_174164268" CREATED="1549675195610" MODIFIED="1549675231364">
<node TEXT="&#x548c;&#x5168;&#x806f;&#x7b49;&#x751f;&#x9bae;&#x8d85;&#x5e02;&#x5408;&#x4f5c;&#xff0c;&#x8b93;&#x53c3;&#x52a0;&#x8005;&#x7d44;&#x968a;&#x4e26;&#x5728;&#x8a72;&#x968a;&#x4f0d;&#x9054;&#x5230;&#x8a2d;&#x5b9a;&#x7684;&#x6642;&#x5019;&#x53ef;&#x4ee5;&#x8d0f;&#x5f97;&#x514d;&#x8cbb;&#x7684;&#x4e09;&#x9910;" ID="ID_1823239735" CREATED="1549675232336" MODIFIED="1549675429076"/>
<node TEXT="&#x4ee5;&#x56db;&#x4eba;&#x70ba;&#x55ae;&#x4f4d;(&#x7d44;)&#xff0c;&#x53c3;&#x52a0;&#x968a;&#x4f0d;&#x9700;&#x8981;&#x5148;&#x7e73;&#x51fa;&#x4fdd;&#x8b49;&#x91d1;&#xff0c;&#x4e26;&#x4e14;&#x5728;&#x6d3b;&#x52d5;&#x7db2;&#x7ad9;&#x4e0a;&#x6a19;&#x8a3b;&#x9032;&#x884c;&#x6d3b;&#x52d5;&#x7684;&#x6642;&#x9593;&#x548c;&#x7ad9;&#x9ede;&#x4f4d;&#x7f6e;&#xff0c;&#x548c;&#x500b;&#x4eba;&#x8cfd;&#x4e0d;&#x4e00;&#x6a23;&#xff0c;&#x540c;&#x4e00;&#x5c0f;&#x7d44;&#x5fc5;&#x9808;&#x6e96;&#x6642;&#x5230;&#x540c;&#x4e00;&#x7ad9;&#x9ede;&#x9032;&#x884c;&#x6d3b;&#x52d5;&#xff0c;&#x81f3;&#x65bc;&#x6d3b;&#x52d5;&#x9805;&#x76ee;&#x5247;&#x4e0d;&#x62d8;&#xff0c;&#x53ea;&#x8981;&#x9054;&#x5230;&#x57fa;&#x672c;&#x904b;&#x52d5;&#x91cf;&#x4e26;&#x8d85;&#x904e;&#x4e8c;&#x5341;&#x4e94;&#x5206;&#x9418;&#x5373;&#x53ef;&#x9054;&#x6a19;" ID="ID_1412364477" CREATED="1549675429780" MODIFIED="1549675802447"/>
<node TEXT="&#x56db;&#x4eba;&#x5168;&#x54e1;&#x5230;&#x9f4a;&#x4e14;&#x9054;&#x6a19;&#x53ef;&#x4ee5;&#x7372;&#x5f97;&#x5b8c;&#x5168;&#x514d;&#x8cbb;&#x7684;&#x9910;&#x9ede;&#xff0c;&#x4e09;&#x4eba;&#x70ba;&#x534a;&#x50f9;&#x512a;&#x5f85;&#xff0c;&#x5169;&#x4eba;&#x70ba;&#x516b;&#x4e94;&#x6298;" ID="ID_1196226609" CREATED="1549675840249" MODIFIED="1549675937079"/>
<node TEXT="&#x4f9b;&#x61c9;&#x7684;&#x9910;&#x9ede;" ID="ID_1064785636" CREATED="1549675937501" MODIFIED="1549675957475">
<node TEXT="&#x5bb6;&#x5ead;&#x865f;&#x725b;&#x5976;/&#x8c46;&#x6f3f;/&#x512a;&#x683c;/&#x512a;&#x916a;&#x4e73;" ID="ID_764441931" CREATED="1549675958412" MODIFIED="1549676068301"/>
<node TEXT="&#x5bb6;&#x5ead;&#x865f;&#x5410;&#x53f8;/&#x5176;&#x4ed6;&#x9eb5;&#x5305;" ID="ID_1917911484" CREATED="1549675977927" MODIFIED="1549675996701"/>
<node TEXT="&#x9999;&#x8549;/&#x860b;&#x679c;/&#x5176;&#x4ed6;&#x6c34;&#x679c;" ID="ID_1054704326" CREATED="1549675996997" MODIFIED="1549676014463"/>
<node TEXT="&#x6c34;&#x716e;&#x86cb;" ID="ID_1311902381" CREATED="1549676014697" MODIFIED="1549676025393"/>
</node>
<node TEXT="&#x7372;&#x5229;" ID="ID_1819599691" CREATED="1549676097659" MODIFIED="1549676112913">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;" ID="ID_192515116" CREATED="1549676113726" MODIFIED="1549676125226">
<node TEXT="&#x5728;&#x9032;&#x884c;&#x904b;&#x52d5;&#x7684;&#x540c;&#x6642;&#x8cfa;&#x5230;&#x5065;&#x5eb7;&#x7684;&#x514d;&#x8cbb;&#x6b63;&#x9910;&#xff0c;&#x5728;&#x9ad8;&#x7269;&#x50f9;&#x7684;&#x5730;&#x5340;&#x6703;&#x6709;&#x5438;&#x5f15;&#x529b;" ID="ID_1813870780" CREATED="1549676125992" MODIFIED="1549676193736"/>
<node TEXT="&#x5728;&#x5fc3;&#x7406;&#x548c;&#x7d93;&#x6fdf;&#x8a98;&#x56e0;&#x7684;&#x523a;&#x6fc0;&#x4e0b;&#x66f4;&#x80fd;&#x5920;&#x6709;&#x7d00;&#x5f8b;&#x7684;&#x5b8c;&#x6210;&#x8cfd;&#x7a0b;&#xff0c;&#xa;&#x9054;&#x5230;&#x5065;&#x8eab;&#x6216;&#x6e1b;&#x91cd;&#x7684;&#x76ee;&#x6a19;" ID="ID_941226614" CREATED="1549676273530" MODIFIED="1549676375504"/>
<node TEXT="&#x589e;&#x9032;&#x5c0f;&#x7d44;&#x6210;&#x54e1;&#x9593;&#x7684;&#x5411;&#x5fc3;&#x529b;&#x548c;&#x611f;&#x60c5;" ID="ID_681647051" CREATED="1549676194126" MODIFIED="1549676269787"/>
</node>
<node TEXT="ACFit&#x4e3b;&#x8fa6;&#x8005;&#x65b9;" ID="ID_836735442" CREATED="1549676378223" MODIFIED="1549676484364">
<node TEXT="&#x589e;&#x52a0;&#x53c3;&#x8cfd;&#x8005;&#x7684;&#x4eba;&#x6578;&#xff0c;&#x5f97;&#x5230;&#x66f4;&#x591a;&#x53c3;&#x52a0;&#x8cbb;&#x8207;&#x76f8;&#x95dc;&#x6536;&#x5165;" ID="ID_635250991" CREATED="1549676383551" MODIFIED="1549676423490"/>
<node TEXT="&#x589e;&#x5f37;&#x53c3;&#x8cfd;&#x8005;&#x53c3;&#x52a0;&#x6d3b;&#x52d5;&#x7684;&#x6642;&#x9593;&#x548c;&#x5730;&#x9ede;&#x898f;&#x5f8b;&#x6027;" ID="ID_1466899183" CREATED="1549676423755" MODIFIED="1549676456224"/>
</node>
<node TEXT="&#x8d85;&#x5546;/&#x91cf;&#x8ca9;&#x5e97;&#x65b9;" ID="ID_158857305" CREATED="1549676484958" MODIFIED="1549676509248">
<node TEXT="&#x589e;&#x52a0;&#x5927;&#x898f;&#x683c;&#x5546;&#x54c1;&#x7684;&#x92b7;&#x552e;&#x984d;" ID="ID_1268846883" CREATED="1549676510217" MODIFIED="1549676537722"/>
<node TEXT="&#x589e;&#x52a0;&#x6f5b;&#x5728;&#x7684;&#x5ba2;&#x6e90;" ID="ID_471079652" CREATED="1549676538113" MODIFIED="1549676562812"/>
</node>
</node>
</node>
<node TEXT="&#x7121;&#x7159;&#x70ab;&#x5149;&#x82b1;&#x706b;&#x79c0;&#xa;&#x6f54;&#x6de8;&#x80fd;&#x6e90;&#x82b1;&#x71c8;&#x79c0;" ID="ID_852230067" CREATED="1550379366384" MODIFIED="1550379484573">
<node TEXT="&#x7531;&#x88dd;&#x8f09;RGB LED&#x5149;&#x6e90;&#x7684;&#x7121;&#x4eba;&#x6a5f;&#x5347;&#x7a7a;&#xff0c;&#x5728;&#x591c;&#x9593;&#x9032;&#x884c;&#x52d5;&#x614b;&#x7684;&#x5149;&#x5f71;&#x8868;&#x6f14;" ID="ID_1630361019" CREATED="1550379543521" MODIFIED="1550379634351"/>
<node TEXT="&#x5728;&#x7bc0;&#x6176;&#x65e5;&#x4ee5;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x767c;&#x51fa;&#x7684;&#x96fb;&#x4f86;&#x9ede;&#x4eae;LED&#x82b1;&#x71c8;" ID="ID_1568975775" CREATED="1550379485948" MODIFIED="1550379541552"/>
</node>
<node TEXT="&#x518d;&#x751f;&#x80fd;&#x6e90;&#x5065;&#x8eab;&#x516c;&#x5712;" ID="ID_322108495" CREATED="1547773867168" MODIFIED="1547773908216">
<node TEXT="&#x5728;&#x4e00;&#x500b;&#x6709;&#x5929;&#x7136;&#x9ad8;&#x4f4e;&#x5761;&#x5ea6;(20m&#x4ee5;&#x4e0a;)&#x7684;&#x5730;&#x5340;&#x5efa;&#x7acb;&#x56fa;&#x5b9a;&#x7684;&#x8a2d;&#x65bd;&#xff0c;&#xa;&#x9ad8;&#x8655;&#x70ba;&#x6c34;&#x7bb1;&#x9663;&#x5217;&#xa;&#x4f4e;&#x8655;&#x8a2d;&#x7f6e;&#x4e00;&#x500b;&#x96c6;&#x4e2d;&#x7684;&#x767c;&#x96fb;&#x6a5f;&#x548c;&#x7e3d;&#x96c6;&#x6c34;&#x6c60;&#xa;&#x5712;&#x5340;&#x6700;&#x5927;&#x7684;&#x5e73;&#x5766;&#x8179;&#x5730;&#x4f5c;&#x70ba;&#x5065;&#x8eab;&#x623f;&#x6240;&#x5728;&#x5730;&#xff0c;&#xa;&#x6574;&#x500b;&#x5712;&#x5340;&#x9032;&#x884c;&#x4ee5;&#x4eba;&#x9020;&#x6fd5;&#x5730;&#x70ba;&#x4e3b;&#x984c;&#x7684;&#x7da0;&#x5316;&#x548c;&#x7f8e;&#x5316;" ID="ID_1967725948" CREATED="1547773908840" MODIFIED="1550283780230"/>
<node TEXT="&#x5065;&#x8eab;&#x623f;&#x548c;&#x516c;&#x5712;&#x4e3b;&#x8981;&#x63d0;&#x4f9b;&#x89c0;&#x5149;&#x6536;&#x5165;&#x548c;&#x4f86;&#x5ba2;&#xff0c;&#x767c;&#x96fb;&#x6548;&#x76ca;&#x4e0d;&#x5927;" ID="ID_1065293723" CREATED="1547774101071" MODIFIED="1550283802096"/>
<node TEXT="&#x5c4b;&#x9802;&#x548c;&#x7a7a;&#x66e0;&#x7a7a;&#x9593;&#x88dd;&#x8a2d;&#x6975;&#x4f4e;&#x6210;&#x672c;&#x7684;&#x92c1;&#x7b94;&#x53cd;&#x5c04;&#x93e1;&#xff0c;&#x5c07;&#x967d;&#x5149;&#x96c6;&#x4e2d;&#x5230;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x71b1;&#x6e90;&#x69fd;&#xff0c;&#x8b93;&#x592a;&#x967d;&#x80fd;&#x76f4;&#x63a5;&#x8b8a;&#x6210;&#x6c34;&#x4f4d;&#x80fd;&#x5132;&#x5b58;&#x8d77;&#x4f86;" ID="ID_51271393" CREATED="1547774181206" MODIFIED="1547774705258">
<node TEXT="DirtyCycle" ID="ID_1767205689" CREATED="1548592376315" MODIFIED="1548592382245">
<node TEXT="&#x548c;&#x50b3;&#x7d71;&#x7684;&#x5c01;&#x9589;&#x65af;&#x7279;&#x6797;&#x5faa;&#x74b0;&#x4e0d;&#x4e00;&#x6a23;&#xff0c;ACFit&#x7684;&#x65af;&#x7279;&#x6797;&#x84c4;&#x80fd;&#x7cfb;&#x7d71;&#x53ef;&#x4ee5;&#x7522;&#x751f;&#x7684;&#x80fd;&#x91cf;&#x9060;&#x8d85;&#x904e;&#x71b1;&#x6e90;&#x672c;&#x8eab;(&#x592a;&#x967d;&#x71b1;&#x80fd;&#x548c;&#x71c3;&#x71d2;&#x993f;&#x6c34;&#x6cb9;&#x71b1;&#x80fd;)&#xff0c;&#x56e0;&#x70ba;&#x88ab;&#x7576;&#x4f5c;&#x5132;&#x80fd;&#x5a92;&#x4ecb;&#x7684;&#x6c34;&#x672c;&#x8eab;&#x5c31;&#x662f;&#x51b7;&#x537b;&#x5291;&#xff0c;&#x4f4e;&#x6eab;&#x7684;&#x6c34;&#x88ab;&#x62bd;&#x5230;&#x9ad8;&#x8655;&#x6642;&#xff0c;&#x4e00;&#x90e8;&#x4efd;&#x7684;&#x6c34;&#x6703;&#x88ab;&#x5c0e;&#x5165;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x7684;&#x51b7;&#x69fd;&#xff0c;&#x5f37;&#x5316;&#x6eab;&#x5dee;&#x767c;&#x96fb;&#x7684;&#x5a01;&#x529b;" ID="ID_451695417" CREATED="1548592384085" MODIFIED="1548592795465"/>
<node TEXT="&#x6eab;&#x5ea6;&#x5927;&#x5e45;&#x5ea6;&#x5347;&#x9ad8;&#x7684;&#x71b1;&#x6c34;&#x53ef;&#x4ee5;&#x4f9b;&#x5712;&#x5340;&#x5167;&#x8a2d;&#x65bd;&#x4f7f;&#x7528;&#xff0c;&#x7576;&#x5176;&#x6eab;&#x5ea6;&#x53c8;&#x964d;&#x56de;&#x4f4e;&#x6eab;&#x6642;&#x4fbf;&#x548c;&#x4e3b;&#x6d41;&#x6c34;&#x69fd;&#x532f;&#x6d41;&#xff0c;" ID="ID_1936085374" CREATED="1548592796058" MODIFIED="1548592803631"/>
<node TEXT="&#x5728;&#x590f;&#x5b63;&#x6642;&#xff0c;&#x5728;&#x4e0b;&#x6e38;&#x6c34;&#x69fd;&#x8a2d;&#x7f6e;&#x4e00;&#x500b;&#x84b8;&#x767c;&#x69fd;&#xff0c;&#x7528;&#x4e0b;&#x6e38;&#x7684;&#x5404;&#x7a2e;&#x5ee2;&#x71b1;&#x4f86;&#x628a;&#x6c34;&#x84b8;&#x767c;&#xff0c;&#x6c34;&#x84b8;&#x6c23;&#x901a;&#x904e;&#x5782;&#x76f4;&#x7ba1;&#xff0c;&#x5728;&#x9ad8;&#x8655;&#x6c34;&#x69fd;&#x51dd;&#x7d50;&#xff0c;&#x5c07;&#x5ee2;&#x71b1;&#x8f49;&#x5316;&#x6210;&#x6c34;&#x4f4d;&#x80fd;" ID="ID_919715522" CREATED="1548592804881" MODIFIED="1548813987863"/>
</node>
</node>
<node TEXT="&#x5728;&#x5236;&#x9ad8;&#x9ede;&#x6216;&#x8fce;&#x98a8;&#x9762;&#x5efa;&#x7acb;&#x7e31;&#x8ef8;&#x5f0f;&#x98a8;&#x529b;&#x5e6b;&#x6d66;&#xff0c;&#x4e26;&#x4e14;&#x5728;&#x56db;&#x5468;&#x5efa;&#x7acb;&#x5373;&#x6642;&#x7684;&#x98a8;&#x529b;&#x5075;&#x6e2c;&#x7cfb;&#x7d71;&#xff0c;&#x96a8;&#x6642;&#x6539;&#x8b8a;&#x98a8;&#x529b;&#x5e6b;&#x6d66;&#x7684;&#x8ca0;&#x8f09;&#xff0c;&#x7528;&#x6700;&#x4f73;&#x7684;&#x6548;&#x7387;&#x8f49;&#x5316;&#x98a8;&#x529b;&#x6210;&#x70ba;&#x6c34;&#x4f4d;&#x80fd;" ID="ID_983895283" CREATED="1547774301567" MODIFIED="1548590686207">
<node TEXT="&#x548c;&#x56fa;&#x5b9a;&#x8ca0;&#x8f09;&#x7684;&#x98a8;&#x529b;&#x767c;&#x96fb;&#x6a5f;&#x4e0d;&#x540c;&#xff0c;&#x6bcf;&#x500b;&#x98a8;&#x529b;&#x6a21;&#x7d44;&#x5b8c;&#x5168;&#x4e0d;&#x9700;&#x8981;&#x6210;&#x672c;&#x6602;&#x8cb4;&#x7684;&#x767c;&#x96fb;&#x6a5f;&#xff0c;&#x53ea;&#x8981;&#x5805;&#x56fa;&#x8010;&#x7528;&#x7684;&#x5e6b;&#x6d66;&#x50b3;&#x52d5;&#x7d50;&#x69cb;&#x5c31;&#x80fd;&#x84c4;&#x80fd;&#xff0c;&#x800c;&#x4e14;&#x80fd;&#x5920;&#x8996;&#x98a8;&#x529b;&#x5927;&#x5c0f;&#x4f86;&#x64f7;&#x53d6;&#x6700;&#x5927;&#x7684;&#x80fd;&#x91cf;" ID="ID_1770889564" CREATED="1548593366669" MODIFIED="1548593486823"/>
</node>
<node TEXT="&#x6240;&#x6709;&#x80fd;&#x6e90;&#x8f38;&#x5165;&#x5168;&#x90e8;&#x4ee5;&#x6c34;&#x4f4d;&#x80fd;&#x5f62;&#x5f0f;&#x5132;&#x5b58;&#x8d77;&#x4f86;&#xff0c;&#x5404;&#x7528;&#x96fb;&#x6236;&#x4e8b;&#x5148;&#x63d0;&#x4ea4;&#x5176;&#x7528;&#x96fb;&#x7684;&#x6700;&#x5927;&#x8ca0;&#x8f09;&#x9700;&#x6c42;&#x548c;&#x7528;&#x96fb;&#x6642;&#x9593;&#xff0c;&#x6309;&#x7167;&#x4f7f;&#x7528;&#x8005;&#x7aef;&#x7684;&#x7528;&#x96fb;&#x9700;&#x6c42;&#x91cf;&#x4f86;&#x958b;&#x555f;&#x4e0a;&#x65b9;&#x6c34;&#x69fd;&#xff0c;&#x8da8;&#x52d5;&#x4f4e;&#x8655;&#x7684;&#x6c34;&#x529b;&#x767c;&#x96fb;&#x6a21;&#x7d44;&#xff0c;&#x4e0d;&#x7528;&#x50cf;&#x5927;&#x578b;&#x706b;&#x529b;&#x6216;&#x6838;&#x80fd;&#x767c;&#x96fb;&#x5ee0;&#x4e00;&#x6a23;&#x9700;&#x8981;&#x7a7a;&#x8f49;&#xff0c;&#x907f;&#x514d;&#x6d6a;&#x8cbb;&#x5927;&#x91cf;&#x80fd;&#x6e90;&#x5728;&#x5099;&#x8f09;&#x96fb;&#x529b;&#x4e0a;" ID="ID_1226396077" CREATED="1547774518248" MODIFIED="1550283882009"/>
<node TEXT="&#x5728;&#x516c;&#x5712;&#x7684;&#x5404;&#x500b;&#x65b9;&#x4f4d;&#x8a2d;&#x7f6e;gogoro&#x5145;&#x96fb;&#x7ad9;&#xff0c;&#x6536;&#x53d6;&#x79df;&#x91d1;&#x4e26;&#x4e14;&#x70ba;&#x5712;&#x5340;&#x5167;&#x5546;&#x5e97;&#x5438;&#x5f15;&#x9867;&#x5ba2;" ID="ID_1744008039" CREATED="1548291349556" MODIFIED="1548591173868"/>
<node TEXT="&#x5728;&#x516c;&#x5712;&#x5167;&#x8a2d;&#x7f6e;&#x5404;&#x7a2e;&#x5546;&#x5e97;&#xff0c;&#x6a19;&#x699c;&#x8a72;&#x5e97;&#x9762;&#x5b8c;&#x5168;&#x7531;&#x518d;&#x751f;&#x80fd;&#x6e90;&#x9a45;&#x52d5;" ID="ID_1847716330" CREATED="1548291417578" MODIFIED="1548590723792">
<node TEXT="&#x8d85;&#x5546;" ID="ID_860904447" CREATED="1548591584321" MODIFIED="1548591586411">
<node TEXT="&#x524d;&#x4f86;&#x62bd;&#x63db;&#x96fb;&#x6c60;&#x7684;&#x65c5;&#x5ba2;&#x53ef;&#x4ee5;&#x5728;&#x6b64;&#x4f11;&#x606f;&#x548c;&#x6d88;&#x8cbb;" ID="ID_1047188546" CREATED="1548592969035" MODIFIED="1548592994545"/>
</node>
<node TEXT="&#x9910;&#x5ef3;" ID="ID_1812222933" CREATED="1548590724412" MODIFIED="1548591582874">
<node TEXT="&#x5c31;&#x5730;&#x63d0;&#x7149;&#x993f;&#x6c34;&#x6cb9;&#x4e26;&#x4e14;&#x4f5c;&#x70ba;&#x4e3b;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x591c;&#x9593;&#x71c3;&#x6599;(&#x767d;&#x5929;&#x70ba;&#x65e5;&#x5149;&#x71b1;&#x80fd;)&#xff0c;&#x7576;&#x5929;&#x7684;&#x993f;&#x6c34;&#x6cb9;&#x5c31;&#x5728;&#x7576;&#x5929;&#x5168;&#x6578;&#x71d2;&#x6bc0;&#xff0c;&#x7dad;&#x8b77;&#x98df;&#x5b89;&#x4e26;&#x4e14;&#x7269;&#x76e1;&#x5176;&#x7528;&#xff0c;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x70ba;&quot;&#x5916;&#x71c3;&#x6a5f;&quot;&#xff0c;&#x993f;&#x6c34;&#x6cb9;&#x4e0d;&#x9700;&#x8981;&#x8655;&#x7406;&#x5230;&#x5167;&#x71c3;&#x6a5f;&#x5f15;&#x64ce;&#x7684;&#x7b49;&#x7d1a;&#x3002;" ID="ID_1633888139" CREATED="1548591329093" MODIFIED="1548591567424"/>
</node>
<node TEXT="&#x5496;&#x5561;&#x5e97;/&#x65e9;&#x9910;&#x5e97;" ID="ID_453134589" CREATED="1548591189483" MODIFIED="1548591306077">
<node TEXT="&#x7522;&#x751f;&#x7684;&#x5496;&#x5561;&#x6e23;/&#x9ec3;&#x8c46;&#x6e23;/&#x8336;&#x8449;&#x6e23;/&#x86cb;&#x6bbc;&#x53ef;&#x4ee5;&#x5c31;&#x5730;&#x5728;&#x5712;&#x5340;&#x9032;&#x884c;&#x5806;&#x80a5;&#xff0c;&#x597d;&#x6c27;&#x5806;&#x80a5;&#x53ef;&#x4ee5;&#x7522;&#x751f;&#x71b1;&#x80fd;&#xff0c;&#x9a45;&#x52d5;&#x5fae;&#x578b;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x9032;&#x884c;&#x62bd;&#x6c34;&#x84c4;&#x80fd;" ID="ID_431215113" CREATED="1548591193849" MODIFIED="1550119063942"/>
</node>
<node TEXT="&#x6309;&#x6469;&#x990a;&#x751f;&#x9928;" ID="ID_814493658" CREATED="1548590736692" MODIFIED="1548590759988">
<node TEXT="&#x4ee5;&#x5b8c;&#x5168;&#x6f54;&#x6de8;&#x7684;&#x96fb;&#x529b;&#x548c;&#x7a7a;&#x6c23;&#x70ba;&#x8a34;&#x6c42;&#x5438;&#x5f15;&#x65c5;&#x5ba2;" ID="ID_1367549191" CREATED="1550119092338" MODIFIED="1550119128876"/>
<node TEXT="&#x8a2d;&#x7f6e;&#x4ed8;&#x8cbb;&#x7684;&#x96fb;&#x52d5;&#x6309;&#x6469;&#x6905;" ID="ID_1025259898" CREATED="1550118934030" MODIFIED="1550118983115"/>
<node TEXT="&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x6703;&#x7522;&#x751f;&#x5927;&#x91cf;&#x88ab;&#x52a0;&#x71b1;&#x7684;&#x51b7;&#x537b;&#x6c34;&#xff0c;&#x5176;&#x4e2d;&#x4e00;&#x90e8;&#x4efd;&#x53ef;&#x4ee5;&#x7576;&#x4f5c;&#x6ce1;&#x8173;&#x6c34;&#x7684;&#x71b1;&#x6e90;?" ID="ID_259030336" CREATED="1548591604052" MODIFIED="1548591670647"/>
</node>
<node TEXT="&#x6d17;&#x8863;&#x5e97;" ID="ID_665729581" CREATED="1548591875312" MODIFIED="1548591879399">
<node TEXT="&#x5982;&#x679c;&#x8179;&#x5730;&#x5920;&#x5927;&#xff0c;&#x6574;&#x5408;&#x4e0b;&#x65b9;&#x6c34;&#x69fd;&#x8a2d;&#x7f6e;&#x529f;&#x80fd;&#x6027;&#x4eba;&#x5de5;&#x6ebc;&#x5730;&#xff0c;&#x7528;&#x690d;&#x7269;&#x548c;&#x7802;&#x77f3;&#x4f86;&#x6de8;&#x5316;&#x6d17;&#x8863;&#x5ee2;&#x6c34;&#xff0c;&#x7d93;&#x904e;&#x904e;&#x6ffe;&#x7684;&#x5ee2;&#x6c34;&#x5c31;&#x5145;&#x7576;&#x6574;&#x500b;&#x5712;&#x5340;&#x7684;&quot;&#x84c4;&#x80fd;&#x7528;&#x6c34;&quot;&#x548c;&quot;&#x704c;&#x6e89;&#x7528;&#x6c34;&quot;&#xff0c;&#x5728;&#x4e0a;&#x4e0b;&#x6c34;&#x69fd;&#x9593;&#x5faa;&#x74b0;" ID="ID_51632205" CREATED="1548591880679" MODIFIED="1548592159238"/>
<node TEXT="&#x84c4;&#x80fd;&#x7528;&#x6c34;&#x7d93;&#x904e;&#x8655;&#x7406;(&#x7528;&#x5ee2;&#x71b1;&#x84b8;&#x993e;)&#x4e4b;&#x5f8c;&#x53ef;&#x4ee5;&#x518d;&#x6b21;&#x6210;&#x70ba;&#x6d17;&#x8863;&#x5e97;&#x7684;&#x6c34;&#x6e90;" ID="ID_1967255798" CREATED="1548592167079" MODIFIED="1548592220944"/>
</node>
<node TEXT="&#x8cc7;&#x6e90;&#x7d71;&#x6574;&#x56de;&#x6536;" ID="ID_655815119" CREATED="1550283917905" MODIFIED="1550283926452">
<node TEXT="&#x904b;&#x7528;AI&#x7d71;&#x8a08;&#x4e26;&#x4e14;&#x5f59;&#x6574;&#x5404;&#x500b;&#x5546;&#x5e97;&#x7522;&#x751f;&#x7684;&#x5ee2;&#x68c4;&#x7269;&#xff0c;&#x7528;&#x6700;&#x6709;&#x6548;&#x7387;&#x7684;&#x65b9;&#x5f0f;&#x6536;&#x96c6;&#x4e26;&#x6574;&#x7406;&#x5f8c;&#x552e;&#x51fa;" ID="ID_484864606" CREATED="1550283927390" MODIFIED="1550284094556"/>
<node TEXT="&#x5e36;&#x4f86;&#x91d1;&#x9322;&#x6536;&#x5165;&#x53c8;&#x53ef;&#x4ee5;&#xff62;&#x6e1b;&#x5c11;&#x5783;&#x573e;&#x91cf;&#xff63;&#x70ba;&#x7279;&#x9ede;&#xff0c;&#x5438;&#x5f15;&#x9867;&#x5ba2;&#x4f86;&#x5712;&#x5340;&#x6d88;&#x8cbb;" ID="ID_669225516" CREATED="1550284105743" MODIFIED="1550284201950"/>
</node>
</node>
<node TEXT="&#x871c;&#x871c;&#x82b1;&#x5712;" ID="ID_87242216" CREATED="1559105741495" MODIFIED="1559105753644">
<node TEXT="&#x5728;&#x5712;&#x5340;&#x5167;&#x7a2e;&#x690d;&#x5404;&#x7a2e;&#x6709;&#x89c0;&#x8cde;&#x6216;&#x7d93;&#x6fdf;&#x50f9;&#x503c;&#x7684;&#x871c;&#x6e90;&#x690d;&#x7269;&#xff0c;&#x4e26;&#x4e14;&#x8a2d;&#x7f6e;&#x990a;&#x8702;&#x5834;&#xff0c;&#x5c07;&#x5712;&#x5340;&#x7684;&#x7576;&#x4f5c;&#x89c0;&#x5149;&#x8fb2;&#x5834;&#x4f86;&#x7d93;&#x71df;" ID="ID_662217379" CREATED="1559105754425" MODIFIED="1559105859596">
<node TEXT="&#x5916;&#x570d;&#x7a2e;&#x690d;&#x6ab8;&#x6aac;&#x6849;&#x8207;&#x6a1f;&#x6a39;&#x7b49;&#x53ef;&#x9a45;&#x5bb3;&#x87f2;&#x7684;&#x5927;&#x55ac;&#x6728;&#xff0c;&#x8207;&#x5c71;&#x80e1;&#x6912;&#x3001;&#x767d;&#x96de;&#x6cb9;&#x3001;&#x7d2b;&#x6a80;&#x7b49;&#x6a39;&#x7a2e;&#x642d;&#x914d;&#xff0c;&#x5730;&#x9762;&#x7a2e;&#x690d;&#x9b5a;&#x8165;&#x8349;&#x3001;&#x65f1;&#x91d1;&#x84ee;&#x3001;&#x96de;&#x5c4e;&#x85e4;&#x3001;&#x849c;&#x9999;&#x85e4;&#x7b49;&#x8010;&#x9670;&#x4e14;&#x6709;&#x5f37;&#x70c8;&#x6c23;&#x5473;&#x7684;&#x9a45;&#x87f2;&#x871c;&#x6e90;&#x690d;&#x7269;" ID="ID_1554311271" CREATED="1559105861221" MODIFIED="1559106325900"/>
<node TEXT="&#x904a;&#x5ba2;&#x7d93;&#x904e;&#x7684;&#x5730;&#x65b9;&#x7a2e;&#x690d;&#x6731;&#x69ff;&#x3001;&#x7f8e;&#x4eba;&#x8549;&#x3001;&#x6ce2;&#x65af;&#x83ca;&#x3001;&#x7d2b;&#x5b0c;&#x82b1;&#x3001;&#x91d1;&#x9b5a;&#x8349;&#x3001;&#x842c;&#x58fd;&#x83ca;&#x3001;&#x9577;&#x58fd;&#x82b1;&#x7b49;&#x89c0;&#x8cde;&#x6027;&#x8f03;&#x9ad8;&#x7684;&#x871c;&#x6e90;&#x690d;&#x7269;" ID="ID_412258083" CREATED="1559105953269" MODIFIED="1559106574656"/>
<node TEXT="&#x8702;&#x7bb1;&#x6240;&#x5728;&#x5730;&#x7a2e;&#x690d;&#x56db;&#x5b63;&#x90fd;&#x80fd;&#x958b;&#x82b1;&#x7684;&#x8349;&#x82b1;&#xff0c;&#x4ee5;&#x5782;&#x76f4;&#x5f0f;&#x7a2e;&#x690d;&#x6cd5;&#x589e;&#x52a0;&#x55ae;&#x4f4d;&#x9762;&#x7a4d;&#x5167;&#x7684;&#x82b1;&#x871c;&#x4f9b;&#x61c9;&#x91cf;" ID="ID_1920114337" CREATED="1559106190082" MODIFIED="1559106380044"/>
<node TEXT="&#x7a2e;&#x690d;&#x7d2b;&#x8607;&#x3001;&#x82ab;&#x837d;&#x3001;&#x76ca;&#x6bcd;&#x8349;&#x3001;&#x9999;&#x8702;&#x8349;&#x7b49;&#x6297;&#x87f2;&#x871c;&#x6e90;&#x4f5c;&#x7269;" ID="ID_563434167" CREATED="1559106425057" MODIFIED="1559106505690"/>
</node>
</node>
<node TEXT="&#x9632;&#x6d2a;&#x7de9;&#x885d;&#x7ad9;" ID="ID_1734315432" CREATED="1548590775410" MODIFIED="1548590807940">
<node TEXT="&#x6574;&#x500b;&#x5712;&#x5340;&#x64c1;&#x6709;&#x5927;&#x91cf;&#x9592;&#x7f6e;&#x7684;&#x6c34;&#x69fd;&#x5bb9;&#x91cf;&#xff0c;&#x5728;&#x5f37;&#x964d;&#x96e8;&#x548c;&#x98b1;&#x98a8;&#x4f86;&#x81e8;&#x6642;&#x53ef;&#x4ee5;&#x5c07;&#x6d2a;&#x6c34;&#x66ab;&#x6642;&#x6eef;&#x7559;&#xff0c;&#x5c0d;&#x9644;&#x8fd1;&#x7684;&#x90fd;&#x5e02;&#x793e;&#x5340;&#x6709;&#x6566;&#x89aa;&#x7766;&#x9130;&#x7684;&#x6548;&#x679c;" ID="ID_350395168" CREATED="1548590808760" MODIFIED="1548591856658"/>
<node TEXT="&#x5982;&#x679c;&#x4e0b;&#x6e38;&#x5730;&#x5340;&#x767c;&#x751f;&#x6c34;&#x60a3;&#xff0c;&#x8d85;&#x904e;&#x4e0b;&#x65b9;&#x6c34;&#x69fd;&#x7684;&#x5bb9;&#x91cf;&#xff0c;&#x53ef;&#x4ee5;&#x8abf;&#x52d5;&#x5e6b;&#x6d66;&#x5c07;&#x6c34;&#x62bd;&#x5230;&#x4e0a;&#x6e38;" ID="ID_1055986326" CREATED="1548592252502" MODIFIED="1548592328948"/>
<node TEXT="&#x7531;ACFit&#x516c;&#x53f8;&#x672c;&#x8eab;&#x8ca0;&#x8cac;&#x57fa;&#x672c;&#x5bb9;&#x91cf;&#xff0c;&#x5c0d;&#x5916;&#x62db;&#x6a19;&#x8d0a;&#x52a9;&#x5546;&#xff0c;&#x82e5;&#x8d0a;&#x52a9;&#x5546;&#x6350;&#x6b3e;&#x5e6b;&#x52a9;&#x5712;&#x5340;&#x71df;&#x904b;&#xff0c;&#x5c31;&#x6703;&#x4ee5;&#x8d0a;&#x52a9;&#x5546;&#x540d;&#x7fa9;&#x589e;&#x8a2d;&#x984d;&#x5916;&#x6d2a;&#x6c34;&#x6eef;&#x7559;&#x5bb9;&#x91cf;&#xff0c;&#x4e26;&#x4e14;&#x5c07;&#x53ef;&#x4ee5;&#x5370;&#x4e0a;&#x8d0a;&#x52a9;&#x5546;&#x5ee3;&#x544a;&#x548c;&#x5546;&#x6a19;&#x7684;&#x7dca;&#x6025;&#x6c34;&#x69fd;&#x653e;&#x7f6e;&#x5728;&#x5712;&#x5340;&#x7684;&#x986f;&#x773c;&#x8655;&#x4f5c;&#x70ba;&#x5ba3;&#x50b3;" ID="ID_1649290053" CREATED="1548591682613" MODIFIED="1550119257417"/>
</node>
<node TEXT="&#x529f;&#x80fd;&#x6027;&#x4eba;&#x5de5;&#x6fd5;&#x5730;" ID="ID_413003117" CREATED="1548593011656" MODIFIED="1548593019002">
<node TEXT="&#x8a2d;&#x7f6e;&#x4e3b;&#x8981;&#x76ee;&#x7684;&#x4e0d;&#x662f;&#x6062;&#x5fa9;&#x751f;&#x614b;&#xff0c;&#x800c;&#x662f;&#x5c07;&#x5404;&#x7a2e;&#x8f15;&#x5ea6;&#x6c59;&#x67d3;&#x7684;&#x6c11;&#x751f;&#x5ee2;&#x6c34;&#x8f49;&#x5316;&#x6210;&#x6e05;&#x6de8;&#x53ef;&#x5229;&#x7528;&#x7684;&#x72c0;&#x614b;&#xff0c;" ID="ID_705581595" CREATED="1548593019752" MODIFIED="1548593070610"/>
<node TEXT="&#x5404;&#x7a2e;&#x986f;&#x82b1;&#x6fd5;&#x5730;&#x690d;&#x7269;(&#x5e03;&#x888b;&#x84ee;/&#x6c34;&#x84d1;&#x8863;/&#x6148;&#x59d1;/&#x99ac;&#x978d;&#x85e4;/&#x7f8e;&#x4eba;&#x8549;/&#x99ac;&#x9f52;&#x83a7;/&#x7761;&#x84ee;/&#x840d;&#x84ec;&#x8349;)&#x53ef;&#x4ee5;&#x70ba;&#x5712;&#x5340;&#x589e;&#x6dfb;&#x7f8e;&#x89c0;&#x6027;&#xff0c;&#x5728;&#x82b1;&#x5b63;&#x5438;&#x5f15;&#x904a;&#x5ba2;" ID="ID_784826857" CREATED="1548593216775" MODIFIED="1550119459062"/>
<node TEXT="&#x5712;&#x5340;&#x5167;&#x7684;&#x6c34;&#x6703;&#x5f62;&#x6210;&#x4e00;&#x500b;&#x534a;&#x5c01;&#x9589;&#x5faa;&#x74b0;&#xff0c;&#x540c;&#x6a23;&#x5bb9;&#x7a4d;&#x7684;&#x6c34;&#x53ef;&#x4ee5;&#x5148;&#x88ab;&#x62ff;&#x4f86;&#x6d17;&#x8863;&#x670d;&#xff0c;&#x63a5;&#x4e0b;&#x4f86;&#x704c;&#x6e89;&#x6fd5;&#x5730;&#x5167;&#x7684;&#x690d;&#x7269;&#xff0c;&#x6700;&#x5f8c;&#x6210;&#x70ba;&#x6c96;&#x6d17;&#x5ec1;&#x6240;&#x7684;&#x6c34;&#x6e90;&#x6216;&#x662f;&#x9032;&#x5165;&#x84c4;&#x80fd;&#x6c34;&#x6c60;&#x6210;&#x70ba;&#x904b;&#x4f5c;&#x7528;&#x6c34;&#xff0c;&#x5927;&#x5e45;&#x5ea6;&#x6e1b;&#x5c11;&#x6c34;&#x5eab;&#x7684;&#x7528;&#x6c34;&#x9700;&#x6c42;" ID="ID_1452016157" CREATED="1548593071050" MODIFIED="1550119441303"/>
<node TEXT="&#x5728;&#x96e8;&#x5b63;&#x7684;&#x6642;&#x5019;&#x6536;&#x96c6;&#x7684;&#x96e8;&#x6c34;&#x548c;&#x4e0b;&#x6e38;&#x6d2a;&#x6c34;&#x7d93;&#x904e;&#x6fd5;&#x5730;&#x6de8;&#x5316;&#x4e4b;&#x5f8c;&#x53ef;&#x4ee5;&#x518d;&#x6b21;&#x5229;&#x7528;" ID="ID_1147931087" CREATED="1550119462983" MODIFIED="1550119521871"/>
<node TEXT="&#x904b;&#x4f5c;&#x7528;&#x6c34;&#x7d93;&#x904e;&#x5ee2;&#x71b1;&#x84b8;&#x993e;&#x5f8c;&#x53ef;&#x4ee5;&#x518d;&#x6b21;&#x6210;&#x70ba;&#x6d17;&#x8863;&#x7528;&#x6c34;" ID="ID_1998222421" CREATED="1550119524591" MODIFIED="1550119553912"/>
</node>
<node TEXT="&#x5bcc;&#x6c27;&#x578b;&#x5806;&#x80a5;&#x767c;&#x96fb;" ID="ID_651670524" CREATED="1550761393853" MODIFIED="1550761424163">
<node TEXT="&#x6574;&#x5408;&#x5712;&#x5340;&#x5167;&#x7684;&#x5e97;&#x8216;&#x548c;&#x9020;&#x666f;&#x690d;&#x7269;&#x7522;&#x751f;&#x7684;&#x6709;&#x6a5f;&#x5ee2;&#x68c4;&#x7269;&#xff0c;&#x5728;&#x9ad8;&#x6c27;&#x6c23;&#x5206;&#x58d3;&#x7684;&#x74b0;&#x5883;&#x4e0b;&#x9032;&#x884c;&#x9ad8;&#x901f;&#x5806;&#x80a5;&#x53cd;&#x61c9;&#xff0c;&#x7522;&#x751f;&#x7684;&#x5927;&#x91cf;&#x71b1;&#x80fd;&#x4f5c;&#x70ba;&#x4e2d;&#x5c0f;&#x578b;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x7684;&#x9a45;&#x52d5;&#x80fd;&#x91cf;&#xff0c;&#x767c;&#x96fb;&#x7684;&#x540c;&#x6642;&#x7522;&#x751f;&#x6709;&#x7528;&#x7684;&#x6709;&#x6a5f;&#x80a5;&#x3001;&#x4e26;&#x4e14;&#x505a;&#x5230;&#x5783;&#x573e;&#x6e1b;&#x91cf;&#xff0c;&#x6e1b;&#x5c11;&#x6eab;&#x5ba4;&#x6c23;&#x9ad4;&#xff0c;&#x4e00;&#x8209;&#x56db;&#x5f97;" ID="ID_1816442400" CREATED="1550761424820" MODIFIED="1550762320555"/>
<node TEXT="&#x53ad;&#x6c27;&#x5806;&#x80a5;&#x7522;&#x751f;&#x7684;&#x6cbc;&#x6c23;&#x9700;&#x8981;&#x812b;&#x786b;&#x8655;&#x7406;&#xff0c;&#x53ad;&#x6c27;&#x53cd;&#x61c9;&#x7de9;&#x6162;&#xff0c;&#x4e14;&#x7522;&#x751f;&#x7684;&#x904e;&#x7a0b;&#x4e2d;&#x6c23;&#x9ad4;&#x5e38;&#x6ef2;&#x6f0f;&#xff0c;&#x4e14;&#x9700;&#x8981;&#x5efa;&#x69cb;&#x71c3;&#x6c23;&#x8a2d;&#x5099;&#x624d;&#x80fd;&#x767c;&#x96fb;&#xff0c;&#x6210;&#x672c;&#x9ad8;&#x4f46;&#x662f;&#x56de;&#x6536;&#x6548;&#x76ca;&#x548c;&#x901f;&#x5ea6;&#x90fd;&#x7de9;&#x6162;" ID="ID_1904533803" CREATED="1550761626156" MODIFIED="1550761782373"/>
<node TEXT="&#x597d;&#x6c27;&#x5806;&#x80a5;&#x8207;&#x5176;&#x76f8;&#x53cd;&#xff0c;&#x901f;&#x5ea6;&#x6975;&#x9ad8;&#xff0c;&#x4e00;&#x5468;&#x5167;&#x5c31;&#x80fd;&#x5c07;&#x63a5;&#x8fd1;&#x4e00;&#x534a;&#x7684;&#x6709;&#x6a5f;&#x5ee2;&#x6599;&#x9ad4;&#x7a4d;&#x6d88;&#x8017;&#x6389;&#xff0c;&#x7522;&#x751f;&#x7684;&#x6c23;&#x9ad4;&#x4ee5;&#x55ae;&#x7d14;&#x7684;&#x4e8c;&#x6c27;&#x5316;&#x78b3;&#x70ba;&#x4e3b;&#xff0c;&#x904b;&#x7528;&#x5bc6;&#x9589;&#x5f0f;&#x7684;&#x6c23;&#x5bc6;&#x578b;&#x9ad8;&#x71b1;&#x5806;&#x80a5;&#x69fd;&#x53ef;&#x4ee5;&#x5c0d;&#x53cd;&#x61c9;&#x5806;&#x9032;&#x884c;&#x652a;&#x62cc;&#x548c;&#x5f37;&#x5236;&#x7d66;&#x6c27;/&#x63db;&#x6c23;&#xff0c;&#x8b93;&#x53cd;&#x61c9;&#x901f;&#x5ea6;&#x9054;&#x5230;&#x985b;&#x5cf0;&#xff0c;&#x6700;&#x5f8c;&#x5229;&#x7528;&#x8eab;&#x70ba;&#x5916;&#x71c3;&#x6a5f;&#x7684;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x4f86;&#x8403;&#x53d6;&#x5176;&#x71b1;&#x80fd;" ID="ID_39382236" CREATED="1550761897095" MODIFIED="1550762276927"/>
<node TEXT="&#x6c23;&#x5bc6;&#x578b;&#x9ad8;&#x71b1;&#x5806;&#x80a5;&#x69fd;" ID="ID_254930448" CREATED="1550761782889" MODIFIED="1550762061189">
<node TEXT="&#x6536;&#x96c6;&#x5712;&#x5340;&#x5167;&#x690d;&#x7269;&#x7522;&#x751f;&#x7684;&#x5927;&#x91cf;&#x6c27;&#x6c23;&#xff0c;&#x5f9e;&#x5806;&#x80a5;&#x69fd;&#x4e2d;&#x5fc3;&#x7684;&#x4e09;&#x89d2;&#x5207;&#x6599;&#x5200;&#x7a7a;&#x9699;&#x4e2d;&#x6392;&#x51fa;&#xff0c;&#x5f37;&#x5236;&#x704c;&#x5165;&#x5806;&#x80a5;&#x69fd;&#x5167;&#x7684;&#x53cd;&#x61c9;&#x5806;&#xff0c;&#x4e26;&#x4e14;&#x5c07;&#x6ea2;&#x51fa;&#x7684;&#x4e8c;&#x6c27;&#x5316;&#x78b3;&#x5ee2;&#x6c23;&#x5438;&#x5165;&#x6c34;&#x8349;/&#x85fb;&#x985e;&#x69fd;&#x5167;&#x5c07;&#x4e8c;&#x6c27;&#x5316;&#x78b3;&#x56fa;&#x5b9a;&#xff0c;" ID="ID_845908567" CREATED="1550762342829" MODIFIED="1550762581655"/>
<node TEXT="&#x5806;&#x80a5;&#x69fd;&#x5916;&#x578b;&#x70ba;&#x4e09;&#x89d2;&#x67f1;&#x578b;&#xff0c;&#x5169;&#x7aef;&#x8a2d;&#x6709;&#x8f49;&#x8ef8;&#xff0c;&#x5b9a;&#x671f;&#x9032;&#x884c;&#x9806;/&#x9006;&#x6642;&#x91dd;&#x7684;&#x8f49;&#x52d5;&#xff0c;&#x8b93;&#x53cd;&#x61c9;&#x5806;&#x7d93;&#x904e;&#x4e2d;&#x5fc3;&#x8ef8;&#x5207;&#x6599;&#x5200;&#x7684;&#x8655;&#x7406;&#x4e0b;&#x9054;&#x5230;&#x652a;&#x62cc;&#x7684;&#x6548;&#x679c;&#xff0c;" ID="ID_468780240" CREATED="1550762582889" MODIFIED="1550762734831"/>
<node TEXT="&#x975c;&#x6b62;&#x72c0;&#x614b;&#x6642;&#xff0c;&#x4e09;&#x89d2;&#x67f1;&#x9ad4;&#x7531;&#x5176;&#x4e2d;&#x4e00;&#x500b;&#x5e95;&#x908a;&#x8457;&#x5730;&#xff0c;&#x53e6;&#x5916;&#x7684;&#x5169;&#x908a;&#x88ab;&#x9694;&#x71b1;&#x677f;&#x7f69;&#x4f4f;&#xff0c;&#x8b93;&#x71b1;&#x80fd;&#x7d71;&#x4e00;&#x7531;&#x5e95;&#x908a;&#x63a5;&#x89f8;&#x7684;&#x65af;&#x7279;&#x6797;&#x767c;&#x96fb;&#x6a5f;&#x71b1;&#x6c23;&#x69fd;&#x653e;&#x51fa;" ID="ID_1365228131" CREATED="1550762735961" MODIFIED="1550762874763"/>
</node>
</node>
</node>
</node>
<node TEXT="&#x5176;&#x4ed6;&#x548c;&#x672c;&#x5c08;&#x6848;&#x6709;&#x5171;&#x901a;&#x9ede;&#x7684;&#x6848;&#x4f8b;" POSITION="right" ID="ID_504837914" CREATED="1551596740459" MODIFIED="1551596878100">
<edge COLOR="#007c00"/>
<node TEXT="SmartAfrica" ID="ID_1675349587" CREATED="1551596878757" MODIFIED="1551596888968">
<node TEXT="&#x7531;&#x4e00;&#x4f4d;MIT&#x7684;&#x4eba;&#x58eb;&#x88fd;&#x4f5c;&#xff0c;&#x76ee;&#x7684;&#x5728;&#x89e3;&#x6c7a;&#x975e;&#x6d32;&#x7684;&#x5132;&#x6c34;/&#x6de8;&#x6c34;/&#x591c;&#x9593;&#x7167;&#x660e;&#xff0c;&#x5df2;&#x5b8c;&#x6210;prove of concept&#xff0c;&#x6709;&#x5b8c;&#x6574;&#x7269;&#x7406;&#x8a08;&#x7b97;" ID="ID_1271387716" CREATED="1551596889657" MODIFIED="1551597136527"/>
<node TEXT="&#x767d;&#x5929;&#x904b;&#x7528;&#x592a;&#x967d;&#x80fd;&#x548c;&#x98a8;&#x529b;&#x767c;&#x96fb;&#x5c07;&#x672a;&#x904e;&#x6ffe;&#x7684;&#x4e95;&#x6c34;&#x62bd;&#x51fa;&#xff0c;&#x904e;&#x6ffe;&#x5f8c;&#x5b58;&#x653e;&#x5728;&#x5927;&#x5bb9;&#x91cf;&#x7684;&#x9ad8;&#x8655;&#x6c34;&#x69fd;&#x4e2d;&#xff0c;&#x5728;&#x591c;&#x9593;&#x6642;&#x5c07;&#x6c34;&#x4f4d;&#x80fd;&#x8f49;&#x5316;&#x6210;&#x96fb;&#x529b;&#x4f86;&#x9ede;&#x4eae;&#x7167;&#x660e;&#x8a2d;&#x5099;" ID="ID_1390992311" CREATED="1551596991552" MODIFIED="1551597120004"/>
</node>
<node TEXT="HumanPowerPlant" ID="ID_1269948818" CREATED="1551597138528" MODIFIED="1551597148234">
<node TEXT="&#x6bd4;&#x5229;&#x6642;&#x7684;&#x67d0;&#x9593;&#x5b78;&#x6821;&#x5c08;&#x984c;&#xff0c;&#x548c;&#x672c;&#x5c08;&#x6848;&#x6975;&#x70ba;&#x76f8;&#x4f3c;&#xff0c;&#x5df2;&#x7d93;&#x505a;&#x51fa;&#x5404;&#x7a2e;&#x5132;&#x80fd;&#x904b;&#x52d5;&#x5668;&#x6750;" ID="ID_1788991214" CREATED="1551597149048" MODIFIED="1551597219723"/>
<node TEXT="&#x7f3a;&#x9ede;&#x662f;&#x6548;&#x7387;&#x4e0d;&#x4f73;&#xff0c;&#x80fd;&#x91cf;&#x5132;&#x5b58;&#x7684;&#x6bd4;&#x4f8b;&#x592a;&#x4f4e;" ID="ID_1112883138" CREATED="1551597220098" MODIFIED="1551597245454"/>
<node TEXT="&#x70ba;&#x4e86;&#x5c07;&#x6574;&#x500b;&#x6d3b;&#x52d5;&#x8a2d;&#x65bd;&#x7684;&#x7a7a;&#x9593;&#x9650;&#x5236;&#x5728;&#x4e00;&#x5c64;&#x6a13;&#x5167;&#xff0c;&#x653e;&#x68c4;&#x4e86;&#x9ad8;&#x7a7a;&#x6c34;&#x69fd;&#xff0c;&#x6539;&#x7528;&#x7a7a;&#x6c23;&#x58d3;&#x529b;&#x69fd;&#x4f86;&#x6536;&#x96c6;&#x80fd;&#x6e90;&#xff0c;&#x5728;&#x7a7a;&#x6c23;&#x69fd;&#x5167;&#x7684;&#x9ad8;&#x58d3;&#x7a7a;&#x6c23;&#x6703;&#x63a8;&#x52d5;&#x6c34;&#x69fd;&#x5167;&#x7684;&#x6c34;&#xff0c;&#x4f7f;&#x9ad8;&#x58d3;&#x6c34;&#x67f1;&#x5f9e;&#x5674;&#x5634;&#x5c04;&#x51fa;&#xff0c;&#x63a8;&#x52d5;pelton &#x6c34;&#x8f2a;&#x6a5f;&#xff0c;" ID="ID_1841897684" CREATED="1551597257127" MODIFIED="1551597439170"/>
<node TEXT="&#x58d3;&#x529b;&#x69fd;&#x8655;&#x5b58;&#x7684;&#x58d3;&#x529b;&#x6709;&#x9650;&#xff0c;&#x4e14;&#x4f7f;&#x7528;&#x8005;&#x8f38;&#x51fa;&#x7684;&#x80fd;&#x91cf;&#x6703;&#x6d6a;&#x8cbb;&#x5728;&#x548c;&#x58d3;&#x529b;&#x69fd;&#x539f;&#x6709;&#x7684;&#x7a7a;&#x58d3;&#x62b5;&#x6297;&#x505a;&#x5de5;&#x4e0a;&#x9762;&#xff0c;&#x8f38;&#x51fa;&#x7684;&#x58d3;&#x529b;&#x4e5f;&#x4e0d;&#x80fd;&#x4fdd;&#x6301;&#x6046;&#x5b9a;" ID="ID_1136166672" CREATED="1551597510176" MODIFIED="1551597600145"/>
</node>
</node>
</node>
</map>
