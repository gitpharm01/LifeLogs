<map version="freeplane 1.6.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="Air Cleaning Fitness&#xa;ACFit" FOLDED="false" ID="ID_362164510" CREATED="1517025450167" MODIFIED="1545536924983">
<font SIZE="18"/>
<hook NAME="MapStyle" background="#000000" zoom="2.0">
    <properties fit_to_viewport="false" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#cccccc" BACKGROUND_COLOR="#333333" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<icon BUILTIN="yes"/>
</stylenode>
<stylenode TEXT="mine" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#cccccc" BACKGROUND_COLOR="#333333" SHAPE_HORIZONTAL_MARGIN="10.0 pt" SHAPE_VERTICAL_MARGIN="10.0 pt">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="27" RULE="ON_BRANCH_CREATION"/>
<node TEXT="&#x6982;&#x8981;" POSITION="right" ID="ID_1877809856" CREATED="1545536936602" MODIFIED="1545536940711">
<edge COLOR="#7c0000"/>
<node TEXT="&#x6027;&#x8cea;&#x985e;&#x4f3c;&quot;&#x5927;&#x898f;&#x6a21;&#x8def;&#x8dd1;&quot;&#xff0c;&#x4f46;&#x662f;&#x6539;&#x6210;&#x5728;&#x5ba4;&#x5167;&#xff0c;&#x4e0d;&#x8b93;&#x53c3;&#x52a0;&#x8005;&#x5438;&#x9ad2;&#x7a7a;&#x6c23;&#xff0c;&#x800c;&#x4e14;&#x904b;&#x52d5;&#x65b9;&#x5f0f;&#x591a;&#x7a2e;&#xff0c;&#x4e0d;&#x9650;&#x65bc;&#x6162;&#x8dd1;&#xff0c;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x5f9e;&#x4e00;&#x5929;&#x6539;&#x6210;&#x4e00;&#x500b;&#x6708;&#x3002;" ID="ID_1139102830" CREATED="1545536941774" MODIFIED="1545537117944"/>
<node TEXT="&#x53c3;&#x52a0;&#x8005;&#x5230;&#x6307;&#x5b9a;&#x7684;&#x4f4d;&#x65bc;&#x5ba4;&#x5167;&#x3001;&#x4f7f;&#x7528;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;&#x7cfb;&#x7d71;&#x7684;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x9032;&#x884c;&#x904b;&#x52d5;&#xff0c;&#x5c07;&#x904b;&#x52d5;&#x5668;&#x6750;&#x5982;&#x98db;&#x8f2a;&#x6216;&#x5212;&#x8239;&#x6a5f;&#x7b49;&#x6539;&#x9020;&#x6210;&#x53ef;&#x4ee5;&#x62bd;&#x6c34;&#x84c4;&#x80fd;&#x4ee5;&#x9032;&#x884c;&#x767c;&#x96fb;&#x7684;&#x7248;&#x672c;&#xff0c;&#xa;&#x53c3;&#x52a0;&#x8005;&#x7528;&#x9019;&#x4e9b;&#x5668;&#x6750;&#x7d2f;&#x7a4d;&#xff62;&#x91cc;&#x7a0b;&#x6578;&#xff63;&#x4e26;&#x4e14;&#x4ee5;&#x6b64;&#x70ba;&#x6a19;&#x6e96;&#x9032;&#x884c;&#x7af6;&#x8cfd;&#xff0c;&#xa;&#x5b98;&#x65b9;&#x7db2;&#x7ad9;&#x4e0a;&#x6703;&#x5373;&#x6642;&#x66f4;&#x65b0;&#x6bcf;&#x4e00;&#x4f4d;&#x53c3;&#x8cfd;&#x8005;&#x7684;&#x9032;&#x5ea6;&#xff0c;&#x7e3d;&#x76ee;&#x6a19;&#x91cc;&#x7a0b;&#x6578;&#x8a02;&#x5728;&#x4e00;&#x500b;&#x4eba;&#x53ef;&#x4ee5;&#x5728;&#x4e00;&#x500b;&#x6708;&#x5167;&#x9032;&#x884c;&#x7684;&#x5408;&#x7406;&#x7bc4;&#x570d;&#x5167;&#xff0c;&#xa;&#x6700;&#x65e9;&#x9054;&#x6a19;&#x8005;&#x5373;&#x70ba;&#x51a0;&#x8ecd;&#xff0c;&#x4ee5;&#x6b64;&#x985e;&#x63a8;&#x3002;" ID="ID_287169656" CREATED="1545537118522" MODIFIED="1547943953802"/>
</node>
<node TEXT="&#x7279;&#x6027;" POSITION="right" ID="ID_1365111978" CREATED="1545537597787" MODIFIED="1545537604490">
<edge COLOR="#00007c"/>
<node TEXT="1.&#x4e0d;&#x8b93;&#x4f60;&#x5438;&#x9ad2;&#x7a7a;&#x6c23;" ID="ID_1968833217" CREATED="1545537605599" MODIFIED="1545537625255">
<node TEXT="&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x5747;&#x4f4d;&#x65bc;&#x5ba4;&#x5167;&#xff0c;&#x4e14;&#x5099;&#x6709;&#x7a7a;&#x6c23;&#x6de8;&#x5316;&#x7cfb;&#x7d71;&#xff0c;&#x8b93;&#x53c3;&#x8cfd;&#x8005;&#x80fd;&#x5920;&#x9032;&#x884c;&#x771f;&#x6b63;&#x5065;&#x5eb7;&#x7684;&#x904b;&#x52d5;&#x3002;" ID="ID_1531940393" CREATED="1545537626634" MODIFIED="1545537691530"/>
</node>
<node TEXT="2.&#x4f60;&#x904b;&#x52d5;&#x6211;&#x6de8;&#x7a7a;" ID="ID_267362005" CREATED="1545537694425" MODIFIED="1545537719190">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x5728;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x767c;&#x51fa;&#x7684;&#x96fb;&#x529b;&#x5c07;&#x6703;&#x88ab;&#x7528;&#x4f86;&#x9a45;&#x52d5;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;&#x7cfb;&#x7d71;&#xff0c;&#xa;&#x4e0d;&#x53ea;&#x5728;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x7684;&#x5ba4;&#x5167;&#xff0c;&#x540c;&#x6642;&#x5728;&#x5ba4;&#x5916;&#x4e5f;&#x6703;&#x653e;&#x7f6e;&#x5c0d;&#x5916;&#x7684;&#x7a7a;&#x6c23;&#x6de8;&#x5316;&#x7cfb;&#x7d71;&#xff0c;&#x5229;&#x5df1;&#x4e5f;&#x5229;&#x4ed6;&#xff0c;&#x6709;&#x516c;&#x76ca;&#x6027;&#x8cea;&#x3002;" ID="ID_1171837050" CREATED="1545537719956" MODIFIED="1545537859245"/>
</node>
<node TEXT="3.&#x53c3;&#x8cfd;&#x6642;&#x9593;&#x5730;&#x9ede;&#x4efb;&#x4f60;&#x6311;" ID="ID_1098588662" CREATED="1545537860479" MODIFIED="1545537958389">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x5728;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x53ea;&#x8981;&#x662f;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x958b;&#x653e;&#x7684;&#x6642;&#x6bb5;&#x90fd;&#x53ef;&#x53c3;&#x8cfd;&#xff0c;&#xa;&#x800c;&#x4e14;&#x6d3b;&#x52d5;&#x5730;&#x9ede;&#x4e0d;&#x53ea;&#x4e00;&#x500b;" ID="ID_350362140" CREATED="1545537897560" MODIFIED="1545537995389"/>
</node>
<node TEXT="4.&#x904b;&#x52d5;&#x9805;&#x76ee;&#x4efb;&#x4f60;&#x6311;" ID="ID_524135087" CREATED="1545537996831" MODIFIED="1545538060309">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x53ef;&#x4ee5;&#x6311;&#x9078;&#x81ea;&#x5df1;&#x60f3;&#x9032;&#x884c;&#x7684;&#x904b;&#x52d5;&#x9805;&#x76ee;&#xff0c;&#x4e0d;&#x9700;&#x8981;&#x4fb7;&#x9650;&#x5728;&#x9577;&#x8dd1;&#xff0c;&#xa;&#x53ea;&#x8981;&#x662f;&#x80fd;&#x5920;&#x914d;&#x5408;&#x904b;&#x52d5;&#x5668;&#x6750;&#x9032;&#x884c;&#x62bd;&#x6c34;&#x767c;&#x96fb;&#x7684;&#x9805;&#x76ee;&#x90fd;&#x53ef;&#x4ee5;&#xff0c;&#xa;&#x98db;&#x8f2a;&#x3001;&#x5212;&#x8239;&#x6a5f;&#x3001;&#x555e;&#x9234;&#x3001;&#x62c9;&#x529b;&#x7e69;&#x90fd;&#x884c;&#xff0c;&#x56e0;&#x6b64;&#x4ee5;&#x7121;&#x6c27;&#x58d3;&#x529b;&#x8a13;&#x7df4;&#x70ba;&#x76ee;&#x6a19;&#x7684;&#x5065;&#x7f8e;&#x9078;&#x624b;&#x53ef;&#x4ee5;&#x548c;&#x6709;&#x6c27;&#x904b;&#x52d5;&#x7684;&#x611b;&#x597d;&#x8005;&#x540c;&#x53f0;&#x7af6;&#x6280;&#x3002;" ID="ID_194628336" CREATED="1545538061872" MODIFIED="1548290904859"/>
</node>
<node TEXT="5.&#x734e;&#x52f5;&#x9054;&#x6a19;&#x8005;" ID="ID_1837423007" CREATED="1545538382652" MODIFIED="1545538400524">
<node TEXT="&#x7531;&#x65bc;&#x6d3b;&#x52d5;&#x671f;&#x9593;&#x9577;&#x9054;&#x4e00;&#x500b;&#x6708;&#xff0c;&#x6709;&#x53ef;&#x80fd;&#x6703;&#x6709;&#x4eba;&#x4e2d;&#x9014;&#x68c4;&#x8cfd;&#xff0c;&#xa;&#x56e0;&#x6b64;&#x8a2d;&#x5b9a;&#x6bcf;&#x7576;&#x53c3;&#x8cfd;&#x8005;&#x7d2f;&#x7a4d;&#x4e00;&#x5b9a;&#x7684;&#x904b;&#x52d5;&#x91cc;&#x7a0b;&#x6578;&#x5c31;&#x53ef;&#x4ee5;&#x53d6;&#x56de;&#x4e00;&#x5b9a;&#x6bd4;&#x4f8b;&#x7684;&#x53c3;&#x52a0;&#x8cbb;&#xff0c;&#x5728;&#x6d3b;&#x52d5;&#x7d50;&#x675f;&#x6642;&#x9000;&#x56de;&#x7d66;&#x53c3;&#x52a0;&#x8005;&#xff0c;&#x7528;&#x734e;&#x52f5;&#x6a5f;&#x5236;&#x4f86;&#x4fc3;&#x9032;&#x53c3;&#x8cfd;&#x8005;&#x5b8c;&#x6210;&#x76ee;&#x6a19;&#x3002;" ID="ID_164648339" CREATED="1545538403118" MODIFIED="1545538654109"/>
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x9032;&#x884c;&#x904b;&#x52d5;&#x9700;&#x8981;&#x5360;&#x7528;&#x5668;&#x6750;&#xff0c;&#x56e0;&#x6b64;&#x9700;&#x8981;&#x8b93;&#x4f7f;&#x7528;&#x8005;&#x5148;&#x9810;&#x7d04;&#x6642;&#x6bb5;&#xff0c;&#x7576;&#x4f7f;&#x7528;&#x8005;&#x5728;&#x9810;&#x7d04;&#x7684;&#x6642;&#x6bb5;&#x6e96;&#x6642;&#x4f86;&#x9032;&#x884c;&#x4e26;&#x4e14;&#x9054;&#x6a19;&#x6642;&#xff0c;&#x9000;&#x8cbb;&#x734e;&#x52f5;&#x7684;&#x6bd4;&#x7387;&#x66f4;&#x5927;" ID="ID_985234327" CREATED="1547962100706" MODIFIED="1547962221270"/>
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x53ef;&#x4ee5;&#x9080;&#x8acb;&#x670b;&#x53cb;&#x4e00;&#x540c;&#x53c3;&#x52a0;&#xff0c;&#x5728;&#x540c;&#x6642;&#x6bb5;&#x4f46;&#x4e0d;&#x540c;&#x6d3b;&#x52d5;&#x7ad9;&#x9ede;&#x9032;&#x884c;&#x6d3b;&#x52d5;&#xff0c;&#x9054;&#x6a19;&#x5f8c;&#x540c;&#x6a23;&#x7d66;&#x4e88;&#x734e;&#x52f5;&#xff0c;&#x4fc3;&#x4f7f;&#x4ed6;&#x5011;&#x7d50;&#x4f34;&#x53c3;&#x8cfd;" ID="ID_1953353770" CREATED="1547962222817" MODIFIED="1548291053174"/>
<node TEXT="&#x4f8b;:&#x53c3;&#x52a0;&#x8cbb;2000&#xff0c;&#x6bcf;&#x4e00;&#x6b21;&#x90fd;&quot;&#x9080;&#x8acb;&#x4e00;&#x4eba;&#x4ee5;&#x4e0a;&#x53c3;&#x52a0;&quot; &#xff0c;&quot;&#x6e96;&#x6642;&#x5230;&#x9810;&#x7d04;&#x7ad9;&#x9ede;&quot;&#xff0c;&quot;&#x6bcf;&#x6b21;&#x904b;&#x52d5;&#x90fd;&#x9054;&#x5230;&#x76ee;&#x6a19;&#x904b;&#x52d5;&#x91cf;&quot;&#x5728;&#x8a72;&#x671f;&#x7d50;&#x675f;&#x6642;&#x5c07;&#x53ef;&#x7372;&#x5f97;1000&#x7684;&#x9000;&#x8cbb;" ID="ID_1584274739" CREATED="1547962041988" MODIFIED="1548290806620">
<font BOLD="false"/>
</node>
</node>
</node>
<node TEXT="&#x786c;&#x9ad4;&#x9700;&#x6c42;" POSITION="right" ID="ID_1861946570" CREATED="1545553424568" MODIFIED="1545553437358">
<edge COLOR="#007c00"/>
<node TEXT="&#x6d3b;&#x52d5;&#x5834;&#x5730;" ID="ID_705892240" CREATED="1545553444363" MODIFIED="1545553465241">
<node TEXT="&#x79df;&#x501f;&#x5065;&#x8eab;&#x623f;or&#x7a7a;&#x6a13;&#x5c64;" ID="ID_656733314" CREATED="1545553466665" MODIFIED="1545553501997"/>
<node TEXT="&#x4f7f;&#x7528;&#x8ca8;&#x6ac3;&#x5c4b;&#x6539;&#x88dd;" ID="ID_1203372654" CREATED="1545553503715" MODIFIED="1545553526652"/>
</node>
<node TEXT="&#x6d3b;&#x52d5;&#x8a2d;&#x5099;&#xa;(&#x5168;&#x90e8;&#x6539;&#x88dd;&#x6210;&#x62bd;&#x6c34;&#x5e6b;&#x6d66;)" ID="ID_835965796" CREATED="1545553530817" MODIFIED="1547773051121">
<node TEXT="&#x98db;&#x8f2a;&#x6a5f;" ID="ID_1873859739" CREATED="1545553545409" MODIFIED="1545553555725">
<node TEXT="&#x8f49;&#x8ef8;&#x7684;&#x8ca0;&#x8f09;&#x6539;&#x70ba;&quot;&#x62bd;&#x6cb9;&#x6a5f;&quot;&#x7684;&#x7d50;&#x69cb;" ID="ID_1902886106" CREATED="1547773074478" MODIFIED="1547773170381"/>
</node>
<node TEXT="&#x5212;&#x8239;&#x6a5f;" ID="ID_430342956" CREATED="1545553556197" MODIFIED="1545553560701">
<node TEXT="&#x6539;&#x88dd;&#x65b9;&#x6cd5;&#x540c;&#x98db;&#x8f2a;&#x6a5f;" ID="ID_241642167" CREATED="1547773173695" MODIFIED="1547773208770"/>
</node>
<node TEXT="&#x62c9;&#x529b;&#x7e69;" ID="ID_1568108823" CREATED="1545553561155" MODIFIED="1545553567210">
<node TEXT="&#x62c9;&#x529b;&#x7684;&#x8ca0;&#x8f09;&#x6539;&#x70ba;&#x8ca0;&#x58d3;&#x5e6b;&#x6d66;" ID="ID_1329638774" CREATED="1547773210910" MODIFIED="1547773286722"/>
</node>
<node TEXT="&#x8e0f;&#x6b65;&#x6a5f;" ID="ID_1181388680" CREATED="1545553577697" MODIFIED="1547773304990">
<node TEXT="&#x8e0f;&#x677f;&#x6539;&#x88dd;&#x6210;&#x8173;&#x8e0f;&#x5f0f;&#x62bd;&#x6c34;&#x6a5f;" ID="ID_128817219" CREATED="1547773306759" MODIFIED="1547773392752"/>
</node>
<node TEXT="&#x62f3;&#x64ca;&#x9776;" ID="ID_1451500750" CREATED="1547773403823" MODIFIED="1547773428561">
<node TEXT="&#x53ef;&#x52d5;&#x7684;&#x62f3;&#x64ca;&#x9776;&#x548c;&#x6b63;&#x58d3;&#x5e6b;&#x6d66;&#x9023;&#x901a;&#xff0c;&#x5c07;&#x62f3;&#x64ca;&#x529b;&#x9053;&#x8f49;&#x5316;&#x6210;&#x63a8;&#x52d5;&#x6c34;&#x7684;&#x52d5;&#x529b;" ID="ID_617457819" CREATED="1547773429487" MODIFIED="1547773534881"/>
</node>
<node TEXT="&#x58fa;&#x9234;" ID="ID_1969290987" CREATED="1547773591499" MODIFIED="1547773609258">
<node TEXT="&#x5167;&#x5bb9;&#x7269;&#x6539;&#x70ba;&#x6c34;&#xff0c;&#x8209;&#x9ad8;&#x5f8c;&#x6392;&#x5165;&#x6c34;&#x982d;&#x6c34;&#x69fd;" ID="ID_96648151" CREATED="1547773610588" MODIFIED="1547773654938"/>
</node>
</node>
<node TEXT="&#x9644;&#x5c6c;&#x5132;&#x80fd;&#x8a2d;&#x5099;" ID="ID_721589129" CREATED="1547944803947" MODIFIED="1547944844650">
<node TEXT="&#x5927;&#x9762;&#x7a4d;&#x5c4b;&#x9802;" ID="ID_791365122" CREATED="1547944845827" MODIFIED="1547944861582">
<node TEXT="&#x8a2d;&#x7f6e;&#x4fbf;&#x5b9c;&#x7684;&#x92c1;&#x7b94;&#x7d19;&#x53cd;&#x5c04;&#x93e1;&#xff0c;&#x5c07;&#x5149;&#x7dda;&#x96c6;&#x4e2d;&#x5230;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x96c6;&#x71b1;&#x69fd;&#xff0c;&#x9a45;&#x52d5;&#x5e6b;&#x6d66;&#x4f86;&#x62bd;&#x6c34;" ID="ID_1919687377" CREATED="1547944863960" MODIFIED="1547944958286"/>
</node>
<node TEXT="&#x9ad8;&#x98a8;&#x529b;&#x5730;&#x5340;" ID="ID_1903679533" CREATED="1547944960067" MODIFIED="1547944969586">
<node TEXT="&#x8a2d;&#x7f6e;&#x5782;&#x76f4;&#x5f0f;&#x98a8;&#x8eca;&#xff0c;&#x540c;&#x6a23;&#x4ee5;&#x6c34;&#x4f4d;&#x80fd;&#x65b9;&#x5f0f;&#x5132;&#x80fd;" ID="ID_1661782797" CREATED="1547944970852" MODIFIED="1547945037920"/>
</node>
<node TEXT="&quot;&#x4e0d;&quot;&#x4f7f;&#x7528;&#x592a;&#x967d;&#x80fd;&#x677f;&#xff0c;&#x56e0;&#x70ba;&#x5176;&#x4fdd;&#x990a;&#x4e0d;&#x6613;&#x4e14;&#x990a;&#x8b77;&#x6280;&#x8853;&#x548c;&#x5efa;&#x69cb;&#x6210;&#x672c;&#x6975;&#x9ad8;&#xff0c;&#x800c;&#x4e14;&#x6703;&#x5206;&#x6563;&#x96fb;&#x529b;&#x7522;&#x751f;&#x8207;&#x8f38;&#x9001;&#x7684;&#x9014;&#x5f91;" ID="ID_1331785428" CREATED="1547945080245" MODIFIED="1547945242727"/>
</node>
<node TEXT="&#x7db2;&#x8def;&#x8a2d;&#x5099;/&#x96fb;&#x8a71;&#x7e3d;&#x6a5f;&#x8a2d;&#x5099;" ID="ID_772230489" CREATED="1545553587525" MODIFIED="1545553617684"/>
</node>
<node TEXT="&#x4eba;&#x529b;&#x9700;&#x6c42;" POSITION="right" ID="ID_125243513" CREATED="1545553621135" MODIFIED="1545553627526">
<edge COLOR="#7c007c"/>
<node TEXT="&#x8a2d;&#x5099;&#x7ba1;&#x7406;&#x54e1;" ID="ID_1653423642" CREATED="1545553628963" MODIFIED="1545553668270"/>
<node TEXT="&#x5834;&#x5730;&#x7ba1;&#x7406;&#x54e1;" ID="ID_20158108" CREATED="1545553668520" MODIFIED="1545553679900"/>
<node TEXT="&#x5ba3;&#x50b3;&#x90e8;&#x9580;" ID="ID_1262493586" CREATED="1545553683635" MODIFIED="1545553691524"/>
<node TEXT="&#x7db2;&#x7ad9;&#x7ba1;&#x7406;&#x90e8;&#x9580;" ID="ID_1898585757" CREATED="1545553699810" MODIFIED="1545553710840"/>
</node>
<node TEXT="&#x6280;&#x8853;&#x9700;&#x6c42;" POSITION="right" ID="ID_1036264379" CREATED="1545553721971" MODIFIED="1545553727455">
<edge COLOR="#7c7c00"/>
<node TEXT="&#x4e00;&#x500b;&#x80fd;&#xff62;&#x986f;&#x793a;&#x53bb;&#x6c59;&#x6210;&#x6548;&#xff63;&#x7684;&#x7a7a;&#x6c23;&#x6e05;&#x6de8;&#x6a5f;" ID="ID_1701706950" CREATED="1545553728506" MODIFIED="1545553805299"/>
<node TEXT="&#x6539;&#x88dd;&#x6210;&#x62bd;&#x6c34;&#x6a5f;&#x7684;&#x904b;&#x52d5;&#x8a2d;&#x5099;" ID="ID_1151253426" CREATED="1545553805737" MODIFIED="1547944088792"/>
<node TEXT="&#x96fb;&#x529b;&#x5132;&#x85cf;&#x7cfb;&#x7d71;" ID="ID_1701111466" CREATED="1545553839921" MODIFIED="1545553895695">
<node TEXT="&#x4f7f;&#x7528;&#x653e;&#x5728;&#x9ad8;&#x8655;&#x7684;&#x6c34;&#x69fd;&#x5132;&#x5b58;&#x4e26;&#x4e14;&#x96c6;&#x4e2d;&#x80fd;&#x91cf;&#xff0c;&#x6574;&#x500b;&#x6d3b;&#x52d5;&#x6703;&#x5834;&#x53ea;&#x8a2d;&#x7f6e;&#x4e00;&#x500b;&#x4e3b;&#x8981;&#x7684;&#x767c;&#x96fb;&#x6a5f;(&#x8996;&#x6c34;&#x982d;&#x9ad8;&#x5ea6;&#x4f86;&#x9078;&#x64c7;&#x767c;&#x96fb;&#x6a5f;&#x7a2e;&#x985e;&#xff0c;&#xa;3&#x516c;&#x5c3a;&#x4ee5;&#x4e0b;&#x4f4e;&#x6c34;&#x982d;&#x4f7f;&#x7528;Gravitational water Vortex&#xa;&#x6709;10&#x516c;&#x5c3a;&#x5de6;&#x53f3;&#x5247;&#x4f7f;&#x7528;&#x9ad8;&#x6548;&#x7387;&#x6e26;&#x8f2a;&#x767c;&#x96fb;&#x6a5f;)" ID="ID_1031679946" CREATED="1547943998535" MODIFIED="1547944290614"/>
<node TEXT="&#x6c34;&#x4f4d;&#x80fd;&#x5bb9;&#x6613;&#x5132;&#x5b58;&#x4e14;&#x5132;&#x6c34;&#x8a2d;&#x5099;&#x9060;&#x8f03;&#x5132;&#x96fb;&#x8a2d;&#x5099;&#x7c21;&#x55ae;&#x800c;&#x4fbf;&#x5b9c;" ID="ID_849828468" CREATED="1547944291239" MODIFIED="1547944385938"/>
<node TEXT="&#x4e3b;&#x767c;&#x96fb;&#x6a5f;&#x8996;&#x6703;&#x5834;&#x7684;&#x96fb;&#x529b;&#x9700;&#x6c42;&#x72c0;&#x6cc1;&#x4f86;&#x555f;&#x52d5;&#xff0c;&#x4f4d;&#x65bc;&#x9ad8;&#x8655;&#x7684;&#x6c34;&#x982d;&#x6c34;&#x69fd;&#x51fa;&#x6c34;&#x95a5;&#x9580;&#x53ef;&#x4ee5;&#x6309;&#x7167;&#x767c;&#x96fb;&#x7684;&#x9700;&#x6c42;&#x91cf;&#x4f86;&#x6539;&#x8b8a;&#x6d41;&#x91cf;&#xff0c;&#x4f7f;&#x767c;&#x96fb;&#x7684;&#x6548;&#x7387;&#x6700;&#x5927;&#x5316;" ID="ID_1013711000" CREATED="1547944394282" MODIFIED="1547944595523"/>
<node TEXT="&#x4e0d;&#x9700;&#x8981;&#x70ba;&#x5404;&#x7a2e;&#x4e0d;&#x540c;&#x7684;&#x904b;&#x52d5;&#x8a2d;&#x8a08;&#x7d50;&#x69cb;&#x8907;&#x96dc;&#x7684;&#x767c;&#x96fb;&#x8a2d;&#x5099;&#xff0c;&#xa;&#x66f4;&#x4e0d;&#x9700;&#x8981;&#x5728;&#x6bcf;&#x4e00;&#x500b;&#x5668;&#x6750;&#x8a2d;&#x7f6e;&#x767c;&#x96fb;&#x6a5f;&#xff0c;&#x964d;&#x4f4e;&#x8a2d;&#x5099;&#x6210;&#x672c;" ID="ID_437352748" CREATED="1547944615025" MODIFIED="1547944727872"/>
</node>
</node>
<node TEXT="&#x8cbb;&#x7528;&#x8a08;&#x7b97;" POSITION="right" ID="ID_229216314" CREATED="1547945337399" MODIFIED="1547945347481">
<edge COLOR="#00ffff"/>
<node TEXT="&#x6210;&#x672c;" ID="ID_1745661957" CREATED="1547945348372" MODIFIED="1547945390040">
<node TEXT="&#x5ba3;&#x50b3;&#x8cbb;&#x7528;" ID="ID_1088037770" CREATED="1547945390878" MODIFIED="1547945398095"/>
<node TEXT="&#x4eba;&#x4e8b;&#x8cbb;&#x7528;" ID="ID_118840434" CREATED="1547945398411" MODIFIED="1547945409317"/>
<node TEXT="&#x5834;&#x5730;&#x79df;&#x91d1;" ID="ID_342976986" CREATED="1547945409712" MODIFIED="1547945415382"/>
<node TEXT="&#x8a2d;&#x5099;&#x8cbb;&#x7528;" ID="ID_1287479429" CREATED="1547945415554" MODIFIED="1547945419490"/>
</node>
<node TEXT="&#x6536;&#x5165;" ID="ID_305596983" CREATED="1547945494765" MODIFIED="1547945499574">
<node TEXT="&#x53c3;&#x8cfd;&#x8005;&#x7684;&#x53c3;&#x52a0;&#x8cbb;" ID="ID_411532505" CREATED="1547945500352" MODIFIED="1547945522615"/>
<node TEXT="&#x5ee3;&#x544a;&#x5ee0;&#x5546;&#x8d0a;&#x52a9;&#x8cbb;" ID="ID_921159486" CREATED="1547945522913" MODIFIED="1547945544989"/>
<node TEXT="&#x9644;&#x8a2d;&#x7926;&#x6cc9;&#x6c34;/&#x904b;&#x52d5;&#x98f2;&#x6599;&#x7ad9;&#x92b7;&#x552e;&#x6536;&#x5165;" ID="ID_619479606" CREATED="1548291235936" MODIFIED="1548291268813"/>
</node>
</node>
<node TEXT="&#x9650;&#x5236;" POSITION="right" ID="ID_618582848" CREATED="1545553903052" MODIFIED="1545553913209">
<edge COLOR="#ff0000"/>
<node TEXT="&#x4eba;&#x529b;&#x767c;&#x96fb;&#x4e0d;&#x53ef;&#x80fd;&#x6703;&#x6709;&#x5546;&#x696d;&#x767c;&#x96fb;&#x7684;&#x898f;&#x6a21;&#x548c;&#x6548;&#x76ca;&#xff0c;&#x5728;&#x5ba3;&#x50b3;&#x6642;&#x4e0d;&#x80fd;&#x904e;&#x5ea6;&#x8a87;&#x5927;&#xff0c;" ID="ID_537486540" CREATED="1545553914313" MODIFIED="1545553984789"/>
</node>
<node TEXT="&#x6f5b;&#x5728;&#x5408;&#x4f5c;&#x5c0d;&#x8c61;" POSITION="right" ID="ID_1029227209" CREATED="1545553986945" MODIFIED="1545554003612">
<edge COLOR="#0000ff"/>
<node TEXT="Gogoro&#x96fb;&#x529b;&#x7ad9;" ID="ID_931033234" CREATED="1545554004523" MODIFIED="1545554023454"/>
<node TEXT="&#x9700;&#x8981;&#x74b0;&#x4fdd;&#x516c;&#x76ca;&#x5f62;&#x8c61;&#x7684;&#x5ee0;&#x5546;&#x548c;&#x5718;&#x9ad4;" ID="ID_582727556" CREATED="1545554109915" MODIFIED="1547945069305"/>
<node TEXT="&#x904b;&#x52d5;&#x7528;&#x54c1;&#x5ee0;&#x5546;" ID="ID_1652162820" CREATED="1547773711745" MODIFIED="1547773727637"/>
</node>
<node TEXT="&#x64f4;&#x5f35;&#x767c;&#x5c55;&#x65b9;&#x5411;" POSITION="right" ID="ID_1304049696" CREATED="1547773851996" MODIFIED="1547773866588">
<edge COLOR="#00ff00"/>
<node TEXT="&#x518d;&#x751f;&#x80fd;&#x6e90;&#x5065;&#x8eab;&#x516c;&#x5712;" ID="ID_322108495" CREATED="1547773867168" MODIFIED="1547773908216">
<node TEXT="&#x5728;&#x4e00;&#x500b;&#x6709;&#x5929;&#x7136;&#x9ad8;&#x4f4e;&#x5761;&#x5ea6;(15m&#x4ee5;&#x4e0a;)&#x7684;&#x5730;&#x5340;&#x5efa;&#x7acb;&#x56fa;&#x5b9a;&#x7684;&#x8a2d;&#x65bd;&#xff0c;&#xa;&#x9ad8;&#x8655;&#x70ba;&#x6c34;&#x7bb1;&#x9663;&#x5217;&#xa;&#x4f4e;&#x8655;&#x8a2d;&#x7f6e;&#x4e00;&#x500b;&#x96c6;&#x4e2d;&#x7684;&#x767c;&#x96fb;&#x6a5f;&#x548c;&#x7e3d;&#x96c6;&#x6c34;&#x6c60;&#xa;&#x5712;&#x5340;&#x6700;&#x5927;&#x7684;&#x5e73;&#x5766;&#x8179;&#x5730;&#x4f5c;&#x70ba;&#x5065;&#x8eab;&#x623f;&#x6240;&#x5728;&#x5730;&#xff0c;&#xa;&#x6574;&#x500b;&#x5712;&#x5340;&#x9032;&#x884c;&#x7da0;&#x5316;&#x548c;&#x7f8e;&#x5316;" ID="ID_1967725948" CREATED="1547773908840" MODIFIED="1548590634715"/>
<node TEXT="&#x5065;&#x8eab;&#x623f;&#x548c;&#x516c;&#x5712;&#x4e3b;&#x8981;&#x63d0;&#x4f9b;&#x89c0;&#x5149;&#x6536;&#x5165;&#xff0c;&#x767c;&#x96fb;&#x6548;&#x76ca;&#x4e0d;&#x5927;" ID="ID_1065293723" CREATED="1547774101071" MODIFIED="1547774688294"/>
<node TEXT="&#x5c4b;&#x9802;&#x548c;&#x7a7a;&#x66e0;&#x7a7a;&#x9593;&#x88dd;&#x8a2d;&#x6975;&#x4f4e;&#x6210;&#x672c;&#x7684;&#x92c1;&#x7b94;&#x53cd;&#x5c04;&#x93e1;&#xff0c;&#x5c07;&#x967d;&#x5149;&#x96c6;&#x4e2d;&#x5230;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x71b1;&#x6e90;&#x69fd;&#xff0c;&#x8b93;&#x592a;&#x967d;&#x80fd;&#x76f4;&#x63a5;&#x8b8a;&#x6210;&#x6c34;&#x4f4d;&#x80fd;&#x5132;&#x5b58;&#x8d77;&#x4f86;" ID="ID_51271393" CREATED="1547774181206" MODIFIED="1547774705258">
<node TEXT="DirtyCycle" ID="ID_1767205689" CREATED="1548592376315" MODIFIED="1548592382245">
<node TEXT="&#x548c;&#x50b3;&#x7d71;&#x7684;&#x5c01;&#x9589;&#x65af;&#x7279;&#x6797;&#x5faa;&#x74b0;&#x4e0d;&#x4e00;&#x6a23;&#xff0c;ACFit&#x7684;&#x65af;&#x7279;&#x6797;&#x84c4;&#x80fd;&#x7cfb;&#x7d71;&#x53ef;&#x4ee5;&#x7522;&#x751f;&#x7684;&#x80fd;&#x91cf;&#x9060;&#x8d85;&#x904e;&#x71b1;&#x6e90;&#x672c;&#x8eab;(&#x592a;&#x967d;&#x71b1;&#x80fd;&#x548c;&#x71c3;&#x71d2;&#x993f;&#x6c34;&#x6cb9;&#x71b1;&#x80fd;)&#xff0c;&#x56e0;&#x70ba;&#x88ab;&#x7576;&#x4f5c;&#x5132;&#x80fd;&#x5a92;&#x4ecb;&#x7684;&#x6c34;&#x672c;&#x8eab;&#x5c31;&#x662f;&#x51b7;&#x537b;&#x5291;&#xff0c;&#x4f4e;&#x6eab;&#x7684;&#x6c34;&#x88ab;&#x62bd;&#x5230;&#x9ad8;&#x8655;&#x6642;&#xff0c;&#x4e00;&#x90e8;&#x4efd;&#x7684;&#x6c34;&#x6703;&#x88ab;&#x5c0e;&#x5165;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x7684;&#x51b7;&#x69fd;&#xff0c;&#x5f37;&#x5316;&#x6eab;&#x5dee;&#x767c;&#x96fb;&#x7684;&#x5a01;&#x529b;" ID="ID_451695417" CREATED="1548592384085" MODIFIED="1548592795465"/>
<node TEXT="&#x6eab;&#x5ea6;&#x5927;&#x5e45;&#x5ea6;&#x5347;&#x9ad8;&#x7684;&#x71b1;&#x6c34;&#x53ef;&#x4ee5;&#x4f9b;&#x5712;&#x5340;&#x5167;&#x8a2d;&#x65bd;&#x4f7f;&#x7528;&#xff0c;&#x7576;&#x5176;&#x6eab;&#x5ea6;&#x53c8;&#x964d;&#x56de;&#x4f4e;&#x6eab;&#x6642;&#x4fbf;&#x548c;&#x4e3b;&#x6d41;&#x6c34;&#x69fd;&#x532f;&#x6d41;&#xff0c;" ID="ID_1936085374" CREATED="1548592796058" MODIFIED="1548592803631"/>
<node TEXT="&#x5728;&#x590f;&#x5b63;&#x6642;&#xff0c;&#x5728;&#x4e0b;&#x6e38;&#x6c34;&#x69fd;&#x8a2d;&#x7f6e;&#x4e00;&#x500b;&#x84b8;&#x767c;&#x69fd;&#xff0c;&#x7528;&#x4e0b;&#x6e38;&#x7684;&#x5404;&#x7a2e;&#x5ee2;&#x71b1;&#x4f86;&#x628a;&#x6c34;&#x84b8;&#x767c;&#xff0c;&#x6c34;&#x84b8;&#x6c23;&#x901a;&#x904e;&#x5782;&#x76f4;&#x7ba1;&#xff0c;&#x5728;&#x9ad8;&#x8655;&#x6c34;&#x69fd;&#x51dd;&#x7d50;" ID="ID_919715522" CREATED="1548592804881" MODIFIED="1548592905101"/>
</node>
</node>
<node TEXT="&#x5728;&#x5236;&#x9ad8;&#x9ede;&#x6216;&#x8fce;&#x98a8;&#x9762;&#x5efa;&#x7acb;&#x7e31;&#x8ef8;&#x5f0f;&#x98a8;&#x529b;&#x5e6b;&#x6d66;&#xff0c;&#x4e26;&#x4e14;&#x5728;&#x56db;&#x5468;&#x5efa;&#x7acb;&#x5373;&#x6642;&#x7684;&#x98a8;&#x529b;&#x5075;&#x6e2c;&#x7cfb;&#x7d71;&#xff0c;&#x96a8;&#x6642;&#x6539;&#x8b8a;&#x98a8;&#x529b;&#x5e6b;&#x6d66;&#x7684;&#x8ca0;&#x8f09;&#xff0c;&#x7528;&#x6700;&#x4f73;&#x7684;&#x6548;&#x7387;&#x8f49;&#x5316;&#x98a8;&#x529b;&#x6210;&#x70ba;&#x6c34;&#x4f4d;&#x80fd;" ID="ID_983895283" CREATED="1547774301567" MODIFIED="1548590686207">
<node TEXT="&#x548c;&#x56fa;&#x5b9a;&#x8ca0;&#x8f09;&#x7684;&#x98a8;&#x529b;&#x767c;&#x96fb;&#x6a5f;&#x4e0d;&#x540c;&#xff0c;&#x6bcf;&#x500b;&#x98a8;&#x529b;&#x6a21;&#x7d44;&#x5b8c;&#x5168;&#x4e0d;&#x9700;&#x8981;&#x6210;&#x672c;&#x6602;&#x8cb4;&#x7684;&#x767c;&#x96fb;&#x6a5f;&#xff0c;&#x53ea;&#x8981;&#x5805;&#x56fa;&#x8010;&#x7528;&#x7684;&#x5e6b;&#x6d66;&#x50b3;&#x52d5;&#x7d50;&#x69cb;&#x5c31;&#x80fd;&#x84c4;&#x80fd;&#xff0c;&#x800c;&#x4e14;&#x80fd;&#x5920;&#x8996;&#x98a8;&#x529b;&#x5927;&#x5c0f;&#x4f86;&#x64f7;&#x53d6;&#x6700;&#x5927;&#x7684;&#x80fd;&#x91cf;" ID="ID_1770889564" CREATED="1548593366669" MODIFIED="1548593486823"/>
</node>
<node TEXT="&#x6240;&#x6709;&#x80fd;&#x6e90;&#x8f38;&#x5165;&#x5168;&#x90e8;&#x4ee5;&#x6c34;&#x4f4d;&#x80fd;&#x5f62;&#x5f0f;&#x5132;&#x5b58;&#x8d77;&#x4f86;&#xff0c;&#x5404;&#x7528;&#x96fb;&#x6236;&#x4e8b;&#x5148;&#x63d0;&#x4ea4;&#x5176;&#x7528;&#x96fb;&#x7684;&#x6700;&#x5927;&#x8ca0;&#x8f09;&#x9700;&#x6c42;&#x548c;&#x7528;&#x96fb;&#x6642;&#x9593;&#xff0c;&#x6309;&#x7167;&#x4f7f;&#x7528;&#x8005;&#x7aef;&#x7684;&#x7528;&#x96fb;&#x9700;&#x6c42;&#x91cf;&#x4f86;&#x958b;&#x555f;&#x4e0a;&#x65b9;&#x6c34;&#x69fd;&#xff0c;&#x8da8;&#x52d5;&#x4f4e;&#x8655;&#x7684;&#x6c34;&#x529b;&#x767c;&#x96fb;&#x6a21;&#x7d44;&#xff0c;&#x4e0d;&#x7528;&#x50cf;&#x5927;&#x578b;&#x706b;&#x529b;&#x6216;&#x6838;&#x80fd;&#x767c;&#x96fb;&#x5ee0;&#x4e00;&#x6a23;&#x9700;&#x8981;&#x6d6a;&#x8cbb;&#x5927;&#x91cf;&#x80fd;&#x6e90;&#x5728;&#x5099;&#x8f09;&#x96fb;&#x529b;&#x4e0a;" ID="ID_1226396077" CREATED="1547774518248" MODIFIED="1548591134814"/>
<node TEXT="&#x5728;&#x516c;&#x5712;&#x7684;&#x5404;&#x500b;&#x65b9;&#x4f4d;&#x8a2d;&#x7f6e;gogoro&#x5145;&#x96fb;&#x7ad9;&#xff0c;&#x6536;&#x53d6;&#x79df;&#x91d1;&#x4e26;&#x4e14;&#x70ba;&#x5712;&#x5340;&#x5167;&#x5546;&#x5e97;&#x5438;&#x5f15;&#x9867;&#x5ba2;" ID="ID_1744008039" CREATED="1548291349556" MODIFIED="1548591173868"/>
<node TEXT="&#x5728;&#x516c;&#x5712;&#x5167;&#x8a2d;&#x7f6e;&#x5404;&#x7a2e;&#x5546;&#x5e97;&#xff0c;&#x6a19;&#x699c;&#x8a72;&#x5e97;&#x9762;&#x5b8c;&#x5168;&#x7531;&#x518d;&#x751f;&#x80fd;&#x6e90;&#x9a45;&#x52d5;" ID="ID_1847716330" CREATED="1548291417578" MODIFIED="1548590723792">
<node TEXT="&#x8d85;&#x5546;" ID="ID_860904447" CREATED="1548591584321" MODIFIED="1548591586411">
<node TEXT="&#x524d;&#x4f86;&#x62bd;&#x63db;&#x96fb;&#x6c60;&#x7684;&#x65c5;&#x5ba2;&#x53ef;&#x4ee5;&#x5728;&#x6b64;&#x4f11;&#x606f;&#x548c;&#x6d88;&#x8cbb;" ID="ID_1047188546" CREATED="1548592969035" MODIFIED="1548592994545"/>
</node>
<node TEXT="&#x9910;&#x5ef3;" ID="ID_1812222933" CREATED="1548590724412" MODIFIED="1548591582874">
<node TEXT="&#x5c31;&#x5730;&#x63d0;&#x7149;&#x993f;&#x6c34;&#x6cb9;&#x4e26;&#x4e14;&#x4f5c;&#x70ba;&#x4e3b;&#x65af;&#x7279;&#x6797;&#x5e6b;&#x6d66;&#x7684;&#x591c;&#x9593;&#x71c3;&#x6599;(&#x767d;&#x5929;&#x70ba;&#x65e5;&#x5149;&#x71b1;&#x80fd;)&#xff0c;&#x7576;&#x5929;&#x7684;&#x993f;&#x6c34;&#x6cb9;&#x5c31;&#x5728;&#x7576;&#x5929;&#x5168;&#x6578;&#x71d2;&#x6bc0;&#xff0c;&#x7dad;&#x8b77;&#x98df;&#x5b89;&#x4e26;&#x4e14;&#x7269;&#x76e1;&#x5176;&#x7528;&#xff0c;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x70ba;&quot;&#x5916;&#x71c3;&#x6a5f;&quot;&#xff0c;&#x993f;&#x6c34;&#x6cb9;&#x4e0d;&#x9700;&#x8981;&#x8655;&#x7406;&#x5230;&#x5167;&#x71c3;&#x6a5f;&#x5f15;&#x64ce;&#x7684;&#x7b49;&#x7d1a;&#x3002;" ID="ID_1633888139" CREATED="1548591329093" MODIFIED="1548591567424"/>
</node>
<node TEXT="&#x5496;&#x5561;&#x5e97;/&#x65e9;&#x9910;&#x5e97;" ID="ID_453134589" CREATED="1548591189483" MODIFIED="1548591306077">
<node TEXT="&#x7522;&#x751f;&#x7684;&#x5496;&#x5561;&#x6e23;/&#x9ec3;&#x8c46;&#x6e23;/&#x8336;&#x8449;&#x6e23;/&#x86cb;&#x6bbc;&#x53ef;&#x4ee5;&#x5c31;&#x5730;&#x5806;&#x80a5;&#xff0c;&#x597d;&#x6c27;&#x5806;&#x80a5;&#x53ef;&#x4ee5;&#x540c;&#x6642;&#x7522;&#x751f;&#x71b1;&#x80fd;&#xff0c;&#x9a45;&#x52d5;&#x5fae;&#x578b;&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;" ID="ID_431215113" CREATED="1548591193849" MODIFIED="1548591326543"/>
</node>
<node TEXT="&#x6309;&#x6469;&#x990a;&#x751f;&#x9928;" ID="ID_814493658" CREATED="1548590736692" MODIFIED="1548590759988">
<node TEXT="&#x65af;&#x7279;&#x6797;&#x5f15;&#x64ce;&#x6703;&#x7522;&#x751f;&#x5927;&#x91cf;&#x88ab;&#x52a0;&#x71b1;&#x7684;&#x51b7;&#x537b;&#x6c34;&#xff0c;&#x5176;&#x4e2d;&#x4e00;&#x90e8;&#x4efd;&#x53ef;&#x4ee5;&#x7576;&#x4f5c;&#x6ce1;&#x8173;&#x6c34;&#x7684;&#x71b1;&#x6e90;?" ID="ID_259030336" CREATED="1548591604052" MODIFIED="1548591670647"/>
</node>
<node TEXT="&#x6d17;&#x8863;&#x5e97;" ID="ID_665729581" CREATED="1548591875312" MODIFIED="1548591879399">
<node TEXT="&#x5982;&#x679c;&#x8179;&#x5730;&#x5920;&#x5927;&#xff0c;&#x6574;&#x5408;&#x4e0b;&#x65b9;&#x6c34;&#x69fd;&#x8a2d;&#x7f6e;&#x529f;&#x80fd;&#x6027;&#x4eba;&#x5de5;&#x6ebc;&#x5730;&#xff0c;&#x7528;&#x690d;&#x7269;&#x548c;&#x7802;&#x77f3;&#x4f86;&#x6de8;&#x5316;&#x6d17;&#x8863;&#x5ee2;&#x6c34;&#xff0c;&#x7d93;&#x904e;&#x904e;&#x6ffe;&#x7684;&#x5ee2;&#x6c34;&#x5c31;&#x5145;&#x7576;&#x6574;&#x500b;&#x5712;&#x5340;&#x7684;&quot;&#x84c4;&#x80fd;&#x7528;&#x6c34;&quot;&#x548c;&quot;&#x704c;&#x6e89;&#x7528;&#x6c34;&quot;&#xff0c;&#x5728;&#x4e0a;&#x4e0b;&#x6c34;&#x69fd;&#x9593;&#x5faa;&#x74b0;" ID="ID_51632205" CREATED="1548591880679" MODIFIED="1548592159238"/>
<node TEXT="&#x84c4;&#x80fd;&#x7528;&#x6c34;&#x7d93;&#x904e;&#x8655;&#x7406;(&#x7528;&#x5ee2;&#x71b1;&#x84b8;&#x993e;)&#x4e4b;&#x5f8c;&#x53ef;&#x4ee5;&#x518d;&#x6b21;&#x6210;&#x70ba;&#x6d17;&#x8863;&#x5e97;&#x7684;&#x6c34;&#x6e90;" ID="ID_1967255798" CREATED="1548592167079" MODIFIED="1548592220944"/>
</node>
</node>
<node TEXT="&#x9632;&#x6d2a;&#x7de9;&#x885d;&#x7ad9;" ID="ID_1734315432" CREATED="1548590775410" MODIFIED="1548590807940">
<node TEXT="&#x6574;&#x500b;&#x5712;&#x5340;&#x64c1;&#x6709;&#x5927;&#x91cf;&#x9592;&#x7f6e;&#x7684;&#x6c34;&#x69fd;&#x5bb9;&#x91cf;&#xff0c;&#x5728;&#x5f37;&#x964d;&#x96e8;&#x548c;&#x98b1;&#x98a8;&#x4f86;&#x81e8;&#x6642;&#x53ef;&#x4ee5;&#x5c07;&#x6d2a;&#x6c34;&#x66ab;&#x6642;&#x6eef;&#x7559;&#xff0c;&#x5c0d;&#x9644;&#x8fd1;&#x7684;&#x90fd;&#x5e02;&#x793e;&#x5340;&#x6709;&#x6566;&#x89aa;&#x7766;&#x9130;&#x7684;&#x6548;&#x679c;" ID="ID_350395168" CREATED="1548590808760" MODIFIED="1548591856658"/>
<node TEXT="&#x5982;&#x679c;&#x4e0b;&#x6e38;&#x5730;&#x5340;&#x767c;&#x751f;&#x6c34;&#x60a3;&#xff0c;&#x8d85;&#x904e;&#x4e0b;&#x65b9;&#x6c34;&#x69fd;&#x7684;&#x5bb9;&#x91cf;&#xff0c;&#x53ef;&#x4ee5;&#x8abf;&#x52d5;&#x5e6b;&#x6d66;&#x5c07;&#x6c34;&#x62bd;&#x5230;&#x4e0a;&#x6e38;" ID="ID_1055986326" CREATED="1548592252502" MODIFIED="1548592328948"/>
<node TEXT="&#x7531;ACFit&#x516c;&#x53f8;&#x672c;&#x8eab;&#x8ca0;&#x8cac;&#x57fa;&#x672c;&#x5bb9;&#x91cf;&#xff0c;&#x5c0d;&#x5916;&#x62db;&#x6a19;&#x8d0a;&#x52a9;&#x5546;&#xff0c;&#x82e5;&#x8d0a;&#x52a9;&#x5546;&#x6350;&#x6b3e;&#x5e6b;&#x52a9;&#x5712;&#x5340;&#x71df;&#x904b;&#xff0c;&#x5c31;&#x6703;&#x4ee5;&#x8d0a;&#x52a9;&#x5546;&#x540d;&#x7fa9;&#x589e;&#x8a2d;&#x984d;&#x5916;&#x6d2a;&#x6c34;&#x6eef;&#x7559;&#x5bb9;&#x91cf;" ID="ID_1649290053" CREATED="1548591682613" MODIFIED="1548591814948"/>
</node>
<node TEXT="&#x529f;&#x80fd;&#x6027;&#x4eba;&#x5de5;&#x6fd5;&#x5730;" ID="ID_413003117" CREATED="1548593011656" MODIFIED="1548593019002">
<node TEXT="&#x8a2d;&#x7f6e;&#x4e3b;&#x8981;&#x76ee;&#x7684;&#x4e0d;&#x662f;&#x6062;&#x5fa9;&#x751f;&#x614b;&#xff0c;&#x800c;&#x662f;&#x5c07;&#x5404;&#x7a2e;&#x8f15;&#x5ea6;&#x6c59;&#x67d3;&#x7684;&#x6c11;&#x751f;&#x5ee2;&#x6c34;&#x8f49;&#x5316;&#x6210;&#x6e05;&#x6de8;&#x53ef;&#x5229;&#x7528;&#x7684;&#x72c0;&#x614b;&#xff0c;" ID="ID_705581595" CREATED="1548593019752" MODIFIED="1548593070610"/>
<node TEXT="&#x5404;&#x7a2e;&#x986f;&#x82b1;&#x6fd5;&#x5730;&#x690d;&#x7269;(&#x5e03;&#x888b;&#x84ee;/&#x6c34;&#x84d1;&#x8863;/&#x99ac;&#x978d;&#x85e4;/&#x7f8e;&#x4eba;&#x8549;)&#x53ef;&#x4ee5;&#x70ba;&#x5712;&#x5340;&#x589e;&#x6dfb;&#x7f8e;&#x89c0;&#x6027;" ID="ID_784826857" CREATED="1548593216775" MODIFIED="1548593322612"/>
<node TEXT="&#x5712;&#x5340;&#x5167;&#x7684;&#x6c34;&#x6703;&#x5f62;&#x6210;&#x4e00;&#x500b;&#x534a;&#x5c01;&#x9589;&#x5faa;&#x74b0;&#xff0c;&#x540c;&#x6a23;&#x5bb9;&#x7a4d;&#x7684;&#x6c34;&#x53ef;&#x4ee5;&#x5148;&#x88ab;&#x62ff;&#x4f86;&#x6d17;&#x8863;&#x670d;&#xff0c;&#x63a5;&#x4e0b;&#x4f86;&#x704c;&#x6e89;&#x6fd5;&#x5730;&#x5167;&#x7684;&#x690d;&#x7269;&#xff0c;&#x6700;&#x5f8c;&#x6210;&#x70ba;&#x6c96;&#x6d17;&#x5ec1;&#x6240;&#x7684;&#x6c34;&#x6e90;&#x6216;&#x662f;&#x9032;&#x5165;&#x84c4;&#x80fd;&#x6c34;&#x6c60;&#x6210;&#x70ba;&#x904b;&#x4f5c;&#x7528;&#x6c34;" ID="ID_1452016157" CREATED="1548593071050" MODIFIED="1548593199934"/>
</node>
</node>
</node>
</node>
</map>
