//!!!!REMOVED MSIE detecting mechanism
var container, stats;
var camera, scene, renderer, light;
var backLightA, backLightB, ambientLight;
var controls;
var mesh;
var renderer_is_webgl;
var addonMod;


//!!!!!!!!!!!!!Viewer mode part, can only do the preview over the model. But the vision is free for 360 degree rotation
//called in the canvas.js to load the resulting 3d model(obj_data) in viewer(viewerId)
function load_viewer(obj_data, viewerId) {
    //call function to initialize html viewer's 3d environment
    load_scene(viewerId);
    //initialize a new OBJloader instance and parce the 3d model(obj_data) to displayable format
    loader = new THREE.OBJLoader();
    object = loader.parse(obj_data);
    object.children[0].geometry.computeFaceNormals();
    geometry = object.children[0].geometry;

    // Fixes flip of model for printing, to display it as modelled
    // var flipMatrix = new THREE.Matrix4();
    // flipMatrix.set(-1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);
    // geometry.applyMatrix(flipMatrix);

    THREE.GeometryUtils.center(geometry);
    //Error prevention for webgl absence
    if (!renderer_is_webgl) {
        mesh = new THREE.SceneUtils.createMultiMaterialObject(
            geometry, [
        new THREE.MeshBasicMaterial({
                    color: 0x067777
                }),
        new THREE.MeshBasicMaterial({
                    color: 0x5effff
                })
      ]
        );
        /*} else if ($.browser.msie) {
          mesh = new THREE.SceneUtils.createMultiMaterialObject(geometry, [new THREE.MeshPhongMaterial( { ambient: 0x888888, color: 0x19A8CB, specular: 0x49D8FB, shininess: 50, perPixel: false, overdraw: true } ), new THREE.MeshBasicMaterial({ color: 0x3388dd } )] ); */
    } else {
        //Otherwise just create the mesh from the geometry(which is generated from obj_data)
        mesh = new THREE.SceneUtils.createMultiMaterialObject(geometry, [new THREE.MeshPhongMaterial({
            ambient: 0x444444,
            color: 0x19A8CB,
            specular: 0x49D8FB,
            shininess: 50,
            perPixel: false,
            overdraw: true
        }), new THREE.MeshBasicMaterial({
            color: 0x3388dd,
            wireframe: true,
            transparent: true,
            opacity: 0.15
        })]);
    }
    //light.target = mesh;

    //mesh.rotation.y = Math.PI;

    /*THREE.SceneUtils.traverseHierarchy(mesh, function (mesh) {
    mesh.doubleSided = true;
	mesh.flipSided = true;
  });
  */

    //geometry.castShadow = true;
    //geometry.receiveShadow = true;
    scene.traverse(function (mesh) {
        mesh.doubleSided = true;
        mesh.flipSided = true;
    });
    mesh.rotation.set(180, 180, 0);

    scene.add(mesh);
    //camera.lookAt(geometry);
    light.lookAt(geometry);
    //if (!$.browser.msie) {
    backLightA.lookAt(geometry);
    backLightB.lookAt(geometry);
    //}
    ani(new Date().getTime());
}
//special "animate" function only called in this js file, with some debugging function(now commented)
function ani(t) {
    //  console.log(camera.position.x + " , " + camera.position.y + " , " + camera.position.z);
    //light.target = scene.position;
    requestAnimationFrame(ani, renderer.domElement);
}

function resetViewerCamera() {
    camera.position.set(0, 0, 1000);
}

//get html element and set up viewer environment including scene, camera, and renderer
function load_scene(viewerId) {
    container = document.getElementById(viewerId);
    width = container.style.width.replace('px', '');
    height = container.style.height.replace('px', '');

    // Scene & Camera
    scene = new THREE.Scene();

    camera = new THREE.PerspectiveCamera(40, width / height, 1, 2000);
    resetViewerCamera();
    scene.add(camera);

    light = new THREE.SpotLight();
    light.position.set(40, 80, 150);
    light.castShadow = true;
    scene.add(light);

    //if (!$.browser.msie) {
    ambientLight = new THREE.AmbientLight(0xaaaaaa);
    scene.add(ambientLight);

    backLightA = new THREE.SpotLight();
    backLightA.position.set(-40, -80, -150);
    backLightA.castShadow = false;
    scene.add(backLightA);

    backLightB = new THREE.SpotLight();
    backLightB.position.set(80, 40, 150);
    backLightB.castShadow = false;
    scene.add(backLightB);
    //}

    // Controls
    controls = new THREE.TrackballControls(camera, container);
    controls.rotateSpeed = 4.0;
    controls.zoomSpeed = 1.2;
    controls.panSpeed = 0.8;
    controls.noZoom = false;
    controls.noPan = false;
    controls.staticMoving = true;
    controls.dynamicDampingFactor = 0.1;
    controls.keys = [65, 83, 68];

    // Renderer
    testCanvas = document.createElement('canvas');
    try {
        if (testCanvas.getContext('experimental-webgl')) {
            renderer_is_webgl = true;
            renderer = new THREE.WebGLRenderer({
                antialias: true
            });
        } else {
            renderer_is_webgl = false;
            renderer = new THREE.CanvasRenderer();
        }
    } catch (e) {
        renderer = new THREE.CanvasRenderer();
    }
    renderer.shadowMapEnabled = true;
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);
}

//Not called in this js file, but called in canvas.js
function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
    //stats.update();
}


//!!!!!!!!!!!!!Editor part. Can modify and add specific parts onto the model, but vision is limited to simplify the operation.
function load_editor(obj_data, editorId) {
    //call function to initialize html editor's 3d environment
    load_sceneEditor(editorId);
    //initialize a new OBJloader instance and parce the 3d model(obj_data) to displayable format
    loader = new THREE.OBJLoader();
    object = loader.parse(obj_data);
    object.children[0].geometry.computeFaceNormals();
    geometry = object.children[0].geometry;

    // Fixes flip of model for printing, to display it as modelled
    // var flipMatrix = new THREE.Matrix4();
    // flipMatrix.set(-1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);
    // geometry.applyMatrix(flipMatrix);

    THREE.GeometryUtils.center(geometry);
    //Error prevention for webgl absence
    if (!renderer_is_webgl) {
        mesh = new THREE.SceneUtils.createMultiMaterialObject(
            geometry, [
        new THREE.MeshBasicMaterial({
                    color: 0x067777
                }),
        new THREE.MeshBasicMaterial({
                    color: 0x5effff
                })
      ]
        );
        /*} else if ($.browser.msie) {
          mesh = new THREE.SceneUtils.createMultiMaterialObject(geometry, [new THREE.MeshPhongMaterial( { ambient: 0x888888, color: 0x19A8CB, specular: 0x49D8FB, shininess: 50, perPixel: false, overdraw: true } ), new THREE.MeshBasicMaterial({ color: 0x3388dd } )] ); */
    } else {
        //Otherwise just create the mesh from the geometry(which is generated from obj_data)
        mesh = new THREE.SceneUtils.createMultiMaterialObject(geometry, [new THREE.MeshPhongMaterial({
            ambient: 0x444444,
            color: 0x19A8CB,
            specular: 0x49D8FB,
            shininess: 50,
            perPixel: false,
            overdraw: true
        }), new THREE.MeshBasicMaterial({
            color: 0x3388dd,
            wireframe: true,
            transparent: true,
            opacity: 0.15
        })]);
    }
    //light.target = mesh;

    //mesh.rotation.y = Math.PI;

    /*THREE.SceneUtils.traverseHierarchy(mesh, function (mesh) {
    mesh.doubleSided = true;
	mesh.flipSided = true;
  });
  */

    //geometry.castShadow = true;
    //geometry.receiveShadow = true;
    scene.traverse(function (mesh) {
        mesh.doubleSided = true;
        mesh.flipSided = true;
    });
    mesh.rotation.set(180, 180, 0);

    scene.add(mesh);
    //camera.lookAt(geometry);
    light.lookAt(geometry);
    //if (!$.browser.msie) {
    backLightA.lookAt(geometry);
    backLightB.lookAt(geometry);
    //}
    ani(new Date().getTime());
}

function resetEditorCamera() {
    camera.position.set(0, 0, -200);
}

//get html element and set up editor environment including scene, camera, and renderer
function load_sceneEditor(editorId) {
    container = document.getElementById(editorId);
    width = container.style.width.replace('px', '');
    height = container.style.height.replace('px', '');

    //Add the button elements
    var btnMoveLeft = document.createElement('button');
    btnMoveLeft.textContent = "Move left";
    btnMoveLeft.setAttribute("class", "editBtn");
    btnMoveLeft.style.bottom = "10%";
    btnMoveLeft.style.right = "35%";
    container.appendChild(btnMoveLeft);
    
    var btnMoveRight = document.createElement('button');
    btnMoveRight.textContent = "Move right";
    btnMoveRight.setAttribute("class", "editBtn");
    btnMoveRight.style.bottom = "10%";
    btnMoveRight.style.right = "0%";
    container.appendChild(btnMoveRight);
    
    var btnMoveUp = document.createElement('button');
    btnMoveUp.textContent = "Move up";
    btnMoveUp.setAttribute("class", "editBtn");
    btnMoveUp.style.bottom = "15%";
    btnMoveUp.style.right = "18%";
    container.appendChild(btnMoveUp);
    
    var btnMoveDown = document.createElement('button');
    btnMoveDown.textContent = "Move down";
    btnMoveDown.setAttribute("class", "editBtn");
    btnMoveDown.style.bottom = "0%";
    btnMoveDown.style.right = "18%";
    container.appendChild(btnMoveDown);
    
    
    /*
    <button class="button" style="top:10%;left: 80%" onclick="moveLeft()">  </button>
    <button class="button" style="top:0% ;left: 85%" onclick="moveUp()"> &#8679 </button>
        <button class="button" style="top:10%;left: 90%" onclick="moveRight()"> &#8680 </button>
        <button class="button" style="top:10%;left: 85%" onclick="moveDown()"> &#8681 </button>
        <button class="button" style="left: 65%" onclick="zoomOut()"> + </button>
        <button class="button" style="left: 70%" onclick="zoomIn()"> - </button>
        <button class="button" style="top: 10%;left: 65%" onclick="rotateClock()"> &#8635 </button>
        <button class="button" style="top: 10%;left: 70%" onclick="rotateAnti()"> &#8634 </button>
    */
    //Define the function to handle events
    function onMouseMove(event) {
        event.preventDefault();
        var mouse = new THREE.Vector2();
        if (addonMod) {

            mouse.x = ((event.clientX - container.offsetLeft + document.body.scrollLeft) / container.offsetWidth) * 2 - 1;
            mouse.y = -((event.clientY - container.offsetTop + document.body.scrollTop) / container.offsetHeight) * 2 + 1;
            var vector = new THREE.Vector3(mouse.x, mouse.y, 0);
            vector.unproject(camera);
            var dir = vector.sub(camera.position).normalize();
            var distance = -camera.position.z / dir.z;
            var pos = camera.position.clone().add(dir.multiplyScalar(distance));
            console.log(pos);
            adapterMesh.position.copy(pos);

        }

    };

    function onMouseUp(event) {
        if (addonMod) {
            adapterCSG = THREE.CSG.fromMesh(adapterMesh)
            var result = cubeCSG.union(adapterCSG);
            var mesh = THREE.CSG.toMesh(result, material);
            scene.add(mesh);
            var exporter = new THREE.OBJExporter();
            var result = exporter.parse(mesh);
            document.getElementById("exportText").innerHTML = result.split('\n').join('<br />');

            toggleAddon();
        }

    };



    //Add event listeners
    container.addEventListener("mousemove", onMouseMove, false);
    container.addEventListener("mouseup", onMouseUp, false);
    document.getElementById("addonButton").addEventListener("click", toggleAddon);


    // Scene & Camera
    scene = new THREE.Scene();

    camera = new THREE.PerspectiveCamera(40, width / height, 1, 2000);
    scene.background = new THREE.Color(0xffffff);
    resetEditorCamera();
    scene.add(camera);

    // GRID
    var grid1 = new THREE.GridHelper(SCREEN_WIDTH / 2, 6, 0x444444, 0xe1e2e3);
    grid1.rotation.x = Math.PI / 2;
    scene.add(grid1);

    var grid2 = new THREE.GridHelper(SCREEN_WIDTH / 2, 30, 0x444444, 0xc1c2c3);
    grid2.rotation.x = Math.PI / 2;
    scene.add(grid2);

    light = new THREE.SpotLight();
    light.position.set(40, 80, 150);
    light.castShadow = true;
    scene.add(light);

    //if (!$.browser.msie) {
    ambientLight = new THREE.AmbientLight(0xaaaaaa);
    scene.add(ambientLight);

    backLightA = new THREE.SpotLight();
    backLightA.position.set(-40, -80, -150);
    backLightA.castShadow = false;
    scene.add(backLightA);

    backLightB = new THREE.SpotLight();
    backLightB.position.set(80, 40, 150);
    backLightB.castShadow = false;
    scene.add(backLightB);
    //}



    //test the webgl support and create the Renderer object
    testCanvas = document.createElement('canvas');
    try {
        if (testCanvas.getContext('experimental-webgl')) {
            renderer_is_webgl = true;
            renderer = new THREE.WebGLRenderer({
                antialias: true
            });
        } else {
            renderer_is_webgl = false;
            renderer = new THREE.CanvasRenderer();
        }
    } catch (e) {
        renderer = new THREE.CanvasRenderer();
    }

    renderer.shadowMapEnabled = true;
    renderer.setSize(width, height);
    container.appendChild(renderer.domElement);
}
