<map version="freeplane 1.6.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="WeARFit" FOLDED="false" ID="ID_362164510" CREATED="1517025450167" MODIFIED="1527422245879">
<font SIZE="18"/>
<hook NAME="MapStyle" background="#000000" zoom="2.0">
    <properties fit_to_viewport="false" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#cccccc" BACKGROUND_COLOR="#333333" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<icon BUILTIN="yes"/>
</stylenode>
<stylenode TEXT="mine" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" COLOR="#cccccc" BACKGROUND_COLOR="#333333" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#cccccc" BACKGROUND_COLOR="#333333" SHAPE_HORIZONTAL_MARGIN="10.0 pt" SHAPE_VERTICAL_MARGIN="10.0 pt">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#cccccc" BACKGROUND_COLOR="#333333">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11" COLOR="#cccccc" BACKGROUND_COLOR="#333333"/>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="16" RULE="ON_BRANCH_CREATION"/>
<node TEXT="&#x6982;&#x8981;:&#x5229;&#x7528;&#x96fb;&#x8166;&#x8996;&#x89ba;&#x548c;&#x734e;&#x52f5;&#x6a5f;&#x5236;&#x4f86;&#x5e6b;&#x52a9;&#x7528;&#x6236;&#x6210;&#x529f;&#x57f7;&#x884c;&#x9069;&#x5408;&#x81ea;&#x5df1;&#x7684;&#x904b;&#x52d5;&#x8a08;&#x756b;,&#x9032;&#x800c;&#x6539;&#x8b8a;&#x98f2;&#x98df;&#x548c;&#x4f5c;&#x606f;&#x7fd2;&#x6163;,&#x5354;&#x52a9;&#x4ed6;&#x5011;&#x9054;&#x5230;&#x81ea;&#x6211;&#x6210;&#x9577;&#x7684;&#x76ee;&#x6a19;" POSITION="right" ID="ID_700888609" CREATED="1527422247918" MODIFIED="1528203612496">
<edge COLOR="#00007c"/>
<node TEXT="&#x904b;&#x52d5;&#x8207;&#x6e1b;&#x91cd;&#x8a08;&#x756b;&#x7684;&#x57f7;&#x884c;&#x548c;&#x5f8c;&#x7e8c;&#x7684;&#x7dad;&#x6301;&#x9700;&#x8981;&#x5fc3;&#x7406;&#x610f;&#x5fd7;&#x529b;/&#x6642;&#x9593;&#x7ba1;&#x7406;&#x80fd;&#x529b;/&#x540c;&#x5115;&#x7684;&#x652f;&#x6301;&#x4e0b;&#x624d;&#x80fd;&#x6210;&#x529f;.&#xa;&#x73fe;&#x5728;&#x7684;&#x751f;&#x6d3b;&#x6709;&#x592a;&#x591a;&#x7684;&#x963b;&#x7919;&#x8207;&#x5e72;&#x64fe;&#x6703;&#x8b93;&#x4eba;&#x5403;&#x4e0b;&#x6beb;&#x7121;&#x71df;&#x990a;&#x7684;&#x5783;&#x573e;&#x548c;&#x6c89;&#x8ff7;&#x65bc;&#x8ab2;&#x91d1;&#x904a;&#x6232;&#x5e36;&#x4f86;&#x7684;&#x865b;&#x5e7b;&#x6210;&#x5c31;&#x611f;,&#x800c;WeARFit&#x7684;&#x76ee;&#x7684;&#x662f;&#x5354;&#x52a9;&#x7528;&#x6236;&#x4ee5;&#x6700;&#x5be6;&#x969b;&#x7684;&#x65b9;&#x6cd5;&#x4f86;&#x935b;&#x934a;&#x4ed6;&#x5011;&#x7684;&#x8eab;&#x9ad4;,&#x5efa;&#x7acb;&#x7ba1;&#x7406;&#x6642;&#x9593;&#x548c;&#x884c;&#x7a0b;&#x7684;&#x7d00;&#x5f8b;&#x548c;&#x7fd2;&#x6163;,&#x4e00;&#x6b65;&#x6b65;&#x6392;&#x64e0;&#x6389;&#x751f;&#x6d3b;&#x4e2d;&#x539f;&#x672c;&#x6709;&#x5bb3;&#x7684;&#x5783;&#x573e;&#x98df;&#x7269;&#x8207;&#x6d3b;&#x52d5;,&#x9032;&#x800c;&#x6210;&#x70ba;&#x4e00;&#x500b;&#x5145;&#x6eff;&#x7af6;&#x722d;&#x529b;&#x7684;&#x4eba;." ID="ID_124200715" CREATED="1528202096190" MODIFIED="1528203567144"/>
<node TEXT="WeARFit&#x7684;&#x904b;&#x52d5;&#x4ee5;&#x7c21;&#x55ae;,&#x5b89;&#x5168;,&#x4e0d;&#x9808;&#x7279;&#x6b8a;&#x5668;&#x5177;&#x7684;&#x5f92;&#x624b;&#x6838;&#x5fc3;&#x8a13;&#x7df4;&#x70ba;&#x4e3b;,&#x8b93;&#x7528;&#x6236;&#x80fd;&#x990a;&#x6210;&#x7fd2;&#x6163;&#x4e26;&#x4e14;&#x5bb9;&#x6613;&#x914d;&#x5408;&#x81ea;&#x5df1;&#x7684;&#x751f;&#x6d3b;&#x4f5c;&#x606f;,&#x73fe;&#x5728;&#x6709;&#x592a;&#x591a;&#x4eba;&#x4ea4;&#x4e86;&#x5065;&#x8eab;&#x623f;&#x8cbb;&#x7528;&#x537b;&#x53c8;&#x81ea;&#x5df1;&#x627e;&#x51fa;&#x5404;&#x7a2e;&#x7406;&#x7531;&#x85c9;&#x53e3;&#x8b93;&#x81ea;&#x5df1;&quot;&#x88ab;&#x8feb;&quot;&#x767d;&#x767d;&#x6d6a;&#x8cbb;&#x4e86;&#x9019;&#x4e9b;&#x9322;,&#x800c;WeARFit&#x53ea;&#x8981;&#x6709;&#x624b;&#x6a5f;&#x548c;&#x7db2;&#x8def;&#x4ee5;&#x53ca;&#x4e00;&#x500b;&#x5c0f;&#x5c0f;&#x7684;&#x7a7a;&#x9593;&#x5c31;&#x53ef;&#x4ee5;&#x5c55;&#x958b;&#x904b;&#x52d5;&#x8a13;&#x7df4;,&#x800c;&#x4e14;&#x6bcf;&#x4e00;&#x6b21;&#x904b;&#x52d5;&#x884c;&#x7a0b;&#x7684;&#x5b8c;&#x6210;&#x90fd;&#x4f34;&#x96a8;&#x8457;&#x9000;&#x8cbb;&#x7684;&#x734e;&#x52f5;&#x6a5f;&#x5236;,&#x7576;&#x7528;&#x6236;&#x5b8c;&#x6210;&#x6211;&#x5011;&#x7d66;&#x7684;&#x9019;&#x500b;&#x6708;&#x7684;&#x904b;&#x52d5;&#x4efb;&#x52d9;,&#x4ed6;&#x7b49;&#x65bc;&#x540c;&#x6642;&#x5f97;&#x5230;&#x4e86;&#x514d;&#x8cbb;&#x7684;&#x670d;&#x52d9;,&#x8eab;&#x9ad4;&#x7684;&#x6539;&#x5584;,&#x81ea;&#x6211;&#x5be6;&#x73fe;&#x7684;&#x6210;&#x5c31;&#x611f;,&#x9084;&#x6709;&#x6210;&#x529f;&#x8005;&#x4e0d;&#x53ef;&#x6216;&#x7f3a;&#x7684;&quot;&#x57f7;&#x884c;&#x529b;&quot;&#x548c;&quot;&#x6642;&#x9593;&#x7ba1;&#x7406;&#x80fd;&#x529b;&quot;." ID="ID_920783256" CREATED="1528203315881" MODIFIED="1528203363742"/>
<node TEXT="&#x66f4;&#x6709;&#x6bc5;&#x529b;,&#x53ef;&#x4ee5;&#x9023;&#x7e8c;&#x9054;&#x6a19;&#x7684;&#x4eba;&#x5c07;&#x6703;&#x7372;&#x5f97;&#x734e;&#x91d1;&#x62bd;&#x734e;&#x7684;&#x6a5f;&#x6703;,&#x800c;&#x734e;&#x91d1;&#x548c;&#x4ed6;&#x7684;&#x8868;&#x73fe;&#x5448;&#x6b63;&#x6bd4;,&#x662f;&#x6700;&#x516c;&#x6b63;&#x4e14;&#x6700;&#x9f13;&#x52f5;&quot;&#x52aa;&#x529b;&#x548c;&#x6bc5;&#x529b;&quot;&#x7684;&#x6a02;&#x900f;.&#xa;WeARFIt&#x548c;&#x4e00;&#x822c;app&#x5e02;&#x5834;&#x4e0a;Tititainment&#x985e;&#x578b;&#x7684;&#x525d;&#x524a;&#x6027;&#x8ab2;&#x91d1;&#x904a;&#x6232;&#x4e0d;&#x540c;,&#x6211;&#x5011;&#x8b93;&#x4f7f;&#x7528;&#x8005;&#x5728;&#x6bcf;&#x4e00;&#x671f;&#x7684;&#x5be6;&#x8e10;&#x4e0b;&#x8b8a;&#x5f97;&#x66f4;&#x52a0;&#x5065;&#x5eb7;,&#x6210;&#x529f;&#x4e14;&#x5bcc;&#x8db3;!" ID="ID_749937664" CREATED="1528203347462" MODIFIED="1528203515817"/>
<node TEXT="&#x734e;&#x52f5;&#x539f;&#x5247;:&#x53ea;&#x8981;&#x52d5;&#x4f5c;&#x6709;&#x4f5c;&#x5230;,&#x7dad;&#x6301;&#x6642;&#x9593;&#x5920;&#x9577;,&#x904b;&#x52d5;&#x7b26;&#x5408;&#x8a08;&#x756b;&#x5c31;&#x7d66;&#x8207;&#x734e;&#x52f5;&#x9ede;&#x6578;,&#x4e0d;&#x63a1;&#x8a08;&#x6700;&#x7d42;&#x7684;&#x5065;&#x8eab;&#x7d50;&#x679c;,&#x56e0;&#x70ba;&#x90a3;&#x53d7;&#x5929;&#x751f;&#x7684;&#x9ad4;&#x8cea;&#x5f71;&#x97ff;&#x6975;&#x5927;" ID="ID_879756532" CREATED="1527422404054" MODIFIED="1527422563169"/>
</node>
<node TEXT="&#x4e00;&#x670d;&#x52d9;&#x9805;&#x76ee;" POSITION="right" ID="ID_986495778" CREATED="1527422570135" MODIFIED="1527422579549">
<edge COLOR="#7c007c"/>
<node TEXT="A.&#x904b;&#x52d5;&#x6559;&#x5b78;" FOLDED="true" ID="ID_1993741466" CREATED="1527422581521" MODIFIED="1527422596327">
<node TEXT="&#x63d0;&#x4f9b;&#x7c21;&#x55ae;&#x6613;&#x4e0a;&#x624b;&#x7684;&#x904b;&#x52d5;&#x793a;&#x7bc4;&#x6559;&#x5b78;&#x52d5;&#x756b;,&#x5305;&#x62ec;&#x6b63;&#x9762;&#x548c;&#x5074;&#x9762;&#x7684;&#x93e1;&#x982d;" ID="ID_766276358" CREATED="1527422598856" MODIFIED="1527422637818"/>
</node>
<node TEXT="B.&#x904b;&#x52d5;&#x884c;&#x4e8b;&#x66c6;" FOLDED="true" ID="ID_555647609" CREATED="1527422640914" MODIFIED="1527422653696">
<node TEXT="&#x8b93;&#x7528;&#x6236;&#x53ef;&#x4ee5;&#x5728;&#x884c;&#x4e8b;&#x66c6;&#x4e0a;&#x9762;&#x5beb;&#x4e0b;&#x6bcf;&#x500b;&#x6708;&#x7684;&#x904b;&#x52d5;&#x8a08;&#x756b;,&#x4fdd;&#x7559;PlanB&#x7684;&#x6642;&#x6bb5;&#x8b93;&#x539f;&#x904b;&#x52d5;&#x6642;&#x6bb5;&#x78b0;&#x4e0a;&#x7dca;&#x6025;&#x4e8b;&#x4ef6;&#x6642;&#x53ef;&#x4ee5;&#x518d;&#x4e4b;&#x5f8c;&#x88dc;&#x6551;," ID="ID_1795232543" CREATED="1527422655181" MODIFIED="1527422754299"/>
<node TEXT="&#x6bcf;30&#x5929;&#x7522;&#x751f;&#x4e00;&#x6b21;&#x6210;&#x679c;&#x5206;&#x6790;,&#x7528;&#x5361;&#x901a;&#x5316;&#x7684;&#x65b9;&#x5f0f;&#x5448;&#x73fe;&#x7576;&#x6708;&#x7684;&#x904b;&#x52d5;&#x5468;&#x8a18;" ID="ID_982578596" CREATED="1527422756050" MODIFIED="1527422836804"/>
</node>
<node TEXT="C.&#x904b;&#x52d5;&#x71b1;&#x91cf;&#x6d88;&#x8017;&#x8a66;&#x7b97;" FOLDED="true" ID="ID_1893506853" CREATED="1527422838443" MODIFIED="1527422860461">
<node TEXT="&#x4ee5;&#x8eab;&#x9ad8;&#x548c;&#x9ad4;&#x91cd;&#x70ba;&#x57fa;&#x6e96;&#x7b97;&#x51fa;&#x71b1;&#x91cf;&#x6d88;&#x8017;&#x7684;&#x53c3;&#x8003;&#x503c;" ID="ID_1172671895" CREATED="1527422861930" MODIFIED="1527422885023"/>
</node>
<node TEXT="D.AR&#x904b;&#x52d5;&#x76e3;&#x6e2c;" FOLDED="true" ID="ID_1434242288" CREATED="1527422886273" MODIFIED="1527423036087">
<node TEXT="&#x4ee5;&#x96fb;&#x8166;&#x8996;&#x89ba;&#x548c;AR&#x7cfb;&#x7d71;&#x4f86;&#x53ca;&#x6642;&#x76e3;&#x6e2c;&#x4f7f;&#x7528;&#x8005;&#x7684;&#x52d5;&#x4f5c;,&#xa;&#x770b;&#x770b;&#x4f7f;&#x7528;&#x8005;&#x662f;&#x5426;&#x771f;&#x7684;&#x505a;&#x5230;&#x4e86;&#x8a72;&#x505a;&#x7684;&#x6b21;&#x6578;,&#x52d5;&#x4f5c;&#x662f;&#x5426;&#x6a19;&#x6e96;&#x4ee5;&#x9632;&#x904b;&#x52d5;&#x50b7;&#x5bb3;." ID="ID_1371122481" CREATED="1527422906163" MODIFIED="1527423010805"/>
</node>
<node TEXT="E.Win It Back" FOLDED="true" ID="ID_592817806" CREATED="1527423081237" MODIFIED="1527423122248">
<node TEXT="&#x5ef6;&#x4f38;D.&#x7684;&#x90e8;&#x5206;,&#x5982;&#x679c;&#x6bcf;&#x6b21;&#x7684;&#x904b;&#x52d5;&#x8868;&#x73fe;(&#x6301;&#x7e8c;&#x6642;&#x9593;&#x548c;&#x52d5;&#x4f5c;&#x6e96;&#x78ba;&#x5ea6;)&#x9054;&#x5230;&#x6a19;&#x6e96;,&#x5c31;&#x7d66;&#x4e88;&#x90e8;&#x5206;&#x7684;&#x9000;&#x8cbb;,&#x4e26;&#x4e14;&#x7372;&#x5f97;&#x5e74;&#x5ea6;&#x62bd;&#x734e;&#x7684;&#x52a0;&#x6210;&#x9ede;&#x6578;,&#xa;&#x7576;&#x4f7f;&#x7528;&#x8005;&#x5b8c;&#x5168;&#x9054;&#x5230;&#x9019;30&#x5929;&#x6240;&#x9810;&#x5b9a;&#x8981;&#x505a;&#x7684;&#x904b;&#x52d5;&#x6b21;&#x6578;&#x8207;&#x904b;&#x52d5;&#x91cf;,&#x6700;&#x5927;&#x53ef;&#x4ee5;&#x7372;&#x5f97;80%&#x7684;&#x9000;&#x8cbb;," ID="ID_1414163665" CREATED="1527423123374" MODIFIED="1527423645495"/>
<node TEXT="&#x6301;&#x7e8c;&#x8d85;&#x904e;30&#x5206;&#x9418;&#x734e;&#x52f5;1&#x9ede;,&#x8d85;&#x904e;1&#x5c0f;&#x6642;&#x734e;&#x52f5;3&#x9ede;&#xa;&#x52d5;&#x4f5c;&#x6b63;&#x78ba;&#x5ea6;&#x904e;6&#x6210;&#x734e;&#x52f5;1&#x9ede;,&#x8d85;&#x904e;8&#x6210;&#x734e;&#x52f5;&#x2c7;3&#x9ede;" ID="ID_1740371049" CREATED="1527424769795" MODIFIED="1527424925767"/>
</node>
<node TEXT="F.Win It Back Plus" FOLDED="true" ID="ID_281351207" CREATED="1527423398825" MODIFIED="1527423427149">
<node TEXT="Optional,&#x4f7f;&#x7528;&#x8005;&#x53ef;&#x4ee5;&#x9078;&#x64c7;&#x5728;&#x6bcf;&#x6b21;&#x7684;&#x904b;&#x52d5;&#x6642;&#x518d;&#x52a0;&#x5165;15&#x5206;&#x9418;&#x7684;AR&#x4e92;&#x52d5;&#x904a;&#x6232;&#x6027;&#x8cea;&#x7684;&#x904b;&#x52d5;,&#x7528;&#x6236;&#x7684;&#x52d5;&#x4f5c;&#x53ef;&#x5206;&#x70ba;ABC&#x6216;O&#x548c;X,&#x807d;&#x5230;&#x4ee5;&#x8d0a;&#x52a9;&#x5546;&#x7684;&#x5ee3;&#x544a;&#x8a5e;&#x6539;&#x88dd;&#x7684;&#x984c;&#x76ee;&#x6642;,&#x8981;&#x4f5c;&#x51fa;&#x6b63;&#x78ba;&#x7684;&#x76f8;&#x5c0d;&#x61c9;&#x52d5;&#x4f5c;,&#x7d50;&#x679c;&#x53ca;&#x683c;&#x4fbf;&#x80fd;&#x5f97;&#x5230;&#x9000;&#x8cbb;,30&#x5929;&#x5167;&#x6700;&#x5927;&#x53ef;&#x4ee5;&#x7372;&#x5f97;20%&#x7684;&#x9000;&#x8cbb;" ID="ID_490866439" CREATED="1527423428634" MODIFIED="1527423920575"/>
</node>
<node TEXT="G.Win It Back Hardcore" ID="ID_86391670" CREATED="1527423921638" MODIFIED="1527423941769">
<node TEXT="&#x5c0d;&#x65bc;hard core &#x5065;&#x8eab;&#x6216;&#x7626;&#x8eab;&#x8005;&#x7684;&#x670d;&#x52d9;,E.&#x548c;F.&#x7684;&#x9000;&#x8cbb;&#x6bd4;&#x4f8b;&#x5206;&#x5225;&#x6539;&#x70ba;40%&#x548c;10%,&#x5269;&#x4e0b;&#x7684;50%&#x6539;&#x70ba;&#x98f2;&#x98df;&#x63a7;&#x5236;,&#x4f7f;&#x7528;&#x8005;&#x5fc5;&#x9808;&#x5728;&#x6bcf;&#x5468;&#x7684;&#x5341;&#x6b21;&#x6b63;&#x9910;&#x6642;&#x9593;&#x7528;&#x624b;&#x6a5f;&#x6263;&#x6b3e;&#x8cfc;&#x8cb7;&#x7279;&#x5b9a;&#x7684;&#x98df;&#x54c1;(&#x7d71;&#x4e00;&#x7121;&#x7cd6;&#x8c46;&#x6f3f;,&#x8d85;&#x5546;&#x6c34;&#x679c;&#x7d44;&#x5408;,&#x8336;&#x8449;&#x86cb;,etc),&#x9a57;&#x8b49;&#x81ea;&#x5df1;&#x662f;&#x5426;&#x771f;&#x7684;&#x5728;&#x6bcf;&#x5929;&#x6b63;&#x78ba;&#x7684;&#x6642;&#x9593;&#x5403;&#x4e86;&#x6b63;&#x78ba;&#x7684;&#x6771;&#x897f;,&#x82e5;&#x5728;&#x6b64;&#x65b9;&#x6848;&#x9054;&#x6a19;,&#x6700;&#x9ad8;&#x9000;&#x8cbb;50%,&#x52a0;&#x6210;&#x9ede;&#x6578;&#x70ba;E.&#x548c;F.&#x7684;&#x4e94;&#x500d;" ID="ID_893907401" CREATED="1527423943892" MODIFIED="1528204323811"/>
</node>
<node TEXT="H.&#x904b;&#x52d5;&#x9031;&#x5831;" ID="ID_426070732" CREATED="1527424301338" MODIFIED="1527424313041">
<node TEXT="&#x63d0;&#x4f9b;&#x7528;&#x6236;&#x6700;&#x65b0;&#x7684;&#x5065;&#x5eb7;&#x751f;&#x6d3b;&#x8cc7;&#x8a0a;,&#x4e3b;&#x984c;&#x5305;&#x62ec;&#x500b;&#x4eba;&#x6210;&#x9577;,&#x6642;&#x9593;&#x7ba1;&#x7406;,&#x904b;&#x52d5;&#x50b7;&#x5bb3;&#x9810;&#x9632;&#x8207;&#x8655;&#x7406;,&#x7761;&#x7720;&#x7ba1;&#x7406;,&#x98f2;&#x98df;&#x63a7;&#x5236;." ID="ID_566867635" CREATED="1527424314010" MODIFIED="1527424409393"/>
</node>
<node TEXT="I.Fitlottory" ID="ID_514024822" CREATED="1527424411524" MODIFIED="1527424433871">
<node TEXT="&#x7576;&#x4f7f;&#x7528;&#x8005;&#x7d2f;&#x8a08;&#x9054;&#x6a19;3&#x671f;,&#x5373;&#x53ef;&#x65bc;&#x4e0b;&#x4e00;&#x500b;&#x6708;&#x53c3;&#x52a0;&#x62bd;&#x734e;,Advance&#x548c;HardCore&#x7684;&#x4f7f;&#x7528;&#x8005;&#x5728;&#x540c;&#x4e00;&#x7d44;&#x5167;&#x62bd;&#x734e;,&#x734e;&#x54c1;&#x70ba;&#x73fe;&#x91d1;,&#x4e2d;&#x734e;&#x8005;&#x7684;&#x734e;&#x91d1;&#x6703;&#x518d;&#x4e58;&#x4e0a;&#x4f7f;&#x7528;&#x8005;&#x7d2f;&#x8a08;&#x7684;&#x52a0;&#x6210;&#x9ede;&#x6578;.&#x4e00;&#x5e74;&#x958b;&#x734e;&#x56db;&#x6b21;," ID="ID_321349431" CREATED="1527424435793" MODIFIED="1527990155521"/>
<node TEXT="&#x5982;&#x679c;&#x7576;&#x671f;&#x6c92;&#x6709;&#x4e2d;&#x734e;,&#x52a0;&#x6210;&#x9ede;&#x6578;&#x4ecd;&#x7136;&#x53ef;&#x4ee5;&#x7e7c;&#x627f;&#x539f;&#x672c;&#x7684;&#x56db;&#x5206;&#x4e4b;&#x4e00;,&#x52a0;&#x5165;&#x4e0b;&#x4e00;&#x6b21;&#x9054;&#x6a19;&#x4e09;&#x671f;&#x7684;&#x734e;&#x91d1;&#x52a0;&#x6210;,&#x4ee5;&#x6b64;&#x734e;&#x52f5;&#x6301;&#x7e8c;&#x904b;&#x52d5;&#x7684;&#x7fd2;&#x6163;&#x4e26;&#x4e14;&#x589e;&#x52a0;&#x4f7f;&#x7528;&#x8005;&#x7684;&#x5fe0;&#x8aa0;&#x5ea6;(&#x7d2f;&#x7a4d;&#x8d8a;&#x591a;&#x9ede;&#x6578;,&#x8d8a;&#x96e3;&#x653e;&#x68c4;&#x53c3;&#x52a0;&#x4e0b;&#x4e00;&#x671f;)" ID="ID_1440715982" CREATED="1527989850346" MODIFIED="1527990492984"/>
<node TEXT="&#x548c;&#x4e00;&#x822c;&#x7684;&#x6a02;&#x900f;&#x734e;&#x4e0d;&#x540c;,&#x53c3;&#x8207;&#x8005;&#x4e0d;&#x662f;&#x9760;&#x6295;&#x6ce8;&#x91d1;&#x984d;&#x591a;&#x5be1;&#x800c;&#x662f;&#x904b;&#x52d5;&#x7684;&#x8868;&#x73fe;&#x4f86;&#x63d0;&#x5347;&#x81ea;&#x5df1;&#x4e2d;&#x734e;&#x7684;&#x671f;&#x671b;&#x503c;,&#x53ea;&#x8981;&#x52aa;&#x529b;&#x5c31;&#x53ef;&#x4ee5;&#x7372;&#x5f97;&#x66f4;&#x591a;,&#x7531;&#x65bc;&#x7d2f;&#x7a4d;&#x52a0;&#x6210;&#x9ede;&#x6578;&#x7684;&#x591a;&#x5be1;,&#x4e8c;&#x734e;&#x52a0;&#x6210;&#x5f8c;&#x7684;&#x5be6;&#x969b;&#x91d1;&#x984d;&#x53ef;&#x80fd;&#x5c07;&#x6703;&#x9060;&#x8d85;&#x904e;&#x982d;&#x734e;" ID="ID_726382126" CREATED="1527990267906" MODIFIED="1527990669660"/>
<node TEXT="&#x6bcf;&#x6b21;&#x4f7f;&#x7528;&#x8005;&#x548c;&#x4f3a;&#x670d;&#x5668;&#x7aef;&#x9023;&#x7dda;&#x6e96;&#x5099;&#x958b;&#x59cb;&#x4e00;&#x500b;&#x904b;&#x52d5;&#x7684;&#x884c;&#x7a0b;&#x6642;,server&#x6703;&#x4e82;&#x6578;&#x7522;&#x751f;&#x4e00;&#x7d44;&#x904b;&#x52d5;&#x9805;&#x76ee;&#x7684;&#x6392;&#x5217;&#x7d44;&#x5408;,&#x5982;&#x540c;hash&#x503c;&#x4e00;&#x822c;,&#x5728;&#x904b;&#x52d5;&#x9032;&#x884c;&#x7684;&#x9019;&#x4e00;&#x5230;&#x5169;&#x5c0f;&#x6642;&#x5167;&#x5fc5;&#x9808;&#x662f;&#x7368;&#x4e00;&#x7121;&#x4e8c;&#x7684;,&#x4ee5;&#x6b64;&#x6a5f;&#x5236;&#x9810;&#x9632;&#x7528;&#x6236;&#x540c;&#x4e00;&#x4eba;&#x958b;&#x8a2d;&#x591a;&#x91cd;&#x5e33;&#x865f;&#x5728;&quot;&#x540c;&#x4e00;&#x6642;&#x9593;&quot;&#x7d2f;&#x7a4d;&#x591a;&#x4eba;&#x7684;&#x62bd;&#x734e;&#x8cc7;&#x683c;&#x8207;&#x52a0;&#x6210;&#x9ede;&#x6578;." ID="ID_587587338" CREATED="1527991680554" MODIFIED="1527992461406"/>
</node>
<node TEXT="J.We Are Fit" ID="ID_1571978480" CREATED="1528203654502" MODIFIED="1528203674611">
<node TEXT="&#x5229;&#x7528;&#x540c;&#x5115;&#x7684;&#x529b;&#x91cf;&#x4f86;&#x8b93;&#x7528;&#x6236;&#x5f7c;&#x6b64;&#x6fc0;&#x52f5;,&#x7528;&#x6236;&#x53ef;&#x4ee5;&#x5f7c;&#x6b64;&#x9080;&#x7d04;&#x5c0d;&#x65b9;&#x540c;&#x6642;&#x9032;&#x884c;&#x904b;&#x52d5;&#x884c;&#x7a0b;,&#x5982;&#x679c;&#x5169;&#x908a;&#x6700;&#x5f8c;&#x90fd;&#x5b8c;&#x6210;&#x904b;&#x52d5;&#x4efb;&#x52d9;&#x4e14;&#x52d5;&#x4f5c;&#x5224;&#x5b9a;&#x9054;&#x6a19;,&#x8a72;&#x6b21;Fitlottory&#x7684;&#x734e;&#x52f5;&#x52a0;&#x6210;&#x9ede;&#x6578;&#x8b8a;&#x70ba;&#x5169;&#x500d;" ID="ID_570790732" CREATED="1528203676267" MODIFIED="1528203978379"/>
</node>
</node>
<node TEXT="&#x6536;&#x8cbb;&#x65b9;&#x6848;" POSITION="right" ID="ID_686674132" CREATED="1527425034465" MODIFIED="1527425043921">
<edge COLOR="#007c7c"/>
<node TEXT="WeArFit Light" ID="ID_1431525064" CREATED="1527425045108" MODIFIED="1527425076101">
<node TEXT="&#x514d;&#x8cbb;" ID="ID_332833207" CREATED="1527425097838" MODIFIED="1527425103972"/>
<node TEXT="&#x76ee;&#x6a19;&#x65cf;&#x7fa4;:&#x60f3;&#x8981;&#x5617;&#x9bae;&#x8a66;&#x6c34;&#x6eab;&#x7684;&#x4eba;," ID="ID_847159984" CREATED="1527425077304" MODIFIED="1527425148858"/>
<node TEXT="&#x53ef;&#x5f97;&#x670d;&#x52d9;&#x9805;&#x76ee;:A.B.C.D.H" ID="ID_1358695851" CREATED="1527425262990" MODIFIED="1527425289391"/>
</node>
<node TEXT="WeARFit Advance" ID="ID_485140599" CREATED="1527425165373" MODIFIED="1527425174959">
<node TEXT="NTD500/month" ID="ID_1735519345" CREATED="1527425176131" MODIFIED="1527425191238"/>
<node TEXT="&#x76ee;&#x6a19;&#x65cf;&#x7fa4;:&#x771f;&#x7684;&#x60f3;&#x6e1b;&#x91cd;&#x4f46;&#x76ee;&#x6a19;&#x4e0d;&#x6703;&#x592a;&#x9ad8;" ID="ID_930173111" CREATED="1527425192227" MODIFIED="1527425245582"/>
<node TEXT="&#x53ef;&#x5f97;&#x670d;&#x52d9;&#x9805;&#x76ee;:ABCDEFHIJ" ID="ID_1016127700" CREATED="1527425291491" MODIFIED="1528203990342"/>
</node>
<node TEXT="WeARFit Hardcore" ID="ID_963475922" CREATED="1527425316094" MODIFIED="1527425330644">
<node TEXT="NTD1000/month" ID="ID_858703118" CREATED="1527425335036" MODIFIED="1527425345378"/>
<node TEXT="&#x76ee;&#x6a19;&#x65cf;&#x7fa4;:&#x7a4d;&#x6975;&#x7684;&#x5065;&#x8eab;/&#x7626;&#x8eab;&#x8005;" ID="ID_1364247934" CREATED="1527425345941" MODIFIED="1527425370841"/>
<node TEXT="&#x53ef;&#x5f97;&#x670d;&#x52d9;&#x9805;&#x76ee;:ABCDEFGHIJ" ID="ID_494674047" CREATED="1527425372467" MODIFIED="1528203996973"/>
</node>
<node TEXT="WeARFIT Essentialist" ID="ID_415612307" CREATED="1527425395880" MODIFIED="1527425408711">
<node TEXT="NTD600&#x55ae;&#x6b21;&#x6536;&#x8cbb;" ID="ID_523169270" CREATED="1527425410415" MODIFIED="1527425433872"/>
<node TEXT="&#x76ee;&#x6a19;&#x65cf;&#x7fa4;:&#x5b8c;&#x5168;&#x4e0d;&#x60f3;&#x770b;&#x5230;&#x5ee3;&#x544a;&#x7684;&#x4eba;" ID="ID_847302621" CREATED="1527425434911" MODIFIED="1527425460375"/>
<node TEXT="&#x53ef;&#x5f97;&#x670d;&#x52d9;:ABCDH" ID="ID_1212303368" CREATED="1527425461273" MODIFIED="1527425486018"/>
</node>
</node>
<node TEXT="&#x884c;&#x92b7;&#x7b56;&#x7565;" POSITION="right" ID="ID_1872114071" CREATED="1527425491034" MODIFIED="1527425507961">
<edge COLOR="#7c7c00"/>
<node TEXT="&#x5c0d;&#x7528;&#x6236;&#x7aef;" ID="ID_465219408" CREATED="1527425508727" MODIFIED="1527425513362">
<node TEXT="&#x4ee5;&#x62bd;&#x734e;(&#x4e0d;&#x78ba;&#x5b9a;&#x6a5f;&#x7387;&#x7684;&#x734e;&#x52f5;)&#x70ba;&#x8a98;&#x56e0;&#x4fc3;&#x4f7f;&#x7528;&#x6236;&#x52a0;&#x5165;," ID="ID_1377562835" CREATED="1527425514534" MODIFIED="1527425567493"/>
<node TEXT="&#x4ee5;Win It Back&#x7684;&#x6a5f;&#x5236;,&#x8b93;&#x7528;&#x6236;&#x6263;&#x6b3e;&#x5f8c;&#x70ba;&#x4e86;&#x8cfa;&#x56de;&#x8cbb;&#x7528;&#x771f;&#x7684;&#x958b;&#x59cb;&#x9032;&#x884c;&#x904b;&#x52d5;" ID="ID_1926187681" CREATED="1527425568430" MODIFIED="1527425637162"/>
<node TEXT="&#x6bcf;&#x4e00;&#x6b21;&#x7684;&#x904b;&#x52d5;&#x9054;&#x6a19;&#x90fd;&#x7d66;&#x4e88;&#x80fd;&#x5920;&#x5be6;&#x969b;&#x8b93;&#x734e;&#x91d1;&#x52a0;&#x6210;&#x7684;&#x9ede;&#x6578;,&#xa;&#x8b93;&#x7528;&#x6236;&#x5c0d;&#x904b;&#x52d5;&#x7522;&#x751f;&#x50f9;&#x503c;&#x611f;" ID="ID_1947543327" CREATED="1527425638021" MODIFIED="1527425710894"/>
<node TEXT="&#x7dad;&#x6301;&#x65b0;&#x9bae;&#x611f;,&#x5c0d;&#x61c9;&#x5b63;&#x7bc0;&#x548c;&#x7279;&#x6b8a;&#x7bc0;&#x65e5;&#x63a8;&#x51fa;&#x671f;&#x9593;&#x9650;&#x5b9a;&#x7684;&#x7279;&#x5225;&#x904b;&#x52d5;&#x6d3b;&#x52d5;,&#x7528;&#x6236;&#x53ef;&#x4ee5;&#x8d0f;&#x5f97;Trophy&#x548c;&#x8cbc;&#x5716;" ID="ID_932722143" CREATED="1528204031090" MODIFIED="1528204131381"/>
</node>
<node TEXT="&#x5c0d;&#x8d0a;&#x52a9;&#x5546;&#x7aef;" ID="ID_458448598" CREATED="1527425738312" MODIFIED="1527425747093">
<node TEXT="&#x6211;&#x5011;&#x63d0;&#x4f9b;&#x7684;&#x4e0d;&#x53ea;&#x662f;&#x5e38;&#x88ab;&#x7528;&#x6236;&#x7121;&#x8996;app&#x5167;&#x5d4c;&#x5ee3;&#x544a;,&#xa;&#x800c;&#x662f;&#x9577;&#x9054;&#x5341;&#x4e94;&#x5206;&#x9418;,&#x5fc5;&#x9808;&#x5168;&#x795e;&#x8cab;&#x6ce8;,&#x4e26;&#x4e14;&#x5168;&#x8eab;&#x53bb;&#x56de;&#x61c9;&#x7684;&#x4e92;&#x52d5;&#x5f0f;&#x6d3b;&#x52d5;,&#x5c0d;&#x65bc;&#x5ee3;&#x544a;&#x7684;&#x8aaa;&#x670d;&#x529b;&#x548c;&#x5f71;&#x97ff;&#x7684;&#x6642;&#x6548;&#x5c07;&#x9060;&#x5927;&#x65bc;&#x666e;&#x901a;&#x7684;&#x5ee3;&#x544a;&#x6b04;&#x4f4d;" ID="ID_1795954122" CREATED="1527425748421" MODIFIED="1527425941020"/>
<node TEXT="&#x5728;Hardcore&#x7684;&#x90e8;&#x5206;,&#x7528;&#x6236;&#x7b49;&#x65bc;&#x6bcf;&#x4e00;&#x9910;&#x90fd;&#x5fc5;&#x9808;&#x771f;&#x7684;&#x6d88;&#x8cbb;&#x6389;&#x8a72;&#x7522;&#x54c1;,&#xa;&#x9019;&#x5df2;&#x7d93;&#x8d85;&#x8d8a;&#x5ee3;&#x544a;&#x7684;&#x5c64;&#x6b21;,&#x800c;&#x662f;&#x76f4;&#x63a5;&#x7684;&#x8cfc;&#x8cb7;&#x884c;&#x70ba;.&#xa;&#x800c;&#x4e14;&#x6210;&#x529f;&#x7626;&#x8eab;&#x7684;&#x4f7f;&#x7528;&#x8005;&#x5c07;&#x6703;&#x6210;&#x70ba;&#x8a72;&#x7522;&#x54c1;&#x7684;&#x611b;&#x7528;&#x8005;,&#x66f4;&#x6703;&#x6a02;&#x610f;&#x5411;&#x81ea;&#x5df1;&#x8eab;&#x908a;&#x7684;&#x4eba;&#x63a8;&#x85a6;&#x9019;&#x4e9b;&#x7522;&#x54c1;" ID="ID_907286336" CREATED="1527425941661" MODIFIED="1528204253483"/>
</node>
</node>
<node TEXT="&#x6536;&#x652f;&#x7d50;&#x69cb;" POSITION="right" ID="ID_904155009" CREATED="1527426076356" MODIFIED="1527426084591">
<edge COLOR="#ff0000"/>
<node TEXT="&#x6bcf;&#x6708;(Advance&#x7528;&#x6236;&#x6578;=Xad,HardCore&#x7528;&#x6236;&#x6578;=Xhc)" FOLDED="true" ID="ID_1109887092" CREATED="1527426387091" MODIFIED="1527992641920">
<node TEXT="&#x6536;&#x5165;" FOLDED="true" ID="ID_1290068686" CREATED="1527426407116" MODIFIED="1527426409824">
<node TEXT="&#x57fa;&#x790e;&#x5d4c;&#x5165;&#x5f0f;&#x5ee3;&#x544a;&#x7248;&#x9762;&#x8cbb;&#x7528;" ID="ID_1555314174" CREATED="1527992687826" MODIFIED="1527992735240"/>
<node TEXT="&#x6708;&#x8cbb;" FOLDED="true" ID="ID_561097574" CREATED="1527992549927" MODIFIED="1527992562580">
<node TEXT="Xad*500 + Xhc*1000" ID="ID_1179270106" CREATED="1527992648341" MODIFIED="1527992684961"/>
</node>
<node TEXT="Win it back Plus&#x5ee3;&#x544a;&#x8cbb;" FOLDED="true" ID="ID_269999277" CREATED="1527992740778" MODIFIED="1527992772369">
<node TEXT="&#x6240;&#x6709;&#x7528;&#x6236;&#x5be6;&#x969b;&#x53c3;&#x8207;&#x7684;&#x7e3d;&#x6b21;&#x6578;*&#x55ae;&#x6b21;&#x5ee3;&#x544a;&#x55ae;&#x50f9;" ID="ID_737186272" CREATED="1527992776896" MODIFIED="1527993047467"/>
</node>
<node TEXT="essentialist&#x6536;&#x5165;" FOLDED="true" ID="ID_718326895" CREATED="1527992889891" MODIFIED="1527992938722">
<node TEXT="&#x8cfc;&#x8cb7;&#x4eba;&#x6578;*600" ID="ID_1323053331" CREATED="1527992924452" MODIFIED="1527992958728"/>
</node>
</node>
<node TEXT="&#x652f;&#x51fa;" FOLDED="true" ID="ID_1811176143" CREATED="1527426410449" MODIFIED="1527426412564">
<node TEXT="&#x904b;&#x52d5;&#x9054;&#x6a19;&#x5f8c;&#x7684;&#x9000;&#x8cbb;" ID="ID_1399593079" CREATED="1527993230989" MODIFIED="1527993259091"/>
<node TEXT="&#x4f3a;&#x670d;&#x5668;&#x71df;&#x904b;&#x6210;&#x672c;" ID="ID_1450379585" CREATED="1527993259575" MODIFIED="1527993268569"/>
<node TEXT="googlePlay&#x4e0a;&#x67b6;&#x8cbb;" ID="ID_1172857401" CREATED="1527993268928" MODIFIED="1527993285792"/>
<node TEXT="&#x4eba;&#x4e8b;&#x6210;&#x672c;" ID="ID_1117046309" CREATED="1527993286136" MODIFIED="1527993295988"/>
<node TEXT="&#x516c;&#x95dc;&#x5ba3;&#x50b3;&#x8cbb;" ID="ID_85072485" CREATED="1527993296489" MODIFIED="1527993308236"/>
</node>
</node>
<node TEXT="&#x6bcf;&#x5b63;" FOLDED="true" ID="ID_1150636704" CREATED="1527426396404" MODIFIED="1527993329175">
<node TEXT="&#x6536;&#x5165;" ID="ID_1480986732" CREATED="1527426414802" MODIFIED="1527426417075"/>
<node TEXT="&#x652f;&#x51fa;" ID="ID_77461196" CREATED="1527426417435" MODIFIED="1527426420107"/>
</node>
</node>
<node TEXT="&#x4eba;&#x4e8b;&#x7d50;&#x69cb;" FOLDED="true" POSITION="right" ID="ID_1736207080" CREATED="1527426085904" MODIFIED="1527426091969">
<edge COLOR="#0000ff"/>
<node TEXT="&#x7db2;&#x7ad9;&#x71df;&#x904b;" FOLDED="true" ID="ID_249884884" CREATED="1527426121400" MODIFIED="1527426128993">
<node TEXT="&#x7db2;&#x9801;&#x8a2d;&#x8a08;" ID="ID_554313115" CREATED="1527426222775" MODIFIED="1527426233649"/>
<node TEXT="&#x7db2;&#x8def;&#x7ba1;&#x7406;" ID="ID_1523389623" CREATED="1527426234009" MODIFIED="1527426249301"/>
</node>
<node TEXT="app&#x7cfb;&#x7d71;&#x7dad;&#x8b77;" FOLDED="true" ID="ID_550696131" CREATED="1527426129431" MODIFIED="1527426137690">
<node TEXT="&#x7db2;&#x8def;&#x7cfb;&#x7d71;&#x5b89;&#x5168;" ID="ID_1555727220" CREATED="1527426251207" MODIFIED="1527426272926"/>
<node TEXT="OpenCV" ID="ID_73172876" CREATED="1527426275567" MODIFIED="1527426287837"/>
<node TEXT="ArUCo" ID="ID_1923234696" CREATED="1527426288337" MODIFIED="1527426295200"/>
<node TEXT="OpenPose (CUDA/cuDNN/)" ID="ID_1776342301" CREATED="1527426295466" MODIFIED="1527426330247"/>
</node>
<node TEXT="&#x8ca1;&#x52d9;&#x8207;&#x6263;&#x6b3e;&#x9000;&#x8cbb;&#x6a5f;&#x5236;&#x63a7;&#x7ba1;" ID="ID_719856032" CREATED="1527426138206" MODIFIED="1527426200487"/>
<node TEXT="&#x516c;&#x95dc;&#x5ba3;&#x50b3;&#x90e8;&#x9580;" ID="ID_1497843011" CREATED="1527426160586" MODIFIED="1527426367843"/>
</node>
<node TEXT="app &#x67b6;&#x69cb;" FOLDED="true" POSITION="right" ID="ID_1285395157" CREATED="1527426098739" MODIFIED="1527426105102">
<edge COLOR="#00ff00"/>
<node TEXT="&#x521d;&#x59cb;&#x8a2d;&#x5b9a;" FOLDED="true" ID="ID_611318893" CREATED="1527595374418" MODIFIED="1527595381115">
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x5370;&#x51fa;&#x4e00;&#x5f35;A4&#x7d19;&#x5927;&#x5c0f;&#x7684;AR MARKER,&#x5148;&#x9032;&#x884c;&#x76f8;&#x6a5f;&#x6821;&#x6b63;,&#xa;&#x518d;&#x5c07;&#x9019;&#x5f35;Marker&#x653e;&#x5728;&#x80f8;&#x524d;,&#x627e;&#x5230;&#x91dd;&#x5c0d;&#x81ea;&#x5df1;&#x7684;&#x8eab;&#x9ad8;&#x6240;&#x9069;&#x5408;&#x7684;&#x76f8;&#x6a5f;&#x8ddd;&#x96e2;," ID="ID_10926213" CREATED="1527595381896" MODIFIED="1527595552306"/>
</node>
<node TEXT="&#x6bcf;&#x6708;&#x904b;&#x52d5;&#x6642;&#x7a0b;&#x8868;" FOLDED="true" ID="ID_599874792" CREATED="1527989152319" MODIFIED="1527989177443">
<node TEXT="&#x4ee5;&#x4e00;&#x500b;&#x6708;30&#x5929;&#x70ba;&#x55ae;&#x4f4d;,&#x5148;&#x8b93;&#x4f7f;&#x7528;&#x8005;&#x6392;&#x51fa;&#x9069;&#x5408;&#x81ea;&#x5df1;&#x7684;&#x904b;&#x52d5;&#x884c;&#x7a0b;&#x8868;,&#x540c;&#x6642;&#x53ef;&#x4ee5;&#x9810;&#x5148;&#x7b97;&#x51fa;&#x4ed6;&#x5982;&#x679c;&#x5b8c;&#x5168;&#x7167;&#x8868;&#x64cd;&#x8ab2;,&#x5230;&#x54ea;&#x4e00;&#x5929;&#x5c31;&#x53ef;&#x4ee5;&#x628a;&#x6708;&#x8cbb;&#x5168;&#x62ff;&#x56de;&#x4f86;,&#x4e26;&#x4e14;&#x9810;&#x5148;&#x8a2d;&#x5b9a;&#x7121;&#x6cd5;&#x5982;&#x671f;&#x9032;&#x884c;&#x904b;&#x52d5;&#x7684;Plan B,&#x53ef;&#x4ee5;&#x9032;&#x884c;&#x88dc;&#x6551;&#x904b;&#x52d5;&#x7684;&#x6642;&#x9593;&#x9ede;" ID="ID_1963894181" CREATED="1527989192775" MODIFIED="1527989512384"/>
</node>
<node TEXT="&#x904b;&#x52d5;&#x8868;&#x73fe;&#x8207;&#x98f2;&#x98df;&#x9a57;&#x8b49;" FOLDED="true" ID="ID_1931589327" CREATED="1527987947064" MODIFIED="1527988661910">
<node TEXT="WeARFitLight" FOLDED="true" ID="ID_1489866873" CREATED="1527987968357" MODIFIED="1527988012987">
<node TEXT="&#x5728;&#x4f7f;&#x7528;&#x8005;&#x7684;&#x624b;&#x6a5f;&#x4e0a;&#x9032;&#x884c;&#x9a57;&#x8b49;,&#x5075;&#x6e2c;&#x6975;&#x7c21;&#x55ae;&#x7684;&#x756b;&#x9762;&#x8b8a;&#x5316;(&#x4f7f;&#x7528;&#x8005;&#x63ee;&#x624b;&#x81c2;,&#x8ec0;&#x5e79;&#x5f4e;&#x66f2;,&#x62ac;&#x817f;)" ID="ID_417376033" CREATED="1527988022596" MODIFIED="1527988142572"/>
</node>
<node TEXT="WeARFitAdvance" FOLDED="true" ID="ID_388806651" CREATED="1527988143873" MODIFIED="1527988155663">
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x5148;&#x7d93;&#x904e;&#x7db2;&#x8def;&#x8207;&#x4f3a;&#x670d;&#x5668;&#x7aef;&#x9023;&#x7dda;,&#x4f3a;&#x670d;&#x5668;&#x7522;&#x751f;&#x4e00;&#x7d44;&#x7368;&#x4e00;&#x7121;&#x4e8c;&#x7684;&#x904b;&#x52d5;&#x6392;&#x5217;&#x7d44;&#x5408;&#x5f8c;&#x8a18;&#x9304;&#x4e26;&#x4e14;&#x50b3;&#x9001;&#x7d66;&#x4f7f;&#x7528;&#x8005;,&#x4f7f;&#x7528;&#x8005;&#x958b;&#x59cb;&#x9032;&#x884c;&#x672c;&#x6b21;&#x7684;&#x904b;&#x52d5;&#x6642;,&#x624b;&#x6a5f;&#x6703;&#x5148;&#x5c0d;&#x5f71;&#x50cf;&#x9032;&#x884c;&#x7c21;&#x55ae;&#x7684;&#x8655;&#x7406;(Thresholding&#x6216;&#x62bd;&#x53d6;histogram)&#x518d;&#x628a;&#x8cc7;&#x6599;&#x4e32;&#x6d41;&#x5230;&#x4f3a;&#x670d;&#x5668;,&#x7531;&#x4f3a;&#x670d;&#x5668;&#x5b89;&#x88dd;&#x7684;&#x7a0b;&#x5f0f;&#x5224;&#x5b9a;&#x4f7f;&#x7528;&#x8005;&#x7684;&#x59ff;&#x52e2;&#x8868;&#x73fe;&#x6b63;&#x78ba;&#x8207;&#x5426;,&#x7d00;&#x9304;&#x7d50;&#x679c;&#x4e26;&#x4e14;&#x540c;&#x6642;&#x56de;&#x50b3;&#x5230;&#x4f7f;&#x7528;&#x8005;&#x7684;&#x624b;&#x6a5f;" ID="ID_1547447016" CREATED="1527988156608" MODIFIED="1527988563205"/>
</node>
<node TEXT="WeARFitHardCore" FOLDED="true" ID="ID_1942091267" CREATED="1527988598425" MODIFIED="1527988612291">
<node TEXT="&#x7d93;&#x7531;&#x8d85;&#x5546;&#x7684;&#x6263;&#x6b3e;&#x7d00;&#x9304;&#x4f86;&#x9a57;&#x8b49;&#x4f7f;&#x7528;&#x8005;&#x662f;&#x5426;&#x65bc;&#x6b63;&#x78ba;&#x7684;&#x6642;&#x9593;&#x8cb7;&#x4e86;&#x6b63;&#x78ba;&#x7684;&#x98df;&#x7269;,&#x518d;&#x7528;&#x96fb;&#x8166;&#x8996;&#x89ba;&#x78ba;&#x8a8d;&#x4f7f;&#x7528;&#x8005;&#x771f;&#x7684;&#x628a;&#x5b83;&#x5403;&#x4e0b;&#x809a;(&#x6216;&#x81f3;&#x5c11;&#x628a;&#x5b83;&#x585e;&#x9032;&#x5634;&#x88e1;&#x4e86;)" ID="ID_1475251634" CREATED="1527988613535" MODIFIED="1527988909636"/>
</node>
</node>
<node TEXT="&#x904b;&#x52d5;&#x793a;&#x7bc4;&#x6559;&#x5b78;" FOLDED="true" ID="ID_876996858" CREATED="1527988981497" MODIFIED="1527989052728">
<node TEXT="&#x7c21;&#x55ae;&#x7684;gif&#x52d5;&#x756b;&#x642d;&#x914d;&#x6587;&#x5b57;&#x6558;&#x8ff0;" ID="ID_758340778" CREATED="1527989001347" MODIFIED="1527989092482"/>
</node>
<node TEXT="&#x904b;&#x52d5;&#x71b1;&#x91cf;&#x6d88;&#x8017;&#x8a66;&#x7b97;" ID="ID_906604981" CREATED="1527989135732" MODIFIED="1527989151695"/>
</node>
<node TEXT="&#x5b98;&#x7db2;&#x67b6;&#x69cb;" POSITION="right" ID="ID_28509778" CREATED="1527426105540" MODIFIED="1527426117868">
<edge COLOR="#ff00ff"/>
</node>
<node TEXT="&#x91cd;&#x5927;&#x554f;&#x984c;" FOLDED="true" POSITION="right" ID="ID_1670133416" CREATED="1527990711566" MODIFIED="1527990719204">
<edge COLOR="#00ffff"/>
<node TEXT="Fitlottory&#x62bd;&#x734e;&#x6a5f;&#x5236;" FOLDED="true" ID="ID_988878898" CREATED="1527990720211" MODIFIED="1527990739044">
<node TEXT="&#x7a76;&#x7adf;&#x662f;&#x8981;&#x7528;&#x4e09;&#x671f;&#x9054;&#x6a19;&#x4f7f;&#x7528;&#x8005;&#x81ea;&#x9078;&#x865f;&#x78bc;&#x4f86;&#x9032;&#x884c;&#x514c;&#x734e;(&#x53ef;&#x80fd;&#x767c;&#x751f;&#x69d3;&#x9f9c;&#x6216;&#x662f;&#x591a;&#x4eba;&#x540c;&#x6642;&#x5206;&#x5f97;&#x540c;&#x4e00;&#x734e;&#x9805;)&#xa;&#x53c8;&#x6216;&#x662f;&#x6bcf;&#x4e00;&#x6b21;&#x958b;&#x734e;&#x6642;&#x5c0d;&#x6240;&#x6709;&#x9054;&#x6a19;&#x8005;&#x4e2d;&#x62bd;&#x53d6;&#x4e00;&#x4f4d;&#x4f5c;&#x70ba;&#x8a72;&#x734e;&#x9805;&#x7684;&#x5f97;&#x8b1b;&#x8005;" ID="ID_1517398896" CREATED="1527990739920" MODIFIED="1527990956417"/>
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x53ef;&#x80fd;&#x6703;&#x70ba;&#x4e86;&#x589e;&#x52a0;&#x4e2d;&#x734e;&#x6a5f;&#x7387;,&#x53ef;&#x80fd;&#x6703;&#x540c;&#x4e00;&#x4eba;&#x8a2d;&#x7f6e;&#x591a;&#x91cd;&#x5e33;&#x865f;,&#x5f71;&#x97ff;&#x516c;&#x5e73;&#x6027;,&#x96d6;&#x7136;&#x5df2;&#x7d93;&#x6709;&#x9810;&#x9632;&quot;&#x540c;&#x4e00;&#x55ae;&#x4f4d;&#x6642;&#x9593;&#x5167;&#x7d2f;&#x7a4d;&#x591a;&#x500b;&#x5e33;&#x865f;&quot;&#x7684;&#x6a5f;&#x5236;,&#x4f46;&#x53ef;&#x80fd;&#x9084;&#x662f;&#x6709;&#x4eba;&#x6703;&#x5728;&#x4e0d;&#x540c;&#x6642;&#x6bb5;&#x9032;&#x884c;&#x904b;&#x52d5;&#x9a57;&#x8b49;(&#x4eba;&#x7684;&#x9ad4;&#x529b;&#x6709;&#x9650;,&#x53ef;&#x80fd;&#x4e09;&#x5230;&#x56db;&#x500b;&#x5e33;&#x865f;&#x4fbf;&#x662f;&#x6975;&#x9650;)" ID="ID_1895825818" CREATED="1527990957399" MODIFIED="1527992209162"/>
</node>
<node TEXT="&#x96fb;&#x8166;&#x8996;&#x89ba;&#x9a57;&#x8b49;&#x6a5f;&#x5236;" FOLDED="true" ID="ID_1576090671" CREATED="1527992227234" MODIFIED="1527992239092">
<node TEXT="&#x4f7f;&#x7528;&#x8005;&#x70ba;&#x4e86;&#x5077;&#x61f6;,&#x53ef;&#x80fd;&#x6703;&#x88fd;&#x9020;&#x7a0b;&#x5f0f;,&#x5728;&#x63a5;&#x6536;&#x5230;&#x4f3a;&#x670d;&#x5668;&#x7aef;&#x7d66;&#x7684;&#x904b;&#x52d5;&#x9805;&#x76ee;&#x5f8c;&#x7528;&#x96fb;&#x8166;&#x52d5;&#x756b;&#x81ea;&#x52d5;&#x7522;&#x751f;&#x904b;&#x52d5;&#x5f71;&#x50cf;,&#x9a19;&#x904e;&#x9a57;&#x8b49;&#x6a5f;&#x5236;." ID="ID_793245966" CREATED="1527992240530" MODIFIED="1527992393044"/>
</node>
<node TEXT="&#x4f3a;&#x670d;&#x5668;&#x9023;&#x7dda;&#x8207;&#x904b;&#x7b97;&#x8ca0;&#x8377;" ID="ID_494846644" CREATED="1527991100562" MODIFIED="1527991118921"/>
</node>
</node>
</map>
